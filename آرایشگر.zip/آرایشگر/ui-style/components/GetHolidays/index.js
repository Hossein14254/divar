'use client';
import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import moment from 'moment-jalaali';
import { useEffect, useRef, useState } from 'react';
import DateObject from 'react-date-object';
import gregorian from 'react-date-object/calendars/gregorian';
import persian from 'react-date-object/calendars/persian';
import persian_fa from 'react-date-object/locales/persian_fa';
import { FiAlertCircle, FiCalendar, FiCheckCircle, FiPlus, FiTrash2, FiX } from 'react-icons/fi';
import { Calendar } from 'react-multi-date-picker';
import Swal from 'sweetalert2';
import styles from './GetHolidays.module.css';

export default function GetHolidays({ token }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [datas, setDatas] = useState(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [newHoliday, setNewHoliday] = useState({ 
    name: 'تعطیلی', 
    date: null, 
    gregorianDate: null 
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  const calendarRef = useRef(null);
  const inputRef = useRef(null);
  const modalRef = useRef(null);
  const hasFetched = useRef(false);

  const checkAuth = async () => {
    try {
      setLoading(true);
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/holidays/", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) throw new Error('Authentication failed');
      
      const data = await response.json();
      setDatas(data.days);
    } catch (error) {
      console.error('Error:', error);
      setError('خطا در دریافت تعطیلات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true;
      checkAuth();
    }
  }, []);

  const deleteHoliday = async (id) => {
    try {
      setLoading(true);
      const { status } = await axios.delete(
        process.env.NEXT_PUBLIC_APIURL+`/holidays/delete/${id}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (status === 200) {
        showSuccess('تعطیلی با موفقیت حذف شد');
        await checkAuth();
      }
    } catch (error) {
      console.error(error);
      setError('خطا در حذف تعطیلی');
    } finally {
      setLoading(false);
    }
  };

  const saveHoliday = async () => {
    if (!newHoliday.name || !newHoliday.date) {
      setError('لطفاً نام و تاریخ تعطیلی را وارد کنید');
      return;
    }

    try {
      setLoading(true);
      const { status } = await axios.post(
        process.env.NEXT_PUBLIC_APIURL+"/holidays/new",
        {
          description: newHoliday.name,
          date: newHoliday.date
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (status === 200) {
        showSuccess('تعطیلی جدید با موفقیت ثبت شد');
        setNewHoliday({ name: 'تعطیلی', date: null, gregorianDate: null });
        setIsModalOpen(false);
        await checkAuth();
      }
    } catch (error) {
      console.error(error);
      setError('خطا در ثبت تعطیلی');
    } finally {
      setLoading(false);
    }
  };

  const handleDateChange = (date) => {
    if (!date) {
      setNewHoliday(prev => ({ ...prev, date: null, gregorianDate: null }));
      setIsCalendarOpen(false);
      return;
    }

    const persianDate = new DateObject({ date, calendar: persian, locale: persian_fa });
    const gregorianDate = toEnglishDigits(persianDate.convert(gregorian).format('YYYY-MM-DD'));

    setNewHoliday(prev => ({
      ...prev,
      date,
      gregorianDate,
    }));
    setError(null);
    setIsCalendarOpen(false);
  };

  const toEnglishDigits = (str) => {
    if (typeof str !== 'string') return str;
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return persianDigits.reduce(
      (result, digit, i) => result.replace(new RegExp(digit, 'g'), englishDigits[i]),
      str
    );
  };

  const handleNameChange = (e) => {
    const value = e.target.value;
    if (value.length <= 100) {
      setNewHoliday(prev => ({ ...prev, name: value }));
      setError(null);
    } else {
      setError('نام تعطیلات نمی‌تواند بیشتر از ۱۰۰ کاراکتر باشد');
    }
  };

  const showSuccess = (message) => {
    Swal.fire({
      title: message,
      icon: "success",
      timer: 2000,
      showConfirmButton: false
    });
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target) &&
          inputRef.current && !inputRef.current.contains(event.target)) {
        setIsCalendarOpen(false);
      }
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setIsModalOpen(false);
        setIsCalendarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={styles.container}>
      {/* پیام‌های سیستم */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`${styles.alert} ${error.includes('موفقیت') ? styles.success : styles.error}`}
          >
            <div className={styles.alertContent}>
              {error.includes('موفقیت') ? (
                <FiCheckCircle className={styles.alertIcon} />
              ) : (
                <FiAlertCircle className={styles.alertIcon} />
              )}
              <span>{error}</span>
            </div>
            <button 
              onClick={() => setError(null)} 
              className={styles.alertClose}
            >
              <FiX />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* لودینگ */}
      {loading && (
        <div className={styles.loadingOverlay}>
          <div className={styles.loadingSpinner} />
          <span>در حال پردازش...</span>
        </div>
      )}

      {/* هدر صفحه */}
      <div className={styles.header}>
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => setIsModalOpen(true)}
          className={styles.addButton}
        >
          <FiPlus className={styles.addIcon} />
          افزودن تعطیلی جدید
        </motion.button>
      </div>

      {/* لیست تعطیلات */}
      <div className={styles.holidaysList}>
        {datas?.length === 0 && !loading ? (
          <div className={styles.emptyState}>
            <FiCalendar className={styles.emptyIcon} />
            <h3>هیچ تعطیلی ثبت نشده است</h3>
            <p>برای افزودن تعطیلی جدید روی دکمه بالا کلیک کنید</p>
          </div>
        ) : (
          datas?.slice()?.reverse()?.map(item => (
            <motion.div
              key={item._id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.01 }}
              className={styles.holidayCard}
            >
              <div className={styles.holidayInfo}>
                <div className={styles.holidayDate}>
                  <FiCalendar className={styles.dateIcon} />
                  <span>{moment(item.date).format('jYYYY/jMM/jDD')}</span>
                </div>
                <h3 className={styles.holidayTitle}>{item.description}</h3>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => deleteHoliday(item._id)}
                className={styles.deleteButton}
                aria-label={`حذف ${item.description}`}
              >
                <FiTrash2 className={styles.deleteIcon} />
              </motion.button>
            </motion.div>
          ))
        )}
      </div>

      {/* مودال افزودن تعطیلی */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={styles.modalOverlay}
          >
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              ref={modalRef}
              className={styles.modal}
            >
              <div className={styles.modalHeader}>
                <h2>افزودن تعطیلی جدید</h2>
                <button 
                  onClick={() => {
                    setIsModalOpen(false);
                    setIsCalendarOpen(false);
                  }}
                  className={styles.closeModal}
                >
                  <FiX />
                </button>
              </div>

              <div className={styles.modalBody}>


                <div className={styles.formGroup}>
                  <label htmlFor="date">تاریخ تعطیلی</label>
                  <div 
                    className={styles.datePicker}
                    onClick={() => setIsCalendarOpen(true)}
                    ref={inputRef}
                  >
                    <input
                      id="date"
                      type="text"
                      value={newHoliday.date ? newHoliday.date.format('YYYY/MM/DD') : ''}
                      readOnly
                      placeholder="انتخاب تاریخ"
                    />
                    <FiCalendar className={styles.calendarButton} />
                  </div>

                  {isCalendarOpen && (
                    <div ref={calendarRef} className={styles.calendarWrapper}>
                      <Calendar
                        value={newHoliday.date}
                        onChange={handleDateChange}
                        calendar={persian}
                        locale={persian_fa}
                        minDate={new DateObject().toDate()}
                        maxDate={new DateObject({ year: 1405, month: 12, day: 29, calendar: persian }).toDate()}
                        className={styles.customCalendar}
                      />
                    </div>
                  )}
                </div>

                {newHoliday.date && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={styles.dateDisplay}
                  >
                    <div className={styles.dateDisplayRow}>
                      <span>تاریخ شمسی:</span>
                      <strong>{newHoliday.date.format('YYYY/MM/DD')}</strong>
                    </div>
                    <div className={styles.dateDisplayRow}>
                      <span>تاریخ میلادی:</span>
                      <strong>{newHoliday.gregorianDate}</strong>
                    </div>
                  </motion.div>
                )}
              </div>

              <div className={styles.modalFooter}>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setNewHoliday({ name: 'تعطیلی', date: null, gregorianDate: null });
                    setIsModalOpen(false);
                    setIsCalendarOpen(false);
                  }}
                  className={styles.cancelButton}
                >
                  انصراف
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={saveHoliday}
                  className={styles.saveButton}
                  disabled={loading}
                >
                  ذخیره تعطیلی
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}