import BarberList from '@/mini-components/BarberList';
import Datepicker from '@/mini-components/Datepicker';
import ProgressSteps from '@/mini-components/ProgressTracker';
import WorkHoursLeave from '@/mini-components/WorkHoursLeave';
import axios from 'axios';
import moment from 'moment-jalaali';
import { useEffect, useState } from 'react';
import {
    FiAlertTriangle,
    FiCalendar,
    FiCheckCircle,
    FiClock,
    FiEdit2,
    FiPlus,
    FiTrash2,
    FiUser,
    FiXCircle
} from 'react-icons/fi';
import Swal from 'sweetalert2';
import styles from './style.module.css';
import styles2 from './style2.module.css';


moment.loadPersian({ dialect: 'persian-modern' });

const toPersianDate = (date) => {
  try {
    return moment(date).format('jYYYY/jMM/jDD');
  } catch {
    return 'نامشخص';
  }
};

export default function Leave({ token, numberme }) {
  const [leaves, setLeaves] = useState([]);
  const [isAdding, setIsAdding] = useState(false);
  const [selectedBarberId, setSelectedBarberId] = useState(null);
  const [selectedDateId, setSelectedDateId] = useState(null);
  const [selectedHoursId, setSelectedHoursId] = useState(null);
  const [title, setTitle] = useState('مرخصی');
  const [step, setStep] = useState(0);
  const [selectedBarberName, setSelectedBarberName] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedHours, setSelectedHours] = useState('');
  const fetchLeaves = async () => {
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      };
      const response = await axios.get(process.env.NEXT_PUBLIC_APIURL+'/leave/', config);
      setLeaves(response.data.Leave || []);
    } catch (error) {
      Swal.fire({
        title: 'خطا در بارگذاری مرخصی‌ها',
        icon: 'error',
        text: error?.response?.data?.message || 'خطای نامشخص',
      });
    }
  };
  useEffect(() => {
    fetchLeaves();
  }, [token]);

  const handleSelectBarber = (id, name) => {
    setSelectedBarberId(id);
    setSelectedBarberName(name);
    setStep(1);
  };

  const handleSelectDate = (id, date) => {
    setSelectedDateId(id);
    setSelectedDate(date);
    setStep(2);
  };

  const handleSelectHours = (hours) => {
    console.log(hours)
    setSelectedHours(hours);
    setStep(3);
  };

  const handleBack = () => {
    setIsAdding(false)
    setStep(0);
    if (step > 0) {
    } else {
      setSelectedBarberId(null);
      setSelectedDateId(null);
      setSelectedHoursId(null);
      setTitle('');
      setIsAdding(false);
    }
  };

  const handleNext = async () => {
    if (step < 3) {
      setStep(step + 1);
      return;
    }

    if (!title.trim()) {
      Swal.fire({
        title: 'عنوان مرخصی ضروری است',
        icon: 'error',
        text: 'لطفاً عنوان مناسبی برای مرخصی وارد کنید.',
      });
      return;
    }

    const data = {
      title,
      date_id: selectedDateId,
      provider_id: selectedBarberId,
      workingHour_ids: selectedHours,
    };

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      };
      const response = await axios.post(process.env.NEXT_PUBLIC_APIURL+'/leave/new', data, config);
      if (response.status === 200 || response.status === 201) {
        Swal.fire({
          title: 'مرخصی ثبت شد',
          icon: 'success',
          showConfirmButton: false,
          timer: 1500
        });
        fetchLeaves()
        setLeaves([...leaves, ...response.data.leaves]);
        handleBack();
      }
    } catch (error) {
      Swal.fire({
        title: 'خطا در ثبت مرخصی',
        icon: 'error',
        text: error?.response?.data?.message || 'خطای نامشخص',
      });
    }
  };

  const handleDelete = async (leaveId) => {
    Swal.fire({
      title: 'آیا مطمئن هستید؟',
      text: 'این عمل قابل بازگشت نیست!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'حذف شود',
      cancelButtonText: 'انصراف'
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const config = {
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
          };
          await axios.delete(process.env.NEXT_PUBLIC_APIURL+`/leave/delete/${leaveId}`, config);
          setLeaves(leaves.filter((leave) => leave._id !== leaveId));
          Swal.fire({
            title: 'حذف شد!',
            text: 'مرخصی با موفقیت حذف شد.',
            icon: 'success',
            timer: 1500,
            showConfirmButton: false
          });
        } catch (error) {
          Swal.fire({
            title: 'خطا!',
            text: error?.response?.data?.message || 'حذف انجام نشد',
            icon: 'error',
          });
        }
      }
    });
  };

  return (
    <div className={styles.container}>
      {!isAdding ? (
        <div className={styles2.leaveListContainer}>
  <div className={styles2.header}>
    <button 
      className={styles2.addButton} 
      onClick={() => {
        setIsAdding(true);
        setStep(0);
      }}
    >
      <FiPlus className={styles2.buttonIcon} />
      <span>افزودن مرخصی جدید</span>
    </button>
  </div>

  {leaves.length === 0 ? (
    <div className={styles2.emptyState}>
      <div className={styles2.emptyIllustration}>
        <img 
          src="/images/empty-leave.svg" 
          alt="No leaves" 
          className={styles2.emptyImage}
        />
      </div>
      <p className={styles2.emptyText}>هنوز مرخصی ثبت نشده است</p>
      <button 
        className={styles2.emptyActionButton}
        onClick={() => {
          setIsAdding(true);
          setStep(0);
        }}
      >
        ثبت اولین مرخصی
      </button>
    </div>
  ) : (
    <div className={styles2.leaveCardsContainer}>
      <div className={styles2.leaveCards}>
        {leaves.map((leave) => (
          <div style={{border:'2px solid'}} className={styles2.leaveCard}>
            <div className={styles2.cardHeader}>
              <div className={styles2.cardTitleWrapper}>
                <h3 className={styles2.cardTitle}>
                  {leave.title}
                </h3>
                <span className={`${styles2.statusBadge} ${leave.is_active ? styles2.active : styles2.inactive}`}>
                  {leave.is_active ? (
                    <>
                      <FiCheckCircle className={styles2.statusIcon} />
                      فعال
                    </>
                  ) : (
                    <>
                      <FiXCircle className={styles2.statusIcon} />
                      غیرفعال
                    </>
                  )}
                </span>
              </div>
              <div className={styles2.cardActions}>
                <button
                  className={styles2.deleteButton}
                  onClick={() => handleDelete(leave._id)}
                  aria-label="حذف مرخصی"
                >
                  <FiTrash2 className={styles2.actionIcon} />
                </button>
              </div>
            </div>
            
            <div className={styles2.cardDetails}>
              <div className={styles2.detailItem}>
                <div className={styles2.detailIconWrapper}>
                  <FiUser className={styles2.detailIcon} />
                </div>
                <div className={styles2.detailContent}>
                  <span className={styles2.detailLabel}>پرسنل:</span>
                  <span className={styles2.detailValue}>{leave.provider_id?.name || 'نامشخص'}</span>
                </div>
              </div>
              <div className={styles2.detailItem}>
                <div className={styles2.detailIconWrapper}>
                  <FiCalendar className={styles2.detailIcon} />
                </div>
                <div className={styles2.detailContent}>
                  <span className={styles2.detailLabel}>تاریخ:</span>
                  <span className={styles2.detailValue}>{toPersianDate(leave.date_id?.date)}</span>
                </div>
              </div>
              <div className={styles2.detailItem}>
                <div className={styles2.detailIconWrapper}>
                  <FiClock className={styles2.detailIcon} />
                </div>
                <div className={styles2.detailContent}>
                  <span className={styles2.detailLabel}>ساعت:</span>
                  <span className={styles2.detailValue}>
                    {leave.WorkingHour_id?.start_time} - {leave.WorkingHour_id?.end_time}
                  </span>
                </div>
              </div>
            </div>
          
          </div>
        ))}
      </div>
    </div>
  )}
</div>
      ) : (
        <div >
          <div className={styles.addLeaveHeader}>
        </div>

        <div style={{direction:"ltr"}} className={styles.progressContainer}>
        <ProgressSteps 
              totalSteps={4} 
              completedSteps={step} 
              labels={['انتخاب آرایشگر', 'انتخاب تاریخ', 'انتخاب زمان', 'تأیید نهایی']}
            />
          </div>

          <div>
            {step === 0 && (
              <div>
                <BarberList 
                  onSelectBarber={handleSelectBarber} 
                  selectedId={selectedBarberId}
                />
              </div>
            )}

            {step === 1 && (
              <div >
                <Datepicker 
                  onSelectDate={handleSelectDate} 
                  selectedId={selectedDateId}
                />
              </div>
            )}

            {step === 2 && (
              <div>
                <div >
                </div>
                <WorkHoursLeave 
                  onSelectHours={handleSelectHours} 
                  selectedId={selectedHoursId}
                />
              </div>
            )}

            {step === 3 && (
              <div className={styles.confirmSection}>
                <div className={styles.sectionHeader}>
                  <FiEdit2 className={styles.sectionIcon} />
                  <h3 className={styles.sectionTitle}>تکمیل اطلاعات مرخصی</h3>
                </div>

                <div className={styles.titleInputContainer}>
                  <label htmlFor="leaveTitle" className={styles.inputLabel}>
                    عنوان مرخصی
                  </label>
                  <input
                    id="leaveTitle"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className={styles.titleInput}
                    placeholder="مثال: مرخصی شخصی، مرخصی استعلاجی و..."
                  />
                </div>

                <div className={styles.warningBox}>
                  <FiAlertTriangle className={styles.warningIcon} />
                  <p className={styles.warningText}>
                    پس از ثبت مرخصی، امکان لغو آن وجود ندارد. لطفاً از صحت اطلاعات وارد شده اطمینان حاصل کنید.
                  </p>
                </div>

                <div className={styles.actionButtons}>
                  <button 
                    className={styles.confirmButton}
                    onClick={handleNext}
                  >
                    <FiCheckCircle className={styles.buttonIcon} />
                    ثبت نهایی مرخصی
                  </button>
                  <button 
                    className={styles.cancelButton}
                    onClick={handleBack}
                  >
                    <FiXCircle className={styles.buttonIcon} />
                    انصراف
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}