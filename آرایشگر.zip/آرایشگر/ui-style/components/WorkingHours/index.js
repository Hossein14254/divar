'use client';
import WorkingHoursChart from '@/mini-components/WorkingHoursChart';
import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { FiCalendar, FiPlus, FiTrash2, FiX } from 'react-icons/fi';
import DatePicker from 'react-multi-date-picker';
import TimePicker from 'react-multi-date-picker/plugins/time_picker';
import Swal from 'sweetalert2';
import styles from './ManageWorkingHours.module.css';

export default function GetWorkingHours({ token }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [time1, setTime1] = useState(new Date());
  const [time2, setTime2] = useState(new Date());
  const hasFetched = useRef(false);
  const [newHoliday, setNewHoliday] = useState({
    startTime: '',
    endTime: ''
  });
  const [isChartOpen, setIsChartOpen] = useState(false);
  const [holidays, setHolidays] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const modalRef = useRef(null);

  const [datas, setDatas] = useState(null);

  const checkAuth = async () => {
    try {
      console.log("checkAuth called at", new Date().toISOString());
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/workinghour/", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        throw new Error('Authentication failed');
      }
      const data = await response.json();
      console.log(data);
      setDatas(data.Hour);
    } catch (error) {
      console.error('Error:', error);
      if (router.pathname !== '/Phone') {
        await router.push('/Phone');
      }
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true;
      checkAuth();
    }
  }, []);

  const deleteHoliday = (id) => {
    const config = {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    axios.delete(process.env.NEXT_PUBLIC_APIURL+`/workinghour/delete/${id}`, config)
      .then(response => {
        if (response.status === 200) {
          Swal.fire({
            title: "موفق",
            icon: "success"
          });
          checkAuth();
        } else {
          Swal.fire({
            title: "خطا در حذف",
            icon: "error"
          });
        }
      })
      .catch(error => {
        Swal.fire({
          title: "خطا در حذف",
          icon: "error"
        });
      });
  };

  const saveHoliday = () => {
    const data = {
      start_time: time1.toString(),
      end_time: time2.toString()
    };

    const config = {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    axios.post(process.env.NEXT_PUBLIC_APIURL+"/workinghour/new", data, config)
      .then(response => {
        if (response.status === 200 || response.status === 201) {
          Swal.fire({
            title: "با موفقیت ثبت شد",
            icon: "success"
          });
          checkAuth();
        } else {
          Swal.fire({
            title: "خطا در ثبت",
            icon: "error",
            text: response?.message
          });
        }
      })
      .catch(error => {
        Swal.fire({
          title: "خطا در ثبت",
          icon: "error",
          text: error?.response?.data?.message || "نامشخص"
        });
      });

    setIsModalOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setIsModalOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className={styles.container}>
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={styles.errorMessage}
          >
            <span>{error}</span>
            <button onClick={() => setError(null)} aria-label="بستن خطا">
              <FiX className={styles.errorCloseIcon} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {loading && (
        <div className={styles.loadingOverlay}>
          <div className={styles.loadingSpinner}></div>
        </div>
      )}

      <div className={styles.buttonContainer}>
        <button
          onClick={() => setIsChartOpen(true)}
          className={styles.chartButton}
          aria-label="نمایش نمودار"
        >
          <FiCalendar className={styles.buttonIcon} />
          <span>نمایش نمودار</span>
        </button>
        <button
          onClick={() => setIsModalOpen(true)}
          className={styles.addButton}
          aria-label="افزودن ساعت کاری جدید"
        >
          <FiPlus className={styles.buttonIcon} />
          <span>افزودن ساعت کاری جدید</span>
        </button>
      </div>

      <div className={styles.holidayList}>
        {datas?.length === 0 && !loading ? (
          <div className={styles.noHolidays}>هیچ ساعت کاری یافت نشد</div>
        ) : (
          datas?.slice()?.reverse()?.map((item) => (
            <motion.div
              key={item._id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
              className={styles.holidayItem}
            >
              <div className={styles.holidayItemContent}>
                <div className={styles.holidayIconContainer}>
                  <FiCalendar className={styles.holidayIcon} />
                </div>
                <div className={styles.timeContainer}>
                  <span className={styles.holidayTime}>{item.start_time}</span>
                  <span className={styles.timeSeparator}>تا</span>
                  <span className={styles.holidayTime}>{item.end_time}</span>
                </div>
              </div>
              <button
                onClick={() => deleteHoliday(item._id)}
                className={styles.deleteButton}
                aria-label={`حذف نوبت ${item.start_time}`}
              >
                <FiTrash2 className={styles.deleteIcon} />
              </button>
            </motion.div>
          ))
        )}
      </div>

      <AnimatePresence>
        {isChartOpen && (
          <motion.div
            initial={{ opacity: 0, y: '-20%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '-20%' }}
            className={styles.modalOverlay}
          >
            <motion.div
              ref={modalRef}
              className={styles.modalContent}
            >
              <div className={styles.modalHeader}>
                <h3 className={styles.modalTitle}>نمودار ساعات کاری</h3>
                <button
                  onClick={() => setIsChartOpen(false)}
                  className={styles.modalCloseButton}
                  aria-label="بستن"
                >
                  <FiX className={styles.modalCloseIcon} />
                </button>
              </div>
              <div className={styles.modalBody}>
                <WorkingHoursChart data={datas} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0, y: '-20%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '-20%' }}
            className={styles.modalOverlay}
          >
            <motion.div
              ref={modalRef}
              className={styles.modalContent}
            >
              <div className={styles.modalHeader}>
                <h3 className={styles.modalTitle}>افزودن ساعت کاری جدید</h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className={styles.modalCloseButton}
                  aria-label="بستن"
                >
                  <FiX className={styles.modalCloseIcon} />
                </button>
              </div>
              <div className={styles.modalBody}>
                <div className={styles.inputContainer}>
                  <label htmlFor="startTime" className={styles.inputLabel}>زمان شروع</label>
                  <DatePicker
                    inputClass={styles.timeInput}
                    value={time1}
                    onChange={(date) => setTime1(date)}
                    format="HH:mm"
                    disableDayPicker
                    plugins={[<TimePicker hideSeconds position="bottom" />]}
                  />
                </div>
                <div className={styles.inputContainer}>
                  <label htmlFor="endTime" className={styles.inputLabel}>زمان پایان</label>
                  <DatePicker
                    id="endTime"
                    inputClass={styles.timeInput}
                    value={time2}
                    onChange={(date) => setTime2(date)}
                    format="HH:mm"
                    disableDayPicker
                    plugins={[<TimePicker hideSeconds position="bottom" />]}
                  />
                </div>
              </div>
              <div className={styles.modalFooter}>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className={styles.cancelButton}
                  aria-label="لغو"
                >
                  لغو
                </button>
                <button
                  onClick={saveHoliday}
                  className={styles.saveButton}
                  aria-label="ذخیره نوبت"
                  disabled={loading}
                >
                  ذخیره
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}