import { AnimatePresence, motion } from 'framer-motion';
import moment from 'moment-jalaali';
import { useEffect, useState } from 'react';
import {
    FiEdit2,
    FiPhone,
    FiPlus,
    FiUser,
    FiUserCheck,
    FiUserMinus,
    FiUserPlus,
    FiX
} from 'react-icons/fi';
import Swal from 'sweetalert2';

// Configure moment-jalaali for Persian calendar
moment.loadPersian({ dialect: 'persian-modern', usePersianDigits: true });

export default function GetAllUsers({ token }) {
  const [actionModal, setActionModal] = useState({ show: false, userId: null, userName: '', userData: null });
  const [filterModal, setFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    name: '',
    phone: '',
    role: 'all',
    status: 'all',
    isBanned: 'all',
  });
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch users from API
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+'/user', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) throw new Error('خطا در دریافت کاربران');
        const data = await response.json();
        const mappedUsers = data.users.map((user) => ({
          id: user._id,
          name: user.name,
          phone: String(user.phone),
          joinDate: moment(user.created_at).format('jYYYY/jMM/jDD'),
          role: user.role || 'کاربر',
          status: user.isActive ? 'فعال' : 'غیرفعال',
          isBanned: user.isBanned || false,
          isBarber: user.isbarber,
        }));
        setUsers(mappedUsers);
        setFilteredUsers(mappedUsers);
      } catch (err) {
        showError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, [token]);

  // Filter users
  useEffect(() => {
    let result = [...users];
    if (filters.name) {
      result = result.filter((user) =>
        user.name.toLowerCase().includes(filters.name.toLowerCase())
      );
    }
    if (filters.phone) {
      result = result.filter((user) =>
        user.phone.replace('-', '').includes(filters.phone.replace('-', ''))
      );
    }
    if (filters.role !== 'all') {
      result = result.filter((user) => user.role === filters.role);
    }
    if (filters.status !== 'all') {
      result = result.filter((user) => user.status === filters.status);
    }
    if (filters.isBanned !== 'all') {
      result = result.filter((user) => user.isBanned === (filters.isBanned === 'true'));
    }
    setFilteredUsers(result);
  }, [filters, users]);

  // Show success message
  const showSuccess = (message) => {
    Swal.fire({
      title: 'موفقیت!',
      text: message,
      icon: 'success',
      confirmButtonText: 'باشه',
      confirmButtonColor: '#3b82f6',
    });
  };

  // Show error message
  const showError = (message) => {
    Swal.fire({
      title: 'خطا!',
      text: message,
      icon: 'error',
      confirmButtonText: 'متوجه شدم',
      confirmButtonColor: '#ef4444',
    });
  };

  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // Reset filters
  const resetFilters = () => {
    setFilters({ name: '', phone: '', role: 'all', status: 'all', isBanned: 'all' });
    setFilterModal(false);
  };

  // Action handlers with confirmation dialogs
  const handleEditRole = async (userId, userName) => {
    const { value: role } = await Swal.fire({
      title: 'تغییر رول کاربر',
      text: `آیا می‌خواهید رول کاربر "${userName}" را تغییر دهید؟`,
      icon: 'question',
      input: 'select',
      inputOptions: {
        'user': 'کاربر عادی',
        'admin': 'مدیر سیستم',
        'barber': 'آرایشگر'
      },
      inputPlaceholder: 'رول جدید را انتخاب کنید',
      showCancelButton: true,
      confirmButtonText: 'تغییر رول',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#3b82f6',
      cancelButtonColor: '#ef4444',
    });

    if (role) {
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/user/role/${userId}`, {
          method: 'PUT',
          headers: { 
            Authorization: `Bearer ${token}`, 
            'Content-Type': 'application/json' 
          },
          body: JSON.stringify({ role }),
        });
        
        if (!response.ok) throw new Error('خطا در تغییر رول');
        
        const updatedUser = await response.json();
        setUsers((prev) =>
          prev.map((user) =>
            user.id === userId ? { ...user, role: updatedUser.role || role } : user
          )
        );
        showSuccess('رول کاربر با موفقیت تغییر کرد');
      } catch (err) {
        showError(err.message);
      }
    }
  };

  const handleBan = async (userId, userName) => {
    const { isConfirmed } = await Swal.fire({
      title: 'بن کردن کاربر',
      text: `آیا مطمئنید می‌خواهید کاربر "${userName}" را بن کنید؟`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'بله، بن کن',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
    });

    if (isConfirmed) {
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/user/ban/${userId}`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        
        if (!response.ok) throw new Error('خطا در بن کردن کاربر');
        
        setUsers((prev) =>
          prev.map((user) =>
            user.id === userId ? { ...user, isBanned: true } : user
          )
        );
        showSuccess('کاربر با موفقیت بن شد');
      } catch (err) {
        showError(err.message);
      }
    }
  };

  const handleisbarber= async (userId, userName) => {
    const { isConfirmed } = await Swal.fire({
      title: 'فعال سازی',
      text: `آیا مطمئنید می‌خواهید کاربر "${userName}" را اگر آرایشگر هست فعال یا غیرفعال کنید؟`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'بله',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
    });

    if (isConfirmed) {
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/user/barber/${userId}`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        
        if (!response.ok) throw new Error('خطا    ');
        
        setUsers((prev) =>
          prev.map((user) =>
            user.id === userId ? { ...user, isBanned: true } : user
          )
        );
        showSuccess('علملیات با موفقیت انجام شد');
      } catch (err) {
        showError(err.message);
      }
    }
  };

  const handleDelete = async (userId, userName) => {
    const { isConfirmed } = await Swal.fire({
      title: 'حذف کاربر',
      text: `آیا مطمئنید می‌خواهید کاربر "${userName}" را حذف کنید؟ این عمل غیرقابل برگشت است!`,
      icon: 'error',
      showCancelButton: true,
      confirmButtonText: 'بله، حذف کن',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
    });

    if (isConfirmed) {
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/user/delete/${userId}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
        
        if (!response.ok) throw new Error('خطا در حذف کاربر');
        
        setUsers((prev) => prev.filter((user) => user.id !== userId));
        showSuccess('کاربر با موفقیت حذف شد');
      } catch (err) {
        showError(err.message);
      }
    }
  };

  const handleActivateBarber = async (userId, userName) => {
    const { isConfirmed } = await Swal.fire({
      title: 'فعال‌سازی آرایشگری',
      text: `آیا می‌خواهید کاربر "${userName}" را به عنوان آرایشگر فعال کنید؟`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'بله، فعال کن',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#6b7280',
    });

    if (isConfirmed) {
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/user/barber/${userId}`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        
        if (!response.ok) throw new Error('خطا در فعال‌سازی آرایشگری');
        
        setUsers((prev) =>
          prev.map((user) =>
            user.id === userId ? { ...user, isBarber: true } : user
          )
        );
        showSuccess('کاربر با موفقیت به عنوان آرایشگر فعال شد');
      } catch (err) {
        showError(err.message);
      }
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        when: "beforeChildren"
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    },
    hover: {
      scale: 1.02,
      boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
      transition: {
        duration: 0.2
      }
    }
  };

  const modalVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    },
    exit: { opacity: 0, scale: 0.95 }
  };

  return (
    <div className="space-y-6 p-4">

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow p-4 border-l-4 border-blue-500">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm">کل کاربران</h3>
          <p className="text-2xl font-bold">{users.length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow p-4 border-l-4 border-green-500">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm">کاربران فعال</h3>
          <p className="text-2xl font-bold">{users.filter(u => u.status === 'فعال').length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow p-4 border-l-4 border-red-500">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm">کاربران بن شده</h3>
          <p className="text-2xl font-bold">{users.filter(u => u.isBanned).length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow p-4 border-l-4 border-purple-500">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm">آرایشگران</h3>
          <p className="text-2xl font-bold">{users.filter(u => u.isBarber).length}</p>
        </div>
      </div>

      {/* Users List */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {filteredUsers.length === 0 ? (
          <div className="col-span-full text-center py-10 text-gray-500 dark:text-gray-400">
            {loading ? 'در حال دریافت کاربران...' : 'هیچ کاربری یافت نشد'}
          </div>
        ) : (
          filteredUsers.map((user) => (
            <motion.div
              key={user.id}
              variants={itemVariants}
              whileHover="hover"
              className="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden border border-gray-100 dark:border-gray-700"
            >
              <div className="p-4 flex items-start gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white ${
                  user.isBanned ? 'bg-red-500' : 
                  user.isBarber ? 'bg-purple-500' : 
                  user.role === 'مدیر' ? 'bg-blue-500' : 'bg-gray-500'
                }`}>
                  <FiUser className="text-xl" />
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold text-lg">{user.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      user.status === 'فعال' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 
                      'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    }`}>
                      {user.status}
                    </span>
                  </div>
                  
                  <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                    <FiPhone className="inline ml-1" />
                    {user.phone}
                  </p>
                  
                  <div className="flex flex-wrap gap-1 mt-2">
                    <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full">
                      {user.role}
                    </span>
                    {user.isBarber && (
                      <span className="text-xs px-2 py-1 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 rounded-full">
                        آرایشگر
                      </span>
                    )}
                    {user.isBanned && (
                      <span className="text-xs px-2 py-1 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 rounded-full">
                        بن شده
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-100 dark:border-gray-700 px-4 py-3 flex justify-between items-center">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  عضویت: {user.joinDate}
                </span>
                
                <div className="flex gap-2">
                  <button
                    onClick={() => setActionModal({ show: true, userId: user.id, userName: user.name, userData: user })}
                    className="p-2 text-gray-500 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                    title="مدیریت کاربر"
                  >
                    <FiEdit2 />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </motion.div>


      {/* Action Modal */}
      <AnimatePresence>
        {actionModal.show && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg w-full max-w-md"
            >
              <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                <h3 className="font-semibold text-lg">مدیریت کاربر: {actionModal.userName}</h3>
                <button
                  onClick={() => setActionModal({ show: false, userId: null, userName: '', userData: null })}
                  className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <FiX className="text-xl" />
                </button>
              </div>
              
              <div className="p-4 space-y-4">
                <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <FiUser className="text-gray-500 dark:text-gray-400" />
                  <span className="text-sm">{actionModal.userData?.phone}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handleEditRole(actionModal.userId, actionModal.userName)}
                    className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-800 transition-colors"
                  >
                    <FiUserPlus />
                    <span>تغییر نقش</span>
                  </button>
                  
                  {actionModal.userData?.isbarber ? (
                    <button
                      onClick={() => handleisbarber(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900 text-green-600 dark:text-green-300 rounded-lg hover:bg-green-100 dark:hover:bg-green-800 transition-colors"
                    >
                      <FiUserCheck />
                      <span>غیرفعالساز آرایشگری</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleisbarber(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900 text-yellow-600 dark:text-yellow-300 rounded-lg hover:bg-yellow-100 dark:hover:bg-yellow-800 transition-colors"
                    >
                      <FiUserMinus />
                      <span> فعالسازی آرایشگری</span>
                    </button>
                  )}
                    {actionModal.userData?.ban ? (
                    <button
                      onClick={() => handleBan(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-300 rounded-lg hover:bg-green-100 dark:hover:bg-green-800 transition-colors"
                    >
                      <FiUserCheck />
                      <span>رفع بن</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBan(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-yellow-50 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-300 rounded-lg hover:bg-yellow-100 dark:hover:bg-yellow-800 transition-colors"
                    >
                      <FiUserMinus />
                      <span>بن کاربر</span>
                    </button>
                  )}

                  {!actionModal.userData?.role =="ADMIN" && (
                    <button
                      onClick={() => handleActivateBarber(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-purple-50 dark:bg-purple-900 text-purple-600 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-800 transition-colors"
                    >
                      <FiPlus />
                      <span>آرایشگر</span>
                    </button>
                  )}
                  {!actionModal.userData?.role =="ADMINPRO" && (
                    <button
                      onClick={() => handleActivateBarber(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-purple-50 dark:bg-purple-900 text-purple-600 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-800 transition-colors"
                    >
                      <FiPlus />
                      <span>مدیر</span>
                    </button>
                  )}
                  {!actionModal.userData?.role =="USER" && (
                    <button
                      onClick={() => handleActivateBarber(actionModal.userId, actionModal.userName)}
                      className="flex items-center gap-2 p-3 bg-purple-50 dark:bg-purple-900 text-purple-600 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-800 transition-colors"
                    >
                      <FiPlus />
                      <span>مشتری</span>
                    </button>
                  )}
                
                </div>
              </div>
              
              <div className="p-4 border-t dark:border-gray-700 flex justify-end">
                <a
                  href={`tel:${actionModal.userData?.phone}`}
                  className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white hover:bg-green-600 rounded-lg"
                >
                  <FiPhone />
                  <span>تماس با کاربر</span>
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
}