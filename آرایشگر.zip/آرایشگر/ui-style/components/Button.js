const Button = ({ children, type = 'button', disabled = false, fullWidth = false, onClick }) => {
    return (
      <button
        type={type}
        disabled={disabled}
        onClick={onClick}
        className={`py-3 px-6 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors ${
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        } ${fullWidth ? 'w-full' : ''}`}
      >
        {children}
      </button>
    );
  };
  
  export default Button;