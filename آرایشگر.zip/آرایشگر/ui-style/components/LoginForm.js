import { useRouter } from 'next/router';
import { useState } from 'react';
import { FiLock, FiPhone } from 'react-icons/fi';
import Button from './Button';
import InputField from './InputField';
import PasswordInput from './PasswordInput';

const LoginForm = () => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const validateForm = () => {
    const newErrors = {};
    
    if (!phone.trim()) {
      newErrors.phone = 'شماره تلفن الزامی است';
    } else if (!/^09\d{9}$/.test(phone)) {
      newErrors.phone = 'شماره تلفن معتبر نیست';
    }
    
    if (!password.trim()) {
      newErrors.password = 'رمز عبور الزامی است';
    } else if (password.length < 6) {
      newErrors.password = 'رمز عبور باید حداقل ۶ کاراکتر باشد';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    try {
      // شبیه‌سازی درخواست به API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // در حالت واقعی، پاسخ API را بررسی می‌کنیم
      router.push('/dashboard');
    } catch (error) {
      setErrors({ submit: 'خطا در ورود. لطفا مجددا تلاش کنید.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      {errors.submit && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-sm">
          {errors.submit}
        </div>
      )}
      
      <InputField
        icon={<FiPhone />}
        type="tel"
        placeholder="شماره تلفن"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        error={errors.phone}
      />
      
      <PasswordInput
        icon={<FiLock />}
        placeholder="رمز عبور"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        error={errors.password}
      />
      
      <div className="mt-6">
        <Button type="submit" disabled={isLoading} fullWidth>
          {isLoading ? 'در حال ورود...' : 'ورود'}
        </Button>
      </div>
    </form>
  );
};

export default LoginForm;