import BarberList from "@/mini-components/BarberList";
import Datepicker from "@/mini-components/Datepicker";
import ProgressSteps from "@/mini-components/ProgressTracker";
import ServiceList from "@/mini-components/ServiceList";
import WorkHours from "@/mini-components/WorkHours";
import axios from "axios";
import { useState } from "react";
import { FiAlertTriangle } from "react-icons/fi";
import Swal from "sweetalert2";
import styles from './style.module.css';

export default function New({token,numberme}) {
    const [selectedBarberId, setSelectedBarberId] = useState(null);
    const [selectedServiceId, setSelectedServiceId] = useState(null);
    const [selectedDateId, setSelectedDateId] = useState(null);
    const [selectedHoursId, setSelectedHoursId] = useState(null);
    const [num ,setNum]=useState(numberme)

    const handleSelectBarber = (id) => {
      setSelectedBarberId(id);

      setNum(1)
    };
    const handleSelectService = (id) => {
        setSelectedServiceId(id);
        setNum(2)
      };
      const handleSelectDate = (id) => {
        setSelectedDateId(id);
        setNum(3)
      };
      const handleSelectHours = (id) => {
        setSelectedHoursId(id);
        setNum(4)
      };
      function handleNext(){
    //////////////////////////////////////////////////////////////////////////////////////////////////////////start
    const data = {
      provider_id:selectedBarberId,
      service_id:selectedServiceId,
      date_id:selectedDateId,
      workingHour_id:selectedHoursId
    };
    
    const config = {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
    
    axios.post(process.env.NEXT_PUBLIC_APIURL+"/reservation/new", data, config)
      .then(response => {
        console.log(response.status)
        if(response.status==201){
          Swal.fire({
            title: "با موفقیت ثبت شد",
            icon: "success"
          });
          setSelectedBarberId(null);
          setSelectedServiceId(null);
          setSelectedDateId(null);
          setSelectedHoursId(null);
          setNum(0)
        }else{
          Swal.fire({
            title: "خطا در ثبت",
            icon: "error",
            text:response?.message 
          });
          console.log(response.status==200)
        }
      })
      .catch(error => {
        console.log(error)
        Swal.fire({
          title: "خطا در ثبت",
          icon: "error",
          text:error?.response?.data?.message || "نامشخص"
        });
      });
      //////////////////////////////////////////////////////////////////////////////////////////////////////end
      }
      function handleBack(){
      setSelectedBarberId(null);
      setSelectedServiceId(null);
      setSelectedDateId(null);
      setSelectedHoursId(null);
      setNum(0)
    }
  return (
    <>
    <div style={{direction:"ltr"}}>
      <ProgressSteps totalSteps={5} completedSteps={num} />      
    </div>
    {num == 0 ? <>
        <BarberList token={token} onSelectBarber={handleSelectBarber} />
    </>: num==1?<>
        <ServiceList token={token}  onSelectService={handleSelectService}/>
    </>:num==2?<>
        <Datepicker token={token} onSelectDate={handleSelectDate} />
    </>:num==3?<>
        <WorkHours token={token} onSelectHours={handleSelectHours} selectedDateId={selectedDateId} selectedBarberId={selectedBarberId}/>
    </>:num==4?<>
          <span>{`${"امیر"} عزیز آیا از رزرو نوبت مطمعن هستید؟`}</span>
          <div className={styles.next} onClick={handleNext}>تایید رزرو</div>
          <div className={styles.back} onClick={handleBack}>خیر </div>
    <div style={{height:"48px",display:'flex',justifyContent:'center',marginBottom:'12px',marginTop:'220px',backgroundColor:'#fff'}} className="flex items-center gap-3 p-4 rounded-2xl border border-red-300 bg-red-50 text-red-700 shadow-md animate-fade-in">
      <FiAlertTriangle className="text-red-600 text-2xl animate-pulse" />
      <span className="font-semibold text-sm sm:text-base">پس از رزرو نوبت امکان لغو وجود ندارد!</span>
    </div>
      
    </>:<>
    
    </> }
    
    </>
  )
}
