'use client';
import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import {
    FiCheckCircle,
    FiClock, FiDollarSign,
    FiPlus,
    FiScissors,
    FiTrash2,
    FiXCircle
} from 'react-icons/fi';
import styles from './Services.module.css';

const Services = ({ token }) => {
  const [services, setServices] = useState([]);
  const [filteredServices, setFilteredServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [filters, setFilters] = useState({
    search: '',
    isActive: 'all',
    sortBy: 'title'
  });
  const [newService, setNewService] = useState({
    title: '',
    description: '',
    price: '',
    minute: '',
    is_active: true
  });

  // دریافت سرویس‌ها از API
  const fetchServices = async () => {
    try {
      setLoading(true);
      const response = await axios.get(process.env.NEXT_PUBLIC_APIURL+'/services/', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setServices(response.data.Services);
      setFilteredServices(response.data.Services);
    } catch (err) {
      setError('خطا در دریافت سرویس‌ها');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // اعمال فیلترها
  const applyFilters = () => {
    let result = [...services];
    
    // فیلتر بر اساس جستجو
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      result = result.filter(service => 
        service.title.toLowerCase().includes(searchTerm) || 
        service.description.toLowerCase().includes(searchTerm)
      );
    }
    
    // فیلتر بر اساس وضعیت فعال بودن
    if (filters.isActive !== 'all') {
      const isActive = filters.isActive === 'active';
      result = result.filter(service => service.is_active === isActive);
    }
    
    // مرتب‌سازی
    result.sort((a, b) => {
      if (filters.sortBy === 'title') {
        return a.title.localeCompare(b.title);
      } else if (filters.sortBy === 'price') {
        return a.price - b.price;
      } else if (filters.sortBy === 'duration') {
        return a.minute - b.minute;
      }
      return 0;
    });
    
    setFilteredServices(result);
  };

  // حذف سرویس
  const deleteService = async () => {
    try {
      setLoading(true);
      await axios.delete(
        process.env.NEXT_PUBLIC_APIURL+`/services/delete/${selectedService._id}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      fetchServices();
      setIsDeleteConfirmOpen(false);
      setSelectedService(null);
    } catch (err) {
      setError('خطا در حذف سرویس');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // ثبت سرویس جدید
  const saveService = async () => {
    try {
      setLoading(true);
      await axios.post(
        process.env.NEXT_PUBLIC_APIURL+'/services/new',
        {
          title: newService.title,
          description: newService.description,
          price: parseInt(newService.price),
          minute: parseInt(newService.minute),
          is_active: newService.is_active
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      fetchServices();
      setIsModalOpen(false);
      setNewService({
        title: '',
        description: '',
        price: '',
        minute: '',
        is_active: true
      });
    } catch (err) {
      setError('خطا در ثبت سرویس');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // فرمت قیمت به ریال
  const formatPrice = (price) => {
    return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
  };

  useEffect(() => {
    fetchServices();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [filters, services]);

  return (
    <div className={styles.container}>
      {/* هدر صفحه */}
      <div className={styles.header}>

        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsModalOpen(true)}
          className={styles.addButton}
        >
          <FiPlus className={styles.addIcon} />
          افزودن سرویس جدید
        </motion.button>
      </div>



      {/* محتوای اصلی */}
      <div className={styles.content}>
        {/* حالت لودینگ */}
        {loading && (
          <div className={styles.loadingState}>
            <div className={styles.loadingSpinner} />
            <p>در حال دریافت سرویس‌ها...</p>
          </div>
        )}

        {/* حالت خطا */}
        {error && !loading && (
          <div className={styles.errorState}>
            <FiXCircle className={styles.errorIcon} />
            <p>{error}</p>
            <button 
              onClick={fetchServices}
              className={styles.retryButton}
            >
              تلاش مجدد
            </button>
          </div>
        )}

        {/* حالت خالی */}
        {!loading && !error && filteredServices.length === 0 && (
          <div className={styles.emptyState}>
            <FiScissors className={styles.emptyIcon} />
            <h3>سرویسی یافت نشد</h3>
            <p>با تغییر فیلترها دوباره امتحان کنید یا سرویس جدید اضافه کنید</p>
          </div>
        )}

        {/* لیست سرویس‌ها */}
        {!loading && !error && filteredServices.length > 0 && (
          <div className={styles.servicesGrid}>
            {filteredServices.map(service => (
              <motion.div
                key={service._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02 }}
                className={`${styles.serviceCard} ${!service.is_active ? styles.inactive : ''}`}
              >
                <div className={styles.serviceHeader}>
                  <h3 className={styles.serviceTitle}>{service.title}</h3>
                  <div className={styles.serviceStatus}>
                    {service.is_active ? (
                      <FiCheckCircle className={styles.activeIcon} />
                    ) : (
                      <FiXCircle className={styles.inactiveIcon} />
                    )}
                  </div>
                </div>
                
                <p className={styles.serviceDescription}>{service.description}</p>
                
                <div className={styles.serviceDetails}>
                  <div className={styles.detailItem}>
                    <FiDollarSign className={styles.detailIcon} />
                    <span>{formatPrice(service.price)}</span>
                  </div>
                  
                  <div className={styles.detailItem}>
                    <FiClock className={styles.detailIcon} />
                    <span>{service.minute} دقیقه</span>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      setSelectedService(service);
                      setIsDeleteConfirmOpen(true);
                    }}
                    className={styles.deleteButton}
                    aria-label={`حذف ${service.title}`}
                  >
                    <FiTrash2 className={styles.actionIcon} />
                  </motion.button>
                </div>
                
                <div className={styles.serviceActions}>

                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* مودال افزودن سرویس جدید */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={styles.modalOverlay}
          >
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className={styles.modal}
            >
              <div className={styles.modalHeader}>
                <h2>افزودن سرویس جدید</h2>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className={styles.closeModal}
                >
                  <FiXCircle />
                </button>
              </div>

              <div className={styles.modalBody}>
                <div className={styles.formGroup}>
                  <label htmlFor="title">عنوان سرویس*</label>
                  <input
                    id="title"
                    type="text"
                    value={newService.title}
                    onChange={(e) => setNewService({...newService, title: e.target.value})}
                    placeholder="مثال: اصلاح کامل"
                    required
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="description">توضیحات</label>
                  <textarea
                    id="description"
                    value={newService.description}
                    onChange={(e) => setNewService({...newService, description: e.target.value})}
                    placeholder="توضیحات کامل سرویس..."
                    rows={3}
                  />
                </div>

                <div className={styles.formRow}>
                  <div className={styles.formGroup}>
                    <label htmlFor="price">قیمت (تومان)*</label>
                    <input
                      id="price"
                      type="number"
                      value={newService.price}
                      onChange={(e) => setNewService({...newService, price: e.target.value})}
                      placeholder="مثال: 230000"
                      required
                    />
                  </div>

                  <div className={styles.formGroup}>
                    <label htmlFor="minute">مدت زمان (دقیقه)*</label>
                    <input
                      id="minute"
                      type="number"
                      value={newService.minute}
                      onChange={(e) => setNewService({...newService, minute: e.target.value})}
                      placeholder="مثال: 60"
                      required
                    />
                  </div>
                </div>

                <div className={styles.formGroup}>
                </div>
              </div>

              <div className={styles.modalFooter}>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setIsModalOpen(false)}
                  className={styles.cancelButton}
                >
                  انصراف
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={saveService}
                  className={styles.saveButton}
                  disabled={!newService.title || !newService.price || !newService.minute}
                >
                  ذخیره سرویس
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* تاییدیه حذف */}
      <AnimatePresence>
        {isDeleteConfirmOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={styles.confirmOverlay}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className={styles.confirmModal}
            >
              <FiScissors className={styles.confirmIcon} />
              <h3>آیا از حذف این سرویس مطمئن هستید؟</h3>
              <p>{selectedService?.title} - {formatPrice(selectedService?.price)}</p>
              
              <div className={styles.confirmButtons}>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setIsDeleteConfirmOpen(false)}
                  className={styles.cancelButton}
                >
                  انصراف
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={deleteService}
                  className={styles.deleteButton}
                >
                  حذف سرویس
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Services;