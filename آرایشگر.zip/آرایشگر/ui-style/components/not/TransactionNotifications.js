'use client';
import axios from 'axios';
import { motion } from 'framer-motion';
import moment from 'moment-jalaali';
import { useEffect, useState } from 'react';
import { FiBell, FiClock } from 'react-icons/fi';
import styles from './TransactionNotifications.module.css';

const TransactionNotifications = ({ token }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // دریافت اعلان‌های تراکنش از API
  const fetchTransactionNotifications = async () => {
    try {
      setLoading(true);
      const response = await axios.get(process.env.NEXT_PUBLIC_APIURL+'/not/free4/', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
      const sortedData = response.data.nots.sort((a, b) => 
        new Date(b.createdAt) - new Date(a.createdAt)
      );
      
      setNotifications(sortedData);
    } catch (err) {
      setError('خطا در دریافت اعلان‌های تراکنش');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // تبدیل تاریخ به شمسی
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const jalaliDate = moment(date).format('jYYYY/jMM/jDD - HH:mm');
    return jalaliDate;
  };

  useEffect(() => {
    fetchTransactionNotifications();
  }, []);

  return (
    <div className={styles.container}>
      {/* هدر صفحه */}
      <div className={styles.header}>
        <div className={styles.headerTitle}>
          <FiBell className={styles.headerIcon} />
          <h1>اعلان‌های تراکنش</h1>
        </div>
      </div>

      {/* محتوای اصلی */}
      <div className={styles.content}>
        {/* حالت لودینگ */}
        {loading && (
          <div className={styles.loadingState}>
            <div className={styles.loadingSpinner} />
            <p>در حال دریافت اعلان‌های تراکنش...</p>
          </div>
        )}

        {/* حالت خطا */}
        {error && !loading && (
          <div className={styles.errorState}>
            <FiBell className={styles.errorIcon} />
            <p>{error}</p>
            <button 
              onClick={fetchTransactionNotifications}
              className={styles.retryButton}
            >
              تلاش مجدد
            </button>
          </div>
        )}

        {/* حالت خالی */}
        {!loading && !error && notifications.length === 0 && (
          <div className={styles.emptyState}>
            <FiBell className={styles.emptyIcon} />
            <h3>اعلانی یافت نشد</h3>
            <p>در حال حاضر هیچ اعلان تراکنشی وجود ندارد</p>
          </div>
        )}

        {/* لیست اعلان‌ها */}
        {!loading && !error && notifications.length > 0 && (
          <div className={styles.notificationsList}>
            {notifications.map(notification => (
              <motion.div
                key={notification._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.01 }}
                className={styles.notificationCard}
                style={{
                  borderRight: `4px solid #64748b`
                }}
              >
                <div className={styles.notificationHeader}>
                  <div className={styles.importanceIcon}>
                    <FiBell />
                  </div>
                  <h3 className={styles.notificationTitle}>{notification.title}</h3>
                </div>
                
                <p className={styles.notificationText}>{notification.text}</p>
                
                <div className={styles.notificationFooter}>
                  <div className={styles.notificationDate}>
                    <FiClock className={styles.dateIcon} />
                    <span>{formatDate(notification.createdAt)}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionNotifications;