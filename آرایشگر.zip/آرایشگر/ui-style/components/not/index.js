'use client';
import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import moment from 'moment-jalaali';
import { useEffect, useState } from 'react';
import {
  FiAlertTriangle,
  FiBell,
  FiClock,
  FiFilter,
  FiInfo,
  FiSearch,
  FiStar
} from 'react-icons/fi';
import styles from './Notifications.module.css';

const Notifications = ({ token, me }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [filters, setFilters] = useState({
    title: '',
    phone: '',
    importance: '',
    limit: 10,
  });

  // بررسی آیا کاربر ADMINPRO است
  const isAdminPro = me?.role === 'ADMINPRO';

  // دریافت اعلان‌ها از API با توجه به نقش کاربر
  const fetchNotifications = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log(`${process.env.NEXT_PUBLIC_APIURL}/not/free`)
      const endpoint = isAdminPro 
        ? `${process.env.NEXT_PUBLIC_APIURL}/not/` 
        : `${process.env.NEXT_PUBLIC_APIURL}/not/free`;
      
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };

      // فقط برای ADMINPRO فیلترها را ارسال می‌کنیم
      const data = isAdminPro ? filters : {};
      
      const response = await axios.post(endpoint, data, config);
      
      setNotifications(response.data.nots || response.data);
    } catch (err) {
      setError('خطا در دریافت اعلان‌ها');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // اعمال فیلترها (فقط برای ADMINPRO)
  const applyFilters = () => {
    if (!isAdminPro) return;
    fetchNotifications();
    setFilterOpen(false);
  };

  // بازنشانی فیلترها (فقط برای ADMINPRO)
  const resetFilters = () => {
    if (!isAdminPro) return;
    const defaultFilters = {
      title: '',
      phone: '',
      importance: '',
      limit: 10,
    };
    setFilters(defaultFilters);
    fetchNotifications();
    setFilterOpen(false);
  };

  // تبدیل تاریخ به شمسی
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const jalaliDate = moment(date).format('jYYYY/jMM/jDD - HH:mm');
    return jalaliDate;
  };

  // رنگ بر اساس اهمیت
  const getImportanceColor = (importance) => {
    switch(importance) {
      case 1: return '#ef4444'; // قرمز - مهم
      case 2: return '#f59e0b'; // نارنجی - متوسط
      case 3: return '#3b82f6'; // آبی - عادی
      default: return '#64748b'; // خاکستری - نامشخص
    }
  };

  // آیکون بر اساس اهمیت
  const getImportanceIcon = (importance) => {
    switch(importance) {
      case 1: return <FiAlertTriangle />; // مهم
      case 2: return <FiStar />; // متوسط
      case 3: return <FiInfo />; // عادی
      default: return <FiBell />; // پیش‌فرض
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  return (
    <div className={styles.container}>
      {/* هدر صفحه */}
      <div className={styles.header}>
        <div className={styles.headerTitle}>
          <FiBell className={styles.headerIcon} />
          <h1>اعلان‌های سیستم</h1>
        </div>
        
        {/* دکمه فیلتر فقط برای ADMINPRO نمایش داده می‌شود */}
        {isAdminPro && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setFilterOpen(!filterOpen)}
            className={styles.filterButton}
          >
            <FiFilter className={styles.filterIcon} />
            فیلترها
          </motion.button>
        )}
      </div>

      {/* پنل فیلترها فقط برای ADMINPRO */}
      <AnimatePresence>
        {isAdminPro && filterOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={styles.filterPanel}
          >
            <div className={styles.filterGroup}>
              <label htmlFor="title">عنوان:</label>
              <div className={styles.searchInput}>
                <FiSearch className={styles.searchIcon} />
                <input
                  id="title"
                  type="text"
                  placeholder="جستجو بر اساس عنوان..."
                  value={filters.title}
                  onChange={(e) => setFilters({...filters, title: e.target.value})}
                />
              </div>
            </div>

            <div className={styles.filterGroup}>
              <label htmlFor="phone">شماره کاربر:</label>
              <input
                id="phone"
                type="text"
                placeholder="جستجو بر اساس شماره کاربر..."
                value={filters.phone}
                onChange={(e) => setFilters({...filters, phone: e.target.value})}
              />
            </div>

            <div className={styles.filterGroup}>
              <label htmlFor="importance">اهمیت:</label>
              <select
                id="importance"
                value={filters.importance}
                onChange={(e) => setFilters({...filters, importance: e.target.value})}
              >
                <option value="">همه</option>
                <option value="1">مهم (1)</option>
                <option value="2">متوسط (2)</option>
                <option value="3">عادی (3)</option>
              </select>
            </div>

            <div className={styles.filterGroup}>
              <label htmlFor="limit">تعداد نمایش:</label>
              <select
                id="limit"
                value={filters.limit}
                onChange={(e) => setFilters({...filters, limit: e.target.value})}
              >
                <option value="5">5 مورد</option>
                <option value="10">10 مورد</option>
                <option value="20">20 مورد</option>
                <option value="50">50 مورد</option>
                <option value="100">100 مورد</option>
              </select>
            </div>

            <div className={styles.filterActions}>
              <button 
                onClick={applyFilters}
                className={styles.applyButton}
              >
                اعمال فیلترها
              </button>
              <button 
                onClick={resetFilters}
                className={styles.resetButton}
              >
                بازنشانی
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* محتوای اصلی */}
      <div className={styles.content}>
        {/* حالت لودینگ */}
        {loading && (
          <div className={styles.loadingState}>
            <div className={styles.loadingSpinner} />
            <p>در حال دریافت اعلان‌ها...</p>
          </div>
        )}

        {/* حالت خطا */}
        {error && !loading && (
          <div className={styles.errorState}>
            <FiAlertTriangle className={styles.errorIcon} />
            <p>{error}</p>
            <button 
              onClick={fetchNotifications}
              className={styles.retryButton}
            >
              تلاش مجدد
            </button>
          </div>
        )}

        {/* حالت خالی */}
        {!loading && !error && notifications.length === 0 && (
          <div className={styles.emptyState}>
            <FiBell className={styles.emptyIcon} />
            <h3>اعلانی یافت نشد</h3>
            {isAdminPro && <p>با تغییر فیلترها دوباره امتحان کنید</p>}
          </div>
        )}

        {/* لیست اعلان‌ها */}
        {!loading && !error && notifications.length > 0 && (
          <div className={styles.notificationsList}>
            {notifications.map(notification => (
              <motion.div
                key={notification._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.01 }}
                className={styles.notificationCard}
                style={{
                  borderRight: `4px solid ${getImportanceColor(notification.importance)}`
                }}
              >
                <div className={styles.notificationHeader}>
                  <div className={styles.importanceIcon} style={{
                    color: getImportanceColor(notification.importance)
                  }}>
                    {getImportanceIcon(notification.importance)}
                  </div>
                  <h3 className={styles.notificationTitle}>{notification.title}</h3>
                </div>
                
                <p className={styles.notificationText}>{notification.text}</p>
                
                <div className={styles.notificationFooter}>
                  <div className={styles.notificationDate}>
                    <FiClock className={styles.dateIcon} />
                    <span>{formatDate(notification.createdAt)}</span>
                  </div>
                  {notification.userId && isAdminPro && (
                    <div className={styles.userId}>
                      <span>کاربر: {notification.userId}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;