import ReservationCard from '@/mini-components/ReservationCard';
import axios from 'axios';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import {
  FaCalendarAlt,
  FaClock,
  FaRegSmile,
  FaUsers
} from 'react-icons/fa';
import styles from './Dashboard.module.css';


const Dashboard = ({token}) => {
  const [stats, setStats] = useState({
    activeUsers: 0,
    todayReservations: 0,
    monthlyRevenue: 0,
    completionRate: 0
  });

  const [todayReservations, setTodayReservations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const fetchData = async () => {
      
    setIsLoading(true);
    const today = new Date();
    today.setDate(today.getDate()); // اضافه کردن یک روز (فردا)
    const formattedDate = today.toISOString().split('T')[0];
    // console.log(formattedDate)
    try {
      const response = await axios.get(process.env.NEXT_PUBLIC_APIURL+`/reservation/dashboard/${formattedDate}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      // console.log(response.data)
      setTodayReservations(response.data.reservations)
      setStats({
        activeUsers: response.data.sumUsers,
        todayReservations: response.data.sumReservations,
        monthlyRevenue: 0,
        completionRate: 0
      });

    } catch (err) {
      console.error(err);
    }
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    
    setIsLoading(false);
  };

  useEffect(() => {

    fetchData();
    console.log(todayReservations)
  }, []);

  return (
    <div className={styles.dashboard}>
      {/* هدر داشبورد */}
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className={styles.header}
      >
        <p>خلاصه‌ای از فعالیت‌های امروز</p>
      </motion.div>

      {/* کارت‌های آمار */}
      <div className={styles.statsContainer}>
        <motion.div 
          whileHover={{ y: -5 }}
          className={`${styles.statCard} ${styles.users}`}
        >
          <div className={styles.statIcon}>
            <FaUsers />
          </div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>کاربران فعال</span>
            <span className={styles.statValue}>
              {isLoading ? '--' : stats.activeUsers}
            </span>
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className={`${styles.statCard} ${styles.reservations}`}
        >
          <div className={styles.statIcon}>
            <FaCalendarAlt />
          </div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}> کل رزورها </span>
            <span className={styles.statValue}>
              {isLoading ? '--' : stats.todayReservations}
            </span>
          </div>
        </motion.div>
      </div>

      {/* بخش رزروهای امروز */}
      <div className={styles.reservationsSection}>
        <div className={styles.sectionHeader}>
          <h2>
            <FaClock className={styles.sectionIcon} />
            رزروهای امروز من
          </h2>
          <span className={styles.badge}>{stats.todayReservations} نوبت</span>
        </div>

        {isLoading ? (
          <div className={styles.loadingReservations}>
            <div className={styles.loadingLine} />
            <div className={styles.loadingLine} />
          </div>
        ) : todayReservations.length > 0 ? (
          <div className={styles.reservationsList}>
            {todayReservations.map(reservation => (
              <ReservationCard 
                token={token}
                key={reservation._id} 
                reservation={reservation} 
              />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={styles.emptyState}
            style={{display:"flex",flexDirection:'column',alignItems:'center'}}
            

          >
            <FaRegSmile className={styles.emptyIcon} />
            <h3 >هیچ رزروی برای امروز ندارید!</h3>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;