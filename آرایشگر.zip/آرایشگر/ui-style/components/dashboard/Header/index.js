import { FiBell, FiMenu } from 'react-icons/fi';

export default function Header({ 
  isMobile, 
  activeTab, 
  isLoading, 
  setIsMenuOpen, 
  handleTabChange ,
  me
}) {
  return (
    <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-white dark:bg-gray-800 shadow-lg">
      {me?.role!="USER" ?<>
      {isMobile && (
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label="باز کردن منو"
          disabled={isLoading}
          >
          <FiMenu className="text-2xl" />
        </button>
      )}
      </>:<>
      {isMobile && (
        <button 
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label="باز کردن منو"
          disabled={isLoading}
          >
        </button>
      )}
      </>}
      
      <h1 className="text-xl font-semibold">
        {activeTab === 'home' && 'داشبورد'}
        {activeTab === 'users' && 'کاربران'}
        {activeTab === 'reservations' && 'رزرومن'}
        {activeTab === 'days' && 'روزکاری'}
        {activeTab === 'nights' && 'ساعت کاری'}
        {activeTab === 'NEWreservations' && 'رزرو جدید'}
        {activeTab === 'leave' && 'مرخصی'}
        {activeTab === 'service' && 'خدمات'}
        {activeTab === 'not' && 'اعلان'}
        {activeTab === 'holidays' && 'تعطیلات'}
        {activeTab === 'ChargeAccount' && 'شارژ کیف'}
        {activeTab === 'ReservationsAdminTodey' && 'کل رزروها'}
        {activeTab === 'fetchTransactionNotifications' && 'تراکنش ها'}
        {activeTab === 'profile' && 'پروفایل'}
      </h1>
      
      <div className="flex items-center space-x-3 space-x-reverse">
        <button 
          onClick={() => handleTabChange('not')} 
          className="p-2 relative hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors" 
          aria-label="اعلان‌ها" 
          disabled={isLoading}
        >
          <FiBell className="text-2xl" />
          <span className="absolute top-1 left-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></span>
        </button>
      </div>
    </header>
  );
}