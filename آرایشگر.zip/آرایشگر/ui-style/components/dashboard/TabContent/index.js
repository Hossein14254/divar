import ActiveDay from '@/components/ActiveDay';
import ChargeAccount from '@/components/Charge/ChargeAccount';
import GetHolidays from '@/components/GetHolidays';
import New from '@/components/NEWreservation';
import ProfilePage from '@/components/ProfilePage';
import ReservationsAdminTodey from '@/components/ReservationsAdmin';
import ReservationsMe from '@/components/ReservationsMe';
import GetWorkingHours from '@/components/WorkingHours';
import Leave from '@/components/leave';
import Notifications from '@/components/not';
import TransactionNotifications from '@/components/not/TransactionNotifications';
import Service from '@/components/service';
import GetAllUsers from '@/components/users/GetAll-Users';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import Dashboard from '..';

// کامپوننت جدید برای نمایش دسترسی محدود
function AccessDenied() {
  const router = useRouter();

  useEffect(() => {
    // اگر کاربر لاگین نکرده باشد، به صفحه /Phone هدایت می‌شود
    const timer = setTimeout(() => {
      router.push('/Phone');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg flex flex-col items-center justify-center p-8">
      <div className="text-center">
        <div className="text-6xl mb-6">🚫</div>
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">دسترسی محدود!</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          شما مجوز دسترسی به این بخش را ندارید.
        </p>
        <div className="animate-pulse text-sm text-gray-500 dark:text-gray-400">
          در حال انتقال به صفحه اصلی...
        </div>
      </div>
    </div>
  );
}

// لیست تب‌هایی که نیاز به نقش ADMINPRO دارند
const ADMINPRO_TABS = [
  'users', 
  'days', 
  'nights', 
  'holidays', 
  'leave', 
  'service',
  'ChargeAccount'
];

// لیست تب‌هایی که نیاز به نقش ADMIN یا ADMINPRO دارند
const ADMIN_TABS = [
  'ReservationsAdminTodey'
];

export default function TabContent({ activeTab, token, me }) {
  // بررسی دسترسی
  const hasAccess = () => {
    // اگر تب مورد نظر نیاز به نقش خاصی ندارد
    if (![...ADMINPRO_TABS, ...ADMIN_TABS].includes(activeTab)) {
      return true;
    }
    
    // اگر کاربر لاگین نکرده باشد
    if (!me?.role) {
      return false;
    }
    
    // بررسی تب‌های ADMINPRO
    if (ADMINPRO_TABS.includes(activeTab)) {
      return me.role === 'ADMINPRO';
    }
    
    // بررسی تب‌های ADMIN
    if (ADMIN_TABS.includes(activeTab)) {
      return ['ADMIN', 'ADMINPRO'].includes(me.role);
    }
    
    return true;
  };
  if (!hasAccess()) {
    return <AccessDenied />;
  }

  switch (activeTab) {
    case 'users': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <GetAllUsers token={token} />
        </div>
      );
    case 'reservations': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <ReservationsMe token={token} me={me}/>
        </div>
      );
    case 'days': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <ActiveDay token={token} />      
        </div>
      );
    case 'nights': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <GetWorkingHours token={token}/>      
        </div>
      );
    case 'holidays': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <GetHolidays token={token}/>      
        </div>
      );
    case 'NEWreservations': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <New token={token} numberme={0}/>
        </div>
      );
    case 'profile': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <ProfilePage token={token} me={me}/>
        </div>
      );
    case 'leave': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <Leave token={token} />
        </div>
      );
    case 'service': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <Service token={token} numberme={0}/>
        </div>
      );
    case 'not': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <Notifications token={token}/>
        </div>
      );
    case 'ReservationsAdminTodey': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <ReservationsAdminTodey me={me} token={token}/>
        </div>
      );
    case 'fetchTransactionNotifications': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <TransactionNotifications me={me} token={token}/>
        </div>
      );
    case 'ChargeAccount': 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg text-center">
          <ChargeAccount me={me} token={token}/>
        </div>
      );
    default: 
      return (
        <div style={{minHeight:"72vh",marginBottom:'20px'}}className="bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <Dashboard token={token}/>
        </div>
      );
  }
}