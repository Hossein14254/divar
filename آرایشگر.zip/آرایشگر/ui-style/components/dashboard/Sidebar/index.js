import { useRouter } from 'next/router';
import {
    FiCalendar,
    FiHome,
    FiLogOut,
    FiMoon,
    FiSettings,
    FiSun,
    FiUsers
} from 'react-icons/fi';
  
  export default function Sidebar({ activeTab, handleTabChange, isLoading }) {
    const router = useRouter();
  
    return (
      <aside className="fixed top-0 right-0 h-full w-72 bg-white dark:bg-gray-800 shadow-2xl z-30 rounded-l-lg">
        <div className="p-4 border-b dark:border-gray-700 bg-gradient-to-b from-blue-50 dark:from-gray-700 to-white dark:to-gray-800">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <FiUsers className="text-xl text-blue-600 dark:text-blue-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-blue-600 dark:text-blue-400">حسین امیری</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">سطح دسترسی: کاربر</p>
            </div>
          </div>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            {[
              { tab: 'home', icon: FiHome, label: 'داشبورد' },
              { tab: 'users', icon: FiUsers, label: 'کاربران' },
              { tab: 'reservations', icon: FiCalendar, label: 'رزروها' },
              { tab: 'days', icon: FiSun, label: 'روزها' },
              { tab: 'nights', icon: FiMoon, label: 'ساعت کاری' },
              { tab: 'holidays', icon: FiCalendar, label: 'تعطیلات' }
            ].map(({ tab, icon: Icon, label }) => (
              <li key={tab}>
                <button
                  onClick={() => handleTabChange(tab)}
                  className={`w-full flex items-center p-3 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors duration-200 ${
                    activeTab === tab ? 'bg-blue-100 dark:bg-blue-600 text-blue-700 dark:text-white' : ''
                  }`}
                  aria-label={label}
                  disabled={isLoading}
                >
                  <Icon className="ml-3 text-lg" />
                  <span>{label}</span>
                </button>
              </li>
            ))}
          </ul>
          
          <div className="mt-8 pt-4 border-t dark:border-gray-700">
            <ul className="space-y-2">
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors duration-200" 
                  aria-label="تنظیمات"
                  disabled={isLoading}
                >
                  <FiSettings className="ml-3 text-lg" />
                  <span>تنظیمات</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    document.cookie = "yourToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    setTimeout(() => {
                      router.push('/login');
                    }, 100);
                  }}
                  className="w-full flex items-center p-3 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900 transition-colors duration-200"
                  aria-label="خروج"
                  disabled={isLoading}
                >
                  <FiLogOut className="ml-3 text-lg" />
                  <span>خروج</span>
                </button>
              </li>
            </ul>
          </div>
        </nav>
      </aside>
    );
  }