import { CgProfile } from "react-icons/cg";
import {
  FiCalendar,
  FiDollarSign,
  FiHome,
  FiPlus
} from 'react-icons/fi';
  
  export default function MobileFooter({ 
    activeTab, 
    handleTabChange, 
    isLoading 
  }) {
    return (
      <footer className="fixed bottom-0 left-0 right-0 flex items-center justify-center p-3 bg-white dark:bg-gray-800 border-t dark:border-gray-700 shadow-lg z-10">
        <div className="flex justify-between items-center w-full max-w-sm">
          <button
            onClick={() => handleTabChange('home')}
            className={`p-2 flex flex-col items-center ${
              activeTab === 'home' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'
            } hover:text-blue-500 transition-colors duration-200`}
            aria-label="داشبورد"
            disabled={isLoading}
          >
            <FiHome className="text-xl" />
            <span className="text-xs mt-1">داشبورد</span>
          </button>
          <button
            onClick={() => handleTabChange('reservations')}
            className={`p-2 flex flex-col items-center ${
              activeTab === 'reservations' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'
            } hover:text-blue-500 transition-colors duration-200`}
            aria-label="رزروها"
            disabled={isLoading}
          >
            <FiCalendar className="text-xl" />
            <span className="text-xs mt-1">رزروها</span>
          </button>
          <button 
            onClick={() => handleTabChange('NEWreservations')}
            className="p-3 bg-blue-500 text-white rounded-full shadow-xl hover:bg-blue-600 transition-transform transform hover:scale-110"
            aria-label="افزودن رزرو جدید"
            disabled={isLoading}
          >
            <FiPlus className="text-2xl" />
          </button>
          <button
            onClick={() => handleTabChange('fetchTransactionNotifications')}
            className={`p-2 flex flex-col items-center ${
              activeTab === 'users' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'
            } hover:text-blue-500 transition-colors duration-200`}
            aria-label="کاربران"
            disabled={isLoading}
          >
            <FiDollarSign className="text-xl" />
            <span className="text-xs mt-1">تراکنش</span>
          </button>
          <button
            onClick={() => handleTabChange("profile")}
            className={`p-2 flex flex-col items-center ${
              activeTab === 'more' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'
            } hover:text-blue-500 transition-colors duration-200`}
            aria-label="بیشتر"
            disabled={isLoading}
          >
            <CgProfile className="text-xl" />
            <span className="text-xs mt-1">پروفایل</span>
          </button>
        </div>
      </footer>
    );
  }