import { useState } from 'react';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import styles from './ChargeAccount.module.css';

const MySwal = withReactContent(Swal);

const ChargeAccount = ({ me, token }) => {
  const [formData, setFormData] = useState({
    phone: me?.phone,
    amount: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isFocused, setIsFocused] = useState({
    phone: false,
    amount: false
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFocus = (field) => {
    setIsFocused(prev => ({
      ...prev,
      [field]: true
    }));
  };

  const handleBlur = (field) => {
    setIsFocused(prev => ({
      ...prev,
      [field]: false
    }));
  };

  const showSuccessAlert = (amount) => {
    MySwal.fire({
      title: <strong>شارژ موفق!</strong>,
      html: <p>حساب کاربری با موفقیت به مبلغ <b>{amount} تومان</b> شارژ شد.</p>,
      icon: 'success',
      confirmButtonText: 'باشه',
      confirmButtonColor: '#4f46e5',
      customClass: {
        popup: 'sweet-alert-popup',
        title: 'sweet-alert-title',
        confirmButton: 'sweet-alert-confirm-btn'
      }
    });
  };

  const showErrorAlert = (message) => {
    MySwal.fire({
      title: <strong>خطا!</strong>,
      html: <p>{message}</p>,
      icon: 'error',
      confirmButtonText: 'متوجه شدم',
      confirmButtonColor: '#ef4444'
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // اعتبارسنجی
    if (!formData.phone || !formData.amount) {
      showErrorAlert('لطفاً تمام فیلدها را پر کنید');
      return;
    }

    if (!/^0?9\d{9}$/.test(formData.phone)) {
        showErrorAlert('شماره تلفن معتبر نیست. فرمت صحیح: 09123456789 یا 9123456789');
        return;
      }
      

    if (formData.amount <= 0) {
      showErrorAlert('مبلغ باید بیشتر از صفر باشد');
      return;
    }

    if (formData.amount < 1000) {
      showErrorAlert('حداقل مبلغ شارژ 1,000 تومان می‌باشد');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+'/user/wallet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          newwallet: formData.amount,
          phone: formData.phone
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'خطا در شارژ حساب');
      }

      showSuccessAlert(formData.amount);
      setFormData({ phone: '', amount: '' });
    } catch (err) {
      showErrorAlert(err.message || 'خطا در ارتباط با سرور');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.header}>
          <div className={styles.logo}>
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 14C8 14 9.5 16 12 16C14.5 16 16 14 16 14M9 9H9.01M15 9H15.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h1 className={styles.title}>شارژ حساب کاربری</h1>
          <p className={styles.subtitle}>اطلاعات مورد نیاز برای شارژ حساب را وارد نمایید</p>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={`${styles.inputGroup} ${isFocused.phone ? styles.focused : ''}`}>
            <label htmlFor="phone" className={styles.inputLabel}>شماره موبایل</label>
            <div className={styles.inputContainer}>
              <span className={styles.inputIcon}>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
              </span>
              {me?.role =="ADMINPRO" ?<>
                <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                onFocus={() => handleFocus('phone')}
                onBlur={() => handleBlur('phone')}
                placeholder="09123456789"
                className={styles.inputField}
                maxLength="11"
                dir="ltr"
              />
              </>:<>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={me.phone}
                disabled
                className={styles.inputField}
                maxLength="11"
                dir="ltr"
                style={{
                    backgroundColor: '#f0f0f0', // خاکستری روشن
                    color: '#888',              // رنگ نوشته خاکستری
                    cursor: 'not-allowed',
                    userSelect:'none'       
                }}
                />

              </>}
            </div>
          </div>

          <div className={`${styles.inputGroup} ${isFocused.amount ? styles.focused : ''}`}>
            <label htmlFor="amount" className={styles.inputLabel}>مبلغ شارژ (تومان)</label>
            <div className={styles.inputContainer}>
              <span className={styles.inputIcon}>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="1" x2="12" y2="23"></line>
                  <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
              </span>
              <input
                type="number"
                id="amount"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                onFocus={() => handleFocus('amount')}
                onBlur={() => handleBlur('amount')}
                placeholder="100000"
                className={styles.inputField}
                min="100000"
                dir="ltr"
              />
              <span className={styles.currencySign}>تومان</span>
            </div>
            <div className={styles.amountSuggestions}>
              <button type="button" onClick={() => setFormData({...formData, amount: 50000})} className={styles.amountBtn}>50,000</button>
              <button type="button" onClick={() => setFormData({...formData, amount: 100000})} className={styles.amountBtn}>100,000</button>
              <button type="button" onClick={() => setFormData({...formData, amount: 300000})} className={styles.amountBtn}>300,000</button>
            </div>
          </div>

          <button
            type="submit"
            className={styles.submitButton}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <span className={styles.loadingSpinner} />
                در حال پردازش...
              </>
            ) : (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={styles.buttonIcon}>
                  <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path>
                </svg>
                شارژ حساب
              </>
            )}
          </button>
        </form>

        <div className={styles.footer}>
          <p className={styles.footerText}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={styles.footerIcon}>
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            حداقل مبلغ شارژ 100,000 تومان می‌باشد
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChargeAccount;