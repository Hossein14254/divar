import { useState } from 'react';
import { FiEye, FiEyeOff } from 'react-icons/fi';

const PasswordInput = ({ icon, placeholder, value, onChange, error }) => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="mb-4">
      <div className={`relative flex items-center border rounded-md transition-colors ${error ? 'border-red-500' : 'border-gray-300 focus-within:border-blue-500'}`}>
        <div className="px-3 text-gray-500">
          {icon}
        </div>
        <input
          type={showPassword ? 'text' : 'password'}
          className="w-full py-3 px-2 focus:outline-none text-sm bg-transparent"
          placeholder={placeholder}
          value={value}
          onChange={onChange}
        />
        <button
          type="button"
          className="px-3 text-gray-500 hover:text-gray-700"
          onClick={() => setShowPassword(!showPassword)}
        >
          {showPassword ? <FiEyeOff /> : <FiEye />}
        </button>
      </div>
      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}
    </div>
  );
};

export default PasswordInput;