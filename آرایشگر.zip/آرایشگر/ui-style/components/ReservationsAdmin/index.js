import ReservationCard from "@/mini-components/ReservationCard";
import axios from "axios";
import { useEffect, useState } from "react";
import { FaCalendarAlt, FaChevronLeft, FaChevronRight, FaSyncAlt } from 'react-icons/fa';
import styles from './Dashboard.module.css';

export default function ReservationsAdminPanel({token, me}) {
  const [reservations, setReservations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);

  // تابع برای فرمت تاریخ به صورت عددی (۱۴۰۲/۰۵/۲۵)
  const formatDate = (date) => {
    const options = { year: 'numeric', month: '2-digit', day: '2-digit', calendar: 'persian' };
    return new Intl.DateTimeFormat('fa-IR', options).format(date);
  };

  // تابع برای نمایش نام روز
  const getDayName = (date) => {
    const options = { weekday: 'long' };
    return new Intl.DateTimeFormat('fa-IR', options).format(date);
  };

  const fetchData = async (date) => {
    setIsLoading(true);
    const formattedDate = date.toISOString().split('T')[0];
    
    try {
      const response = await axios.get(process.env.NEXT_PUBLIC_APIURL+`/reservation/get/${formattedDate}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      setReservations(response.data.reservations);
    } catch (err) {
      console.error(err);
    }
    setIsLoading(false);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchData(selectedDate);
    setIsRefreshing(false);
  };

  useEffect(() => {
    fetchData(selectedDate);
  }, [selectedDate]);

  const changeDate = (days) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + days);
    setSelectedDate(newDate);
  };

  const handleToday = () => {
    setSelectedDate(new Date());
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>مدیریت رزروها</h2>
        <button 
          onClick={handleRefresh}
          className={styles.refreshButton}
          disabled={isRefreshing}
        >
          <FaSyncAlt className={isRefreshing ? styles.spin : ''} />
        </button>
      </div>

      <div className={styles.dateNavigation}>
        <button 
          onClick={() => changeDate(-1)}
          className={styles.navButton}
          aria-label="روز قبل"
        >
          <FaChevronRight />
        </button>
        
        <div className={styles.dateDisplay} onClick={handleToday}>
          <FaCalendarAlt className={styles.calendarIcon} />
          <div className={styles.dateTextContainer}>
            <span className={styles.dayName}>{getDayName(selectedDate)}</span>
            <span className={styles.dateText}>{formatDate(selectedDate)}</span>
          </div>
        </div>
        
        <button 
          onClick={() => changeDate(1)}
          className={styles.navButton}
          aria-label="روز بعد"
        >
          <FaChevronLeft />
        </button>
      </div>

      {isLoading ? (
        <div className={styles.loadingContainer}>
          <div className={styles.spinner}></div>
          <p>در حال بارگذاری رزروها...</p>
        </div>
      ) : reservations.length > 0 ? (
        <div className={styles.reservationsGrid}>
          {reservations.map(reservation => (
            <ReservationCard 
              me={me} 
              token={token}
              key={reservation._id} 
              reservation={reservation} 
            />
          ))}
        </div>
      ) : (
        <div className={styles.emptyState}>
          <h3>رزروی برای این تاریخ یافت نشد</h3>
          <p>می‌توانید تاریخ را تغییر دهید یا منتظر رزروهای جدید بمانید</p>
          <button 
            onClick={handleToday}
            className={styles.todayButton}
          >
            بازگشت به امروز
          </button>
        </div>
      )}
    </div>
  );
}