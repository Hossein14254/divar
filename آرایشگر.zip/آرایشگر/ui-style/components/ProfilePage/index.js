import axios from 'axios';
import { motion } from 'framer-motion';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { FaBan, FaCheck, FaPen, FaPhone, FaShieldAlt, FaSignOutAlt, FaTimes, FaUser, FaWallet } from 'react-icons/fa';
import Swal from 'sweetalert2';
import styles from './ProfilePage.module.css';

const ProfilePage = ({ token }) => {
  const [me,setMe]=useState()

  const router = useRouter();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: me?.name || '',
    family: me?.family || '',
  });

  const checkAuth = async () => {
    try {
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/auth/getme", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) throw Error('Authentication failed');

      const data = await response.json();
      if (data?._id) {
        setMe(data);

      } else {
          await router.push('/Phone');
      }
    } catch (error) {
      console.error('Error:', error);
    } 
  };

  // به‌روزرسانی formData وقتی me تغییر می‌کند
  useEffect(() => {
    setFormData({
      name: me?.name || '',
      family: me?.family || '',
    });checkAuth()
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = () => {
    const data = {
      name: formData.name,
      family: formData.family,
    };

    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    };

    axios
      .put(process.env.NEXT_PUBLIC_APIURL+'/user/', data, config)
      .then((response) => {
        if (response.status === 200) {
          Swal.fire({
            title: 'با موفقیت بروز شد',
            icon: 'success',
          });
          checkAuth()
        } else {
          Swal.fire({
            title: 'خطا در بروزرسانی',
            icon: 'error',
            text: response?.data?.message || 'خطای نامشخص',
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          title: 'خطا در بروزرسانی',
          icon: 'error',
          text: error?.response?.data?.message || 'خطای نامشخص',
        });
      });

    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: me.name || '',
      family: me.family || '',
    });
    setIsEditing(false);
  };

  const handleLogout = () => {
    console.log('کاربر از حساب خارج شد');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={styles.profileContainer}
    >
      {me? <>
      
      {/* هدر پروفایل */}
      <div className={styles.profileHeader}>
        <div className={styles.avatarContainer}>
          <div className={styles.avatar}>
            <FaUser className={styles.avatarIcon} />
          </div>
          {me?.role === "ADMIN" && (
            <div className={styles.barberBadge}>{me?.isBarber ? <>آرایشگر فعال</> : <>آرایشگر غیر فعال</>}</div>
          )}
          {me?.role === "ADMINPRO" && (
            <div className={styles.barberBadge}>{me?.isBarber ? <>آرایشگر فعال</> : <>آرایشگر غیر فعال</>}</div>
          )}
          {me?.role === "USER" && (
            <div className={styles.barberBadge}>کاربر فعال</div>
          )}
          {me?.ban && (
            <div className={styles.banBadge}>
              <FaBan /> مسدود شده
            </div>
          )}
        </div>

        {isEditing ? (
          <div className={styles.editForm}>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className={styles.editInput}
              placeholder="نام"
              />
            <input
              type="text"
              name="family"
              value={formData.family}
              onChange={handleInputChange}
              className={styles.editInput}
              placeholder="نام خانوادگی"
              />
          </div>
        ) : (
          <h1 className={styles.userName}>
            {me?.name} {me?.family}
          </h1>
        )}
      </div>

      {/* اطلاعات کاربر */}
      <div className={styles.profileInfo}>
        <div className={styles.infoItem}>
          <FaPhone className={styles.infoIcon} />
          <span className={styles.infoLabel}>شماره تماس:</span>
          <span className={styles.infoValue}>{me.phone}</span>
        </div>
        <div className={styles.infoItem}>
          <FaWallet className={styles.infoIcon} />
          <span className={styles.infoLabel}>موجودی کیف پول:</span>
          <span className={styles.infoValue}>{me.wallet || 0}</span>
          <span className={styles.infoUnit}>تومان</span>
        </div>
        <div className={styles.infoItem}>
          <FaShieldAlt className={styles.infoIcon} />
          <span className={styles.infoLabel}>نقش:</span>
          <span className={styles.infoValue}>
            {me.role === 'ADMIN' ? 'آرایشگر' : me.role === 'ADMINPRO' ? 'مدیر سیستم' : 'کاربر عادی'}
          </span>
        </div>
      </div>

      {/* دکمه‌های اقدام */}
      <div className={styles.actionButtons}>
        {isEditing ? (
          <>
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`${styles.actionBtn} ${styles.saveBtn}`}
              onClick={handleSave}
              >
              <FaCheck className={styles.btnIcon} />
              ذخیره تغییرات
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`${styles.actionBtn} ${styles.cancelBtn}`}
              onClick={handleCancel}
            >
              <FaTimes className={styles.btnIcon} />
              انصراف
            </motion.button>
          </>
        ) : (
          <>
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`${styles.actionBtn} ${styles.editBtn}`}
              onClick={() => setIsEditing(true)}
            >
              <FaPen className={styles.btnIcon} />
              ویرایش پروفایل
            </motion.button>
            <motion.button 
              onClickCapture={() => {
                document.cookie = "yourToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                setTimeout(() => {
                  router.push('/login');
                }, 100);
              }}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`${styles.actionBtn} ${styles.logoutBtn}`}
              onClick={handleLogout}
            >
              <FaSignOutAlt  className={styles.btnIcon} />
              خروج از حساب
            </motion.button>
          </>
        )}
      </div>
      </>:<></>}
    </motion.div>
  );
};

export default ProfilePage;