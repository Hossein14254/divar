import { FiAlertCircle } from 'react-icons/fi';

const InputField = ({ icon, type = 'text', placeholder, value, onChange, error }) => {
  return (
    <div className="mb-4">
      <div className={`relative flex items-center border rounded-md transition-colors ${error ? 'border-red-500' : 'border-gray-300 focus-within:border-blue-500'}`}>
        <div className="px-3 text-gray-500">
          {icon}
        </div>
        <input
          type={type}
          className="w-full py-3 px-2 focus:outline-none text-sm bg-transparent"
          placeholder={placeholder}
          value={value}
          onChange={onChange}
        />
        {error && (
          <div className="px-3 text-red-500">
            <FiAlertCircle />
          </div>
        )}
      </div>
      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}
    </div>
  );
};

export default InputField;