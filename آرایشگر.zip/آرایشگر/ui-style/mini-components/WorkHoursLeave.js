import moment from "moment-jalaali";
import { useEffect, useRef, useState } from "react";
import styles from "./WorkHours.module.css";
moment.loadPersian({ dialect: "persian-modern", usePersianDigits: true });

const WorkHours = ({ onSelectHours, token }) => {
  const [selectedHours, setSelectedHours] = useState([]); // تغییر از selectedHour به selectedHours
  const [err, setErr] = useState(null);
  const [WorkHoursData, setWorkHoursData] = useState(null);
  const hasFetched = useRef(false);

  const checkAuth = async () => {
    try {
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/workinghour/`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        return console.error(response);
      }
      const data = await response.json();
      setWorkHoursData(data.Hour);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true; // تنظیم پرچم برای جلوگیری از اجرای دوباره
      checkAuth();
    }
  }, [WorkHoursData]);

  const handleSelect = (_id) => {
    // اگر ساعت انتخاب شده قبلاً در آرایه باشد، آن را حذف کن
    if (selectedHours.includes(_id)) {
      setSelectedHours(selectedHours.filter((hourId) => hourId !== _id));
    } else {
      setSelectedHours([...selectedHours, _id]); // اضافه کردن ساعت جدید به لیست
    }
  };

  const handleNext = () => {
    
    if (selectedHours.length > 0) {
      if (onSelectHours) {
        onSelectHours(selectedHours); // ارسال آرایه ساعات انتخاب شده
      }
    } else {
      setErr("انتخاب ساعت الزآمی هست.");
    }
  };

  return (
    <div className={styles.barberListContainer}>
      {err ? (
        <>
          <h2 style={{ color: "red" }} className={styles.barberListHeading}>
            انتخاب ساعت الزآمی هست.
          </h2>
        </>
      ) : (
        <>
          <h2 className={styles.barberListHeading}>ساعت مورد نظر را انتخاب کنید</h2>
        </>
      )}
      <div className={styles.barberCardsWrapper}>
        {WorkHoursData?.map((hour) => {
          return (
            <div
              key={hour._id}
              className={`${styles.barberCard}`}
              onClick={() => handleSelect(hour._id)}
            >
              {selectedHours.includes(hour._id) ? (
                <div className={styles.select}></div>
              ) : (
                <div className={styles.selected}></div>
              )}
              <div className={styles.box}>
                <span className={styles.barberName}>{`${hour.start_time}  ${hour.end_time}`}</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className={styles.next} onClick={handleNext}>
        بعدی
      </div>
    </div>
  );
};

export default WorkHours;
