
import moment from "moment-jalaali";
import { useRouter } from "next/router";
import { useEffect, useRef, useState } from "react";
import { MdErrorOutline } from "react-icons/md";
import styles from "./Datepicker.module.css";

moment.loadPersian({ dialect: 'persian-modern', usePersianDigits: true });

const Datepicker = ({ onSelectDate, token }) => {
  const [selectedService, setSelectedService] = useState(null);
  const [idService, setIdService] = useState(null);
  const [Services, setServices] = useState(null);
  const hasFetched = useRef(false);
  const [num, setNum] = useState(1);
  const [err, setErr] = useState(null);
  const [clickMessage, setClickMessage] = useState(null);
  const router = useRouter();

  const checkAuth = async () => {
    try {
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/activeday/${num}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        throw new Error('Authentication failed');
      }
      const data = await response.json();
      setServices(data.days);
    } catch (error) {
      console.error('Error:', error);
      if (router.pathname !== '/Phone') {
        await router.push('/Phone');
      }
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true;
      checkAuth();
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [num]);

  const today = moment().startOf("day");
  const todayDate = new Date();

  const handleSelect = (_id) => {
    const service = Services.find((s) => s._id === _id);
    
    if (service?.isHoliday) {
      setClickMessage("این روز تعطیل است و امکان انتخاب وجود ندارد");
      setTimeout(() => setClickMessage(null), 3000);
      return;
    }
    
    if (selectedService?._id === _id) {
      setSelectedService(null);
      setIdService(null);
    } else if (service && moment(service.date).isSameOrAfter(today)) {
      setSelectedService(service);
      setIdService(_id);
    }
  };

  const handleNextWeek = () => {
    setNum(num + 1);
  };

  const handlePrevWeek = () => {
    if (num > 1) {
      setNum(num - 1);
    }
  };

  const handleNext = () => {
    if (Services) {
      if (onSelectDate && idService) {
        onSelectDate(idService);
      } else {
        setErr("لطفا یک روز را انتخاب کنید");
        setTimeout(() => setErr(null), 3000);
      }
    } else {
      setErr("خطا در دریافت اطلاعات");
      setTimeout(() => setErr(null), 3000);
    }
  };

  return (
    <div className={styles.barberListContainer}>
      <div className={styles.navigation}>
        <button 
          className={styles.navButton} 
          onClick={handlePrevWeek}
          disabled={num === 1}
        >
          هفته قبل
        </button>
        <button className={styles.navButton} onClick={handleNextWeek}>
          هفته بعد
        </button>
      </div>
      
      {err ? (
        <h2 style={{color:"red"}} className={styles.barberListHeading}>{err}</h2> 
      ) : (
        <h2 className={styles.barberListHeading}>خدمات مورد نیاز را انتخاب کنید</h2>
      )}
      
      {clickMessage && (
        <div className={styles.clickMessage}>
            <div className={styles.iconWrapper}>
              <MdErrorOutline className={styles.icon} />
            </div>
            <div className={styles.text}>{clickMessage}</div>
          </div>
      )}
      
      {Services && Services.length === 0 && (
                <div className={styles.clickMessage}>
                <div className={styles.iconWrapper}>
                  <MdErrorOutline className={styles.icon} />
                </div>
                <div className={styles.text}>          برای این هفته هیچ روزکاری تعریف نشده است
                </div>
              </div>
      )}
      
      <div className={styles.barberCardsWrapper}>
        {Services?.map((service) => {
          const serviceDate = new Date(service.date);
          const serviceMoment = moment(service.date).locale("fa");
          const isPast = serviceMoment.isBefore(today);
          const isToday = serviceMoment.isSame(today);
          const isFutureAndActive = serviceMoment.isSameOrAfter(today) && !isToday;
          const dayName = serviceMoment.format("dddd");
          const isHoliday = service?.isHoliday;
          const isTodayme = service?.isToday;

          return (
            <div
              key={service._id}
              className={`${styles.barberCard} ${
                serviceDate.toISOString().split('T')[0] === todayDate.toISOString().split('T')[0]
                  ? styles.today
                  : isPast 
                    ? styles.past
                    : isFutureAndActive 
                      ? styles.futureActive
                      : ''
              } ${isHoliday ? styles.holiday : ''}`}
              onClick={() => {
                if (!isPast && !isHoliday) {
                  handleSelect(service._id);
                } else if (isHoliday) {
                  setClickMessage("این روز تعطیل است و امکان انتخاب وجود ندارد");
                  setTimeout(() => setClickMessage(null), 3000);
                }
              }}
            >
              {isHoliday && (
                <div className={styles.divspanishoilday}>
                  <span className={styles.spanishoilday}>تعطیل</span>
                </div>
              )}
              {isTodayme && (
                <div className={styles.divisTodayme}>
                  <span>امروز</span>
                </div>
              )}

              {selectedService?._id === service._id ? (
                <div className={styles.select}></div>
              ) : (
                <div className={styles.selected}></div>
              )}

              <div className={styles.box}>
                <span className={styles.barberName}>{dayName}</span>
                <span className={styles.price}>{serviceMoment.format("jD jMMMM jYYYY")}</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className={styles.next} onClick={handleNext}>بعدی</div>
    </div>
  );
};

export default Datepicker;