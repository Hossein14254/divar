import React from 'react';
import styles from './ProgressTracker.module.css';

const ProgressSteps = ({ totalSteps, completedSteps }) => {
  return (
    <>
    <div className={styles.container}>
      {Array.from({ length: totalSteps }).map((_, index) => {
          const stepNumber = index + 1;
        const isCompleted = stepNumber <= completedSteps;
        const isActive = stepNumber === completedSteps + 1;
        
        return (
            <React.Fragment key={stepNumber}>
            <div className={`${styles.step} ${isCompleted ? styles.completed : ''} ${isActive ? styles.active : ''}`}>
              <div className={styles.circle}>
                <span className={styles.stepNumber}>{stepNumber}</span>
              </div>
            </div>
            
            {stepNumber < totalSteps && (
                <div className={`${styles.connector} ${isCompleted ? styles.completed : ''}`} />
            )}
          </React.Fragment>
        );
    })}
    </div>
    <hr></hr>
    <hr></hr>
    <hr></hr>
    <hr style={{marginBottom:"12px"}}></hr>

    </>
  );
};

export default ProgressSteps;