import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import moment from 'moment-jalaali';
import { useState } from 'react';
import { FaBan, FaCheck, FaClock, FaEnvelope, FaPhone, FaTimes, FaUser } from 'react-icons/fa';
import { HiOutlineScissors } from "react-icons/hi";
import ReservationStatus from './ReservationStatus';


const ReservationCard = ({ token, reservation, me }) => {
  const [status, setStatus] = useState(null);
  const [data,setData]=useState(reservation)
  const [isExpanded, setIsExpanded] = useState(false);

  const handleAction = (action) => {
    console.log(`${action} clicked for reservation ID: ${reservation._id}`);
  };

  async function statushandler(newStatus) {
    try {
      const response = await axios.put(
        process.env.NEXT_PUBLIC_APIURL+`/reservation/put/${reservation._id}/${newStatus}`,
        {}, // یا null اگر داده‌ای نداری
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      
      if (response.data) { // تغییر از response.ok به response.data چون axios ساختار متفاوتی دارد
        setData(response.data.Reservation)
        setStatus(newStatus);
        setTimeout(() => setStatus(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  }

  const toggleExpand = () => setIsExpanded(!isExpanded);

  return (
    <motion.div 
      className="relative bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl p-4 max-w-sm w-full mx-auto my-4 border border-gray-100/30 dark:border-gray-700/30 overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      whileHover={{ scale: 1.02, boxShadow: "0 12px 24px rgba(0,0,0,0.1)" }}
    >
      {/* Header */}
      <motion.div 
        className="flex items-center gap-4 p-3 rounded-xl bg-gradient-to-r from-blue-50/50 to-purple-50/50 dark:from-gray-900 dark:to-gray-800 cursor-pointer"
        onClick={toggleExpand}
        whileTap={{ scale: 0.98 }}
      >
        <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center flex-shrink-0">
          <FaUser className="text-blue-600 dark:text-blue-400 text-xl" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white truncate">
            {reservation.customer_id.name}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-300 flex items-center gap-2">
            <HiOutlineScissors className="text-purple-500" />
            {reservation.provider_id.name}
          </p>
        </div>
        <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-sm font-medium text-gray-700 dark:text-gray-200">
          <FaClock className="text-amber-500" />
          {reservation.workingHour_id.start_time}
        </div>
      </motion.div>
      
      <ReservationStatus reservation={data}/>

      {/* Expanded Details */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="pt-4 pb-2 px-3"
          >
            <div className="space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-600 dark:text-gray-300">زمان:</span>
                <span className="text-gray-800 dark:text-gray-200">
                  {`${reservation.workingHour_id.start_time} - ${reservation.workingHour_id.end_time}`}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-600 dark:text-gray-300">خدمات:</span>
                <span className="text-gray-800 dark:text-gray-200">{reservation.service_id.title}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-600 dark:text-gray-300">تاریخ:</span>
                <span className="text-gray-800 dark:text-gray-200">{moment(reservation.date_id?.date).format('jYYYY/jMM/jDD') || "امروز"}</span>
              </div>
              <div className="flex gap-3 mt-4">
                {me?.status && (
                  <>
                    <motion.button
                      className="flex-1 p-2 bg-blue-100 dark:bg-blue-900/50 rounded-full text-blue-600 dark:text-blue-300 flex items-center justify-center gap-2 text-sm"
                      whileHover={{ scale: 1.05, backgroundColor: "#3B82F6", color: "#ffffff" }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleAction('تماس')}
                    >
                      <FaPhone /> تماس
                    </motion.button>
                    <motion.button
                      className="flex-1 p-2 bg-blue-100 dark:bg-blue-900/50 rounded-full text-blue-600 dark:text-blue-300 flex items-center justify-center gap-2 text-sm"
                      whileHover={{ scale: 1.05, backgroundColor: "#3B82F6", color: "#ffffff" }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleAction('پیامک')}
                    >
                      <FaEnvelope /> پیامک
                    </motion.button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {status && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.3 }}
            className={`absolute top-2 left-2 right-2 p-2 rounded-lg text-sm font-medium flex items-center justify-center gap-2
              ${status === 'confirmed' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 
                status === 'no-show' ? 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' :
                'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'}`}
          >
            {status === 'confirmed' && <><FaCheck /> تأیید شد</>}
            {status === 'no-show' && <><FaBan /> عدم حضور</>}
            {status === 'cancelled' && <><FaTimes /> لغو شد</>}
            {status === 'pending' && <><FaTimes /> رزرو شد</>}
          </motion.div>
        )}
      </AnimatePresence>
                
      {me?.isbarber && (
        <div className="flex border-t border-gray-100/30 dark:border-gray-700/30 mt-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex-1 p-3 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-bl-xl text-sm font-medium flex items-center justify-center gap-2"
            onClick={() => statushandler('confirmed')}
          >
            <FaCheck /> تأیید
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex-1 p-3 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-900/30 text-sm font-medium flex items-center justify-center gap-2"
            onClick={() => statushandler('cancelled')}
          >
            <FaTimes /> لغو
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex-1 p-3 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-br-xl text-sm font-medium flex items-center justify-center gap-2"
            onClick={() => statushandler('no-show')}
          >
            <FaBan /> عدم حضور
          </motion.button>
        </div>
      )}
    </motion.div>
  );
};

export default ReservationCard;