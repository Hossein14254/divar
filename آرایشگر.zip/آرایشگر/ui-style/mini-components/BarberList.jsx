import { useEffect, useRef, useState } from 'react';
import styles from './BarberList.module.css';

const BarberList = ({ onSelectBarber,token }) => {
  const [selectedBarber, setSelectedBarber] = useState(null);
  const [idbarber, setIdbarber] = useState(null);
  
  const [barbers,setBarbers]=useState(null)
  const hasFetched = useRef(false);

  const checkAuth = async () => {
    try {
      console.log(token)
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/user/barber", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        console.log(response)
      }
      const data = await response.json();
      setBarbers(data.users)
    } catch (error) {
      console.error('Error:', error);
      if (router.pathname !== '/Phone') {
        await router.push('/Phone');
      }
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true; // تنظیم پرچم برای جلوگیری از اجرای دوباره
      checkAuth();
    }
  }, [barbers]); 
    
  const handleSelect = (_id) => {
    if (selectedBarber?._id === _id) {
      setSelectedBarber(null);
      setIdbarber(null);
    } else {
      setSelectedBarber(barbers.find(barber => barber._id === _id));
      setIdbarber(_id);
    }
  };
  const [err,setErr]=useState(null)
  const handleNext = () => {
    if(idbarber){  
      if (onSelectBarber) {
        onSelectBarber(idbarber);
      }
    }else{
      setErr("انتخاب آرایشگر الزآمی هست.")
    }
  };

  return (
    <div className={styles.barberListContainer}>
      {err?<>
      <h2 style={{color:"red"}} className={styles.barberListHeading}>انتخاب آرایشگر الزآمی هست.</h2> 
      </>:<>
      <h2  className={styles.barberListHeading}>آرایشگر خود را انتخاب کنید</h2> 
      </>}
      <div className={styles.barberCardsWrapper}>
        {barbers?.map((barber) => (
          <div
            key={barber._id}
            className={`${styles.barberCard} `}
            onClick={() => handleSelect(barber._id)}
          >
            {selectedBarber?._id === barber._id ? (
              <div className={styles.select}></div>
            ) : (
              <div className={styles.selected}></div>
            )}
            <span className={styles.barberName}>{barber.name}</span>
          </div>
        ))}
      </div>
      <div className={styles.next} onClick={handleNext}>بعدی</div>
    </div>
  );
};

export default BarberList;
