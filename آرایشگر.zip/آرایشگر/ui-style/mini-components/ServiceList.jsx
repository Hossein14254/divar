import { useEffect, useRef, useState } from 'react';
import styles from './ServiceList.module.css';

const ServiceList = ({ onSelectService,token }) => {
  const [selectedService, setSelectedService] = useState(null);
  const [idService , setIdService ] = useState(null);
  const [err,setErr]=useState(null)

  const [Services,setServices]=useState(null)
  const hasFetched = useRef(false);

  const checkAuth = async () => {
    try {
      const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/services", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        throw new Error('Authentication failed');
      }
      const data = await response.json();
      setServices(data.Services)
    } catch (error) {
      console.error('Error:', error);
      if (router.pathname !== '/Phone') {
        await router.push('/Phone');
      }
    }
  };

  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true; // تنظیم پرچم برای جلوگیری از اجرای دوباره
      checkAuth();
    }
  }, [Services]); 

  const handleSelect = (_id) => {
    if (setSelectedService?._id === _id) {
        setSelectedService(null);
        setIdService(null);
    } else {
        setSelectedService(Services.find(Service => Service._id === _id));
        setIdService(_id);
    }
  };

  const handleNext = () => {
    if(Services){

      if (onSelectService) {
        onSelectService(idService);
      }
    }else{
      setErr("انتخاب آرایشگر الزآمی هست.")
    }
  };

  return (
    <div className={styles.barberListContainer}>
      {err?<>
        <h2 style={{color:"red"}} className={styles.barberListHeading}>انتخاب خدمات الزآمی هست.</h2> 
      </>:<>
      <h2 className={styles.barberListHeading}>خدمات مورد نیاز را انتخاب کنید</h2>
      </>}
      <div className={styles.barberCardsWrapper}>
        {Services?.map((Service) => (
          <div
            key={Service._id}
            className={`${styles.barberCard} `}
            onClick={() => handleSelect(Service._id)}
          >
            {selectedService?._id === Service._id ? (
              <div className={styles.select}></div>
            ) : (
              <div className={styles.selected}></div>
            )}
            <div className={styles.box}>
                <span className={styles.barberName}>{Service.title}</span>
                <span className={styles.price}>{Service.price}  تومان  </span>
            </div>
                
            <span className={styles.minute}>`{Service.minute}</span>
          </div>
        ))}
      </div>
      <div className={styles.next} onClick={handleNext}>بعدی</div>
    </div>
  );
};

export default ServiceList;

