'use client';
import Chart from 'chart.js/auto';
import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import styles from './WorkingHoursChart.module.css';

// Register Chart.js plugin for custom hour labels
Chart.register({
  id: 'customHourLabels',
  afterDraw: (chart) => {
    const { ctx, chartArea } = chart;
    const centerX = (chartArea.left + chartArea.right) / 2;
    const centerY = (chartArea.top + chartArea.bottom) / 2;
    const radius = (chartArea.right - chartArea.left) / 2 + 20;
    ctx.save();
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#1f2937';

    const isMorning = chart.config.options.isMorning;
    const startHour = isMorning ? 0 : 12;
    
    // Define the positions for main hours (0/12, 3/15, 6/18, 9/21)
    const mainHours = isMorning ? [0, 3, 6, 9] : [12, 15, 18, 21];
    const angles = [0, 90, 180, 270]; // Top, right, bottom, left
    
    mainHours.forEach((hour, index) => {
      const angle = (angles[index] * Math.PI) / 180;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      ctx.fillText(`${hour}:00`, x, y);
    });
    
    ctx.restore();
  },
});

export default function WorkingHoursChart({ data }) {
  const chartRef1 = useRef(null); // 00:00–12:00
  const chartRef2 = useRef(null); // 12:00–24:00
  const canvasRef1 = useRef(null);
  const canvasRef2 = useRef(null);
  const [isExpanded, setIsExpanded] = useState(true);

  // Fake data with minute precision
  const workingHours = data?.length
    ? data
    : [
      ];

  useEffect(() => {
    if (!canvasRef1.current || !canvasRef2.current || !isExpanded) return;

    const timeToMinutes = (time) => {
      const [hours, minutes] = time.split(':').map(Number);
      return hours * 60 + minutes;
    };

    // Initialize segments (720 segments = 12 hours * 60 minutes)
    const morningSegments = Array(720).fill(0); // 00:00–12:00
    const afternoonSegments = Array(720).fill(0); // 12:00–24:00
    const morningColors = Array(720).fill('rgba(200, 200, 200, 0.5)'); // Gray for empty slots
    const afternoonColors = Array(720).fill('rgba(200, 200, 200, 0.5)'); // Gray for empty slots

    // Generate distinct colors for each working hour slot
    const generateColor = (index) => {
      const hue = (index * 137.5) % 360; // Golden angle for color distribution
      return `hsla(${hue}, 80%, 60%, 0.7)`;
    };

    // Map working hours to segments
    workingHours.forEach((item, index) => {
      let startMinutes = timeToMinutes(item.start_time);
      let endMinutes = timeToMinutes(item.end_time);
      const color = generateColor(index);

      // Handle overnight slots
      if (endMinutes < startMinutes) {
        endMinutes += 1440; // Add 24 hours
      }

      // Assign minutes to segments
      for (let i = startMinutes; i < endMinutes; i++) {
        const minuteIndex = i % 1440; // Wrap around 24 hours
        if (minuteIndex < 720) {
          // Morning (00:00–12:00)
          morningSegments[minuteIndex] = 1;
          morningColors[minuteIndex] = color;
        } else {
          // Afternoon (12:00–24:00)
          afternoonSegments[minuteIndex - 720] = 1;
          afternoonColors[minuteIndex - 720] = color;
        }
      }
    });

    // Create chart configuration
    const createChartConfig = (segments, colors, isMorning) => ({
      type: 'doughnut',
      data: {
        labels: Array(720).fill(''), // No labels for individual minutes
        datasets: [
          {
            data: segments.map(val => val || 0.5), // Use 0.5 for empty segments to make them visible
            backgroundColor: colors,
            borderColor: 'rgba(255, 255, 255, 0.2)',
            borderWidth: 0.5,
          },
        ],
      },
      options: {
        responsive: true,
        cutout: '70%',
        rotation: 0, // Start at top (00:00 or 12:00)
        circumference: 360,
        isMorning,
        plugins: {
          legend: { display: false },
          tooltip: {
            enabled: true,
            callbacks: {
              label: (context) => {
                const minuteIndex = context.dataIndex + (isMorning ? 0 : 720);
                const hour = Math.floor(minuteIndex / 60);
                const minute = minuteIndex % 60;
                const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                
                const slot = workingHours.find((item) => {
                  let start = timeToMinutes(item.start_time);
                  let end = timeToMinutes(item.end_time);
                  if (end < start) end += 1440;
                  return start <= minuteIndex && minuteIndex < end;
                });
                
                return slot
                  ? `${slot.start_time} تا ${slot.end_time}`
                  : `غیرکاری (${timeString})`;
              },
            },
          },
        },
        animation: {
          animateScale: true,
          animateRotate: true,
        },
      },
    });

    // Morning chart
    if (chartRef1.current) chartRef1.current.destroy();
    const ctx1 = canvasRef1.current.getContext('2d');
    chartRef1.current = new Chart(ctx1, createChartConfig(morningSegments, morningColors, true));

    // Afternoon chart
    if (chartRef2.current) chartRef2.current.destroy();
    const ctx2 = canvasRef2.current.getContext('2d');
    chartRef2.current = new Chart(ctx2, createChartConfig(afternoonSegments, afternoonColors, false));

    return () => {
      if (chartRef1.current) chartRef1.current.destroy();
      if (chartRef2.current) chartRef2.current.destroy();
    };
  }, [workingHours, isExpanded]);

  return (
    <div className={styles.chartContainer}>
      <motion.div
        className={styles.toggleBar}
        onClick={() => setIsExpanded(true)}
        whileHover={{ backgroundColor: '#e5e7eb' }}
        transition={{ duration: 0.3 }}
      >
      </motion.div>
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.5 }}
            className={styles.chartWrapper}
          >
            <div className={styles.charts}>
              <div className={styles.chart}>
                <h4 className={styles.chartTitle}>00:00 تا 12:00</h4>
                <canvas ref={canvasRef1} />
              </div>
              <div className={styles.chart}>
                <h4 className={styles.chartTitle}>12:00 تا 24:00</h4>
                <canvas ref={canvasRef2} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}