import moment from "moment-jalaali";
import { useEffect, useRef, useState } from "react";
import styles from "./WorkHours.module.css";
moment.loadPersian({ dialect: "persian-modern", usePersianDigits: true });

const WorkHours = ({ onSelectHours,token,selectedBarberId,selectedDateId }) => {
  const [selectedHour, setSelectedHour] = useState(null);
  const [idService, setIdService] = useState(null);

  const todayDate = new Date();

  const today = moment(todayDate).startOf("day");

  const [err,setErr]=useState(null)

  const [WorkHoursData,setWorkHoursData]=useState(null)
  const hasFetched = useRef(false);

  const checkAuth = async () => {
    if(selectedBarberId &&selectedDateId){
      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+`/reservation/get/${selectedBarberId}/${selectedDateId}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        return console.error(response)
      }
      const data = await response.json();
      setWorkHoursData(data.workingHours)
    } catch (error) {
      console.error('Error:', error);
    }
  }else{
    console.log(selectedBarberId +"   "+selectedDateId)
  };
  }
  useEffect(() => {
    if (!hasFetched.current) {
      hasFetched.current = true; // تنظیم پرچم برای جلوگیری از اجرای دوباره
      checkAuth();
    }
  }, [WorkHoursData]); 

  const handleSelect = (_id) => {
    const hour = WorkHoursData.find((h) => h._id === _id);
    if (selectedHour?._id === _id) {
      setSelectedHour(null);
      setIdService(null);
    } else if (hour) {
      setSelectedHour(hour);
      setIdService(_id);
    }
  };

  const handleNext = () => {
    if(selectedHour){

      if (onSelectHours && idService) {
        onSelectHours(idService);
      }
    }else{
      setErr("انتخاب ساعت الزآمی هست.")
    }
  };

  return (
    <div className={styles.barberListContainer}>
      {err?<>
        <h2 style={{color:"red"}} className={styles.barberListHeading}>انتخاب ساعت الزآمی هست.</h2> 
      </>:<>
      <h2 className={styles.barberListHeading}>ساعت مورد نظر را انتخاب کنید</h2>
      </>}
      <div className={styles.barberCardsWrapper}>
        {WorkHoursData?.map((hour) => {
            
          return (
            <div
              key={hour._id}
              className={`${styles.barberCard} `}
              onClick={() => handleSelect(hour._id)}
            >
              {selectedHour?._id === hour._id ? (
                <div className={styles.select}></div>
              ) : (
                <div className={styles.selected}></div>
              )}
              <div className={styles.box}>
                <span className={styles.barberName}>{`${hour.start_time}  ${hour.end_time}`}</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className={styles.next} onClick={handleNext}>بعدی</div>
    </div>
  );
};

export default WorkHours;