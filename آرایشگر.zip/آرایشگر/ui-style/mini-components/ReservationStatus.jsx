import {
    FaCalendarTimes,
    FaCheckCircle,
    FaHourglassHalf,
    FaInfoCircle,
    FaUserSlash
} from 'react-icons/fa';
import styles from './ReservationStatus.module.css';
  
  const ReservationStatus = ({ reservation }) => {
    // تعریف وضعیت‌ها و مشخصات مربوطه در یک آبجکت
    const statusConfig = {
      confirmed: {
        icon: <FaCheckCircle className={styles.icon} />,
        text: 'انجام شده',
        className: styles.confirmed
      },
      'no-show': {
        icon: <FaUserSlash className={styles.icon} />,
        text: 'عدم حضور کاربر',
        className: styles.noShow
      },
      cancelled: {
        icon: <FaCalendarTimes className={styles.icon} />,
        text: 'رزرو لغو شده',
        className: styles.cancelled
      },
      pending: {
        icon: <FaHourglassHalf className={styles.icon} />,
        text: 'صف نوبت',
        className: styles.pending
      },
      default: {
        icon: <FaInfoCircle className={styles.icon} />,
        text: 'وضعیت نامشخص',
        className: styles.default
      }
    };
  
    // دریافت وضعیت یا استفاده از حالت پیش‌فرض
    const currentStatus = reservation?.status || 'default';
    const { icon, text, className } = statusConfig[currentStatus] || statusConfig.default;
  
    return (
      <div className={styles.reservationStatus}>
        <div className={`${styles.status} ${className}`}>
          {icon}
          <span>{text}</span>
        </div>
      </div>
    );
  };
  
  export default ReservationStatus;