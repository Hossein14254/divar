import { AnimatePresence, motion } from 'framer-motion';
import moment from 'moment-jalaali';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

// Components
import Header from '@/components/dashboard/Header';
import MobileFooter from '@/components/dashboard/MobileFooter';
import MobileMenu from '@/components/dashboard/MobileMenu';
import Sidebar from '@/components/dashboard/Sidebar';
import TabContent from '@/components/dashboard/TabContent';

// Configure moment-jalaali for Persian calendar
moment.loadPersian({ dialect: 'persian-modern', usePersianDigits: true });

export default function DashboardPage({ token, me }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState('light');
  const [activeTab, setActiveTab] = useState('home');
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(moment().format('HH:mm A'));
  const router = useRouter();

  // Persist theme in localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    setCurrentTheme(savedTheme);
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
  }, []);

  // Detect mobile device - با دبل چک برای جلوگیری از فلیکر
  useEffect(() => {
    const handleResize = () => {
      const newIsMobile = window.innerWidth < 768;
      // فقط در صورت تغییر واقعی وضعیت، state را آپدیت کنیم
      if (newIsMobile !== isMobile) {
        setIsMobile(newIsMobile);
      }
      // اگر صفحه بزرگ شد، منو را ببند
      if (!newIsMobile) {
        setIsMenuOpen(false);
      }
    };

    // یک بار در ابتدا چک می‌کنیم
    handleResize();
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isMobile]); // وابستگی به isMobile اضافه شد

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(moment().format('HH:mm A'));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Toggle theme and save to localStorage
  const toggleTheme = () => {
    setCurrentTheme(prev => {
      const newTheme = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      document.documentElement.classList.toggle('dark', newTheme === 'dark');
      return newTheme;
    });
  };

  // Handle tab change with loading state
  const handleTabChange = (tab) => {
    if (isLoading) return;
    setIsLoading(true);
    setTimeout(() => {
      setActiveTab(tab);
      if (isMobile) {
        setIsMenuOpen(false);
      }
      setIsLoading(false);
    }, 300);
  };

  const progressBarVariants = {
    initial: { width: '0%' },
    animate: { width: '100%', transition: { duration: 0.3, ease: 'linear' } },
    exit: { width: '0%', transition: { duration: 0.1 } }
  };

  return (
    <div dir="rtl" className={`min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 text-gray-800 dark:text-gray-100 font-sans transition-colors duration-300 ${currentTheme === 'dark' ? 'dark' : ''}`}>
      <Head>
        <title>داشبورد مدیریت | سامانه رزرواسیون</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
      </Head>

      {/* Progress Bar */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            variants={progressBarVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="fixed top-0 left-0 h-1 bg-blue-500 z-50"
          />
        )}
      </AnimatePresence>

      {/* Header */}
      <Header 
        me={me}
        isMobile={isMobile}
        activeTab={activeTab}
        isLoading={isLoading}
        setIsMenuOpen={setIsMenuOpen}
        handleTabChange={handleTabChange}
      />

      {/* Sidebar for Desktop */}
      {!isMobile && (
        <Sidebar 
          activeTab={activeTab}
          handleTabChange={handleTabChange}
          isLoading={isLoading}
        />
      )}

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobile && isMenuOpen && (
          <MobileMenu 
            isMenuOpen={isMenuOpen}
            setIsMenuOpen={setIsMenuOpen}
            activeTab={activeTab}
            handleTabChange={handleTabChange}
            isLoading={isLoading}
            me={me}
          />
        )}
      </AnimatePresence>

      {/* Loading Spinner */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center z-40"
          >
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 p-6 md:pb-6 pb-20 md:mr-72">
        <TabContent me={me} activeTab={activeTab} token={token} />
      </main>

      {/* Mobile Footer */}
      {isMobile && (
        <MobileFooter 
          activeTab={activeTab}
          handleTabChange={handleTabChange}
          isLoading={isLoading}
        />
      )}
    </div>
  );
}