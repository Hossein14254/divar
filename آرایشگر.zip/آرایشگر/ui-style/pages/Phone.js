import axios from 'axios';
import { AnimatePresence, motion } from 'framer-motion';
import Head from 'next/head';

import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { FiAlertCircle, FiArrowLeft, FiClock, FiMoon, FiPhone, FiRefreshCw, FiSun } from 'react-icons/fi';

export default function UltimateOTPLoginPage() {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '']);
  const [errors, setErrors] = useState({});
  const [alerts, setAlerts] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [theme, setTheme] = useState('light');
  const [isMobile, setIsMobile] = useState(false);
  const [token,setToken]=useState(null)
  const router = useRouter();

  // تشخیص دستگاه موبایل
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // تایمر برای ارسال مجدد کد
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // اعتبارسنجی شماره همراه
  const validatePhone = () => {
    const newErrors = {};
    if (!phone.trim()) newErrors.phone = 'شماره همراه الزامی است';
    else if (!/^09\d{9}$/.test(phone)) newErrors.phone = 'فرمت شماره همراه نامعتبر است';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // اعتبارسنجی کد OTP
  const validateOtp = () => {
    const newErrors = {};
    if (otp.some(digit => !digit)) newErrors.otp = 'لطفاً کد تأیید را کامل وارد کنید';
    else if (otp.join('').length !== 5) newErrors.otp = 'کد تأیید باید ۵ رقمی باشد';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ارسال کد تأیید
  const sendOtp = async (e) => {
    e.preventDefault();
    if (!validatePhone()) return;
    setIsLoading(true);
    //////////////////////////////////////////////////////////////////////////////////////////////////////////start
    const data = {
        identifier: phone,
      };
      
      const config = {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('yourToken')}`,
          'Content-Type': 'application/json'
        }
      };
      console.log(process.env.NEXT_PUBLIC_APIURL)
      axios.post(process.env.NEXT_PUBLIC_APIURL+"/auth/registerCode", data, config)
        .then(response => {
          console.log(response.data);
          console.log(response.status)
          setIsOtpSent(true);
          const newAlerts={}
          newAlerts.message=alerts.response?.data?.message;
          setErrors(newAlerts)
          return
        })
        .catch(error => {
            const newErrors={}
            newErrors.message=error.response?.data.message;
            setErrors(newErrors)
        });
        //////////////////////////////////////////////////////////////////////////////////////////////////////end
    try {
        
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCountdown(120); // 2 دقیقه تایمر
    } catch (error) {
      setErrors({ submit: 'خطا در ارسال کد! لطفاً دوباره تلاش کنید.' });
    } finally {
      setIsLoading(false);
    }
  };

  // تأیید کد OTP
  const verifyOtp = async (e) => {
    e.preventDefault();
    if (!validateOtp()) return;
    setIsLoading(true);

    //////////////////////////////////////////////////////////////////////////////////////////////////////////START
    //////////////////////////////////////////////////////////////////////////////////////////////////////////START
    const data = {
        identifier: phone,
        usercode: otp.join('')
       };
       
       fetch(process.env.NEXT_PUBLIC_APIURL+"/auth/registerCode", {
         method: "POST",
         headers: {
           "Authorization": `Bearer ${localStorage.getItem('yourToken')}`,
           "Content-Type": "application/json"
         },
         body: JSON.stringify(data)
       })
       .then(response => {
         if (!response.ok) {
           return response.json().then(errData => {
             throw { response: { data: errData } };
           });
         }
         return response.json();
       })
       .then(data => {
         const daysToExpire = 120;
         const date = new Date();
         date.setTime(date.getTime() + (daysToExpire * 24 * 60 * 60 * 1000)); // 120 روز به میلی‌ثانیه
         const expires = "expires=" + date.toUTCString();
         document.cookie = `yourToken=${data?.accessToken}; ${expires}; path=/;`;
         setToken(data?.accessToken)
       })
       .catch(error => {
         const newErrors = {};
         newErrors.message = error?.response?.data?.message;
         setErrors(newErrors);
         console.error('Error:', error);
       });
    //////////////////////////////////////////////////////////////////////////////////////////////////////////END
    //////////////////////////////////////////////////////////////////////////////////////////////////////////END
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
    //   router.push('/dashboard');
    } catch (error) {
      setErrors({ submit: 'کد تأیید نامعتبر است! لطفاً دوباره تلاش کنید.' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if(token!=null){
      router.push('/Dashboard')
    }
  }, [token])
  

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  // مدیریت ورود کد OTP (اصلاح شده برای حرکت چپ به راست)
  const handleOtpChange = (index, value) => {
    if (!/^\d*$/.test(value)) return; // فقط اعداد مجاز هستند
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // حرکت خودکار به فیلد بعدی (از چپ به راست)
    if (value && index < 4) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      if (nextInput) {
        nextInput.focus();
        nextInput.select(); // انتخاب محتوا برای جایگزینی آسان
      }
    }
  };

  // مدیریت حذف با backspace (اصلاح شده برای حرکت راست به چپ هنگام حذف)
  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      if (prevInput) {
        prevInput.focus();
        prevInput.select(); // انتخاب محتوا برای جایگزینی آسان
      }
    }
  };

  // انیمیشن‌ها
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <div dir="rtl" className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gradient-to-br from-blue-50 to-indigo-100 text-gray-800'}`}>
      <Head>
        <title>ورود با کد تأیید | سیستم مدیریت</title>
        <meta name="description" content="صفحه ورود با کد تأیید پیامکی" />
      </Head>

      <motion.div
        className={`w-full max-w-md mx-4 p-6 sm:p-8 rounded-2xl shadow-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* هدر */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <motion.h1 className="text-2xl font-bold" variants={itemVariants}>
              {isOtpSent ? 'تأیید شماره همراه' : 'ورود با کد تأیید'}
            </motion.h1>
            <motion.p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`} variants={itemVariants}>
              {isOtpSent ? 'کد ارسال شده را وارد کنید' : 'لطفاً شماره همراه خود را وارد کنید'}
            </motion.p>
          </div>
          <button onClick={toggleTheme} className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-yellow-300' : 'bg-gray-200 text-gray-700'}`}>
            {theme === 'dark' ? <FiSun /> : <FiMoon />}
          </button>
        </div>

        {/* پیام خطا */}
        <AnimatePresence>
          {errors.submit && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-6 p-3 bg-red-100 text-red-700 rounded-lg flex items-center"
            >
              <FiAlertCircle className="ml-2" />
              <span>{errors.submit}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {errors.message && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-6 p-3 bg-red-100 text-red-700 rounded-lg flex items-center"
            >
              <FiAlertCircle className="ml-2" />
              <span>{errors.message}</span>
            </motion.div>
          )}
        </AnimatePresence>
        <AnimatePresence>
          {alerts.message && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-6 p-3 bg-green-100 text-green-700 rounded-lg flex items-center"
            >
              <FiAlertCircle className="ml-2" />
              <span>{errors.message}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* فرم ورود */}
        <motion.form onSubmit={isOtpSent ? verifyOtp : sendOtp} variants={containerVariants} initial="hidden" animate="visible">
          {/* فیلد شماره همراه - فقط زمانی که کد ارسال نشده نمایش داده شود */}
          {!isOtpSent && (
            <motion.div variants={itemVariants}>
              <div className="mb-6">
                <label htmlFor="phone" className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  شماره همراه
                </label>
                <div className={`relative flex items-center rounded-lg overflow-hidden border ${errors.phone ? 'border-red-500' : theme === 'dark' ? 'border-gray-700 focus-within:border-blue-500' : 'border-gray-300 focus-within:border-blue-500'}`}>
                  <div className={`px-3 ${errors.phone ? 'text-red-500' : theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    <FiPhone />
                  </div>
                  <input
                    id="phone"
                    type="tel"
                    className={`w-full py-3 px-2 focus:outline-none bg-transparent text-right ${theme === 'dark' ? 'placeholder-gray-500' : 'placeholder-gray-400'}`}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    dir="ltr"
                  />
                </div>
                {errors.phone && (
                  <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-1 text-xs text-red-500 flex items-center justify-end">
                    <FiAlertCircle className="ml-1" /> {errors.phone}
                  </motion.p>
                )}
              </div>
            </motion.div>
          )}

          {/* فیلدهای کد تأیید - فقط زمانی که کد ارسال شده نمایش داده شود */}
          {isOtpSent && (
            <motion.div 
              variants={itemVariants}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="mb-6">
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  کد تأیید ۵ رقمی
                </label>
                <div style={{direction:'ltr'}} className="flex justify-between space-x-2">
                  {[0, 1, 2, 3, 4].map((index) => (
                    <input
                      key={index}
                      id={`otp-${index}`}
                      type="text"
                      maxLength="1"
                      className={`w-12 h-12 text-center text-xl rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.otp ? 'border-red-500' : 
                        theme === 'dark' ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-50'
                      }`}
                      value={otp[index]}
                      onChange={(e) => handleOtpChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      dir="ltr"
                    />
                  ))}
                </div>
                {errors.otp && (
                  <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-1 text-xs text-red-500 flex items-center justify-end">
                    <FiAlertCircle className="ml-1" /> {errors.otp}
                  </motion.p>
                )}

                <div className="mt-4 flex items-center justify-between">
                  <div className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    کد به شماره {phone} ارسال شد
                  </div>
                  {countdown > 0 ? (
                    <div className="flex items-center text-sm text-blue-500">
                      <FiClock className="ml-1" />
                      {Math.floor(countdown / 60)}:{String(countdown % 60).padStart(2, '0')}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={sendOtp}
                      className="flex items-center text-sm text-blue-500 hover:text-blue-700"
                    >
                      <FiRefreshCw className="ml-1" />
                      ارسال مجدد کد
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* دکمه ارسال/تأیید */}
          <motion.div variants={itemVariants}>
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3 px-4 rounded-lg font-medium flex items-center justify-center transition-all ${
                isLoading ? 'opacity-70 cursor-not-allowed' : 'hover:shadow-lg'
              } ${
                theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 
                'bg-gradient-to-r from-blue-600 to-indigo-700 text-white hover:from-blue-700 hover:to-indigo-800'
              }`}
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span className="mr-2">{isOtpSent ? 'در حال تأیید...' : 'در حال ارسال...'}</span>
                </>
              ) : isOtpSent ? 'تأیید کد' : 'ارسال کد تأیید'}
            </button>
          </motion.div>
        </motion.form>

        {/* تغییر روش ورود */}
        <motion.div className="mt-8 text-center" variants={itemVariants}>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            {isOtpSent ? (
              <button 
                onClick={() => {
                  setIsOtpSent(false);
                  setErrors({});
                }}
                className={`font-medium ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'}`}
              >
                تغییر شماره همراه
              </button>
            ) : (
              <>
                ثبت نام نکردید؟{' '}
                <a href="/Register" className={`font-medium ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'}`}>
                  کلیک کنید
                </a>
              </>
            )}
          </p>
        </motion.div>

        {/* فوتر */}
        <motion.div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center text-xs" variants={itemVariants}>
          <p className={theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}>
            با ورود یا ثبت‌نام، شما شرایط استفاده و حریم خصوصی ما را می‌پذیرید.
          </p>
          {isMobile && (
            <button onClick={() => router.back()} className="mt-4 flex items-center justify-center text-blue-500 mx-auto">
              <FiArrowLeft className="ml-1" />
              بازگشت
            </button>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}