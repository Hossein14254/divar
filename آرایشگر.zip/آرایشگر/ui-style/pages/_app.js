import "@/styles/globals.css";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const PUBLIC_PAGES = ['/Phone', '/Register', '/test'];

export default function App({ Component, pageProps }) {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [tokenme, setTokenme] = useState("");
  const [me, setMe] = useState(null);
  const router = useRouter();

  useEffect(() => {
    // PWA Installation Prompt
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        console.log('PWA installation available');
      });
    }

    const getTokenFromCookie = (cookieName) => {
      const nameEQ = cookieName + "=";
      const ca = document.cookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i].trim();
        if (c.indexOf(nameEQ) === 0) {
          return c.substring(nameEQ.length, c.length);
        }
      }
      return null;
    };

    const checkAuth = async () => {
      const isPublicPage = PUBLIC_PAGES.includes(router.pathname);
      const token = getTokenFromCookie('yourToken');

      setTokenme(token);

      if (!token) {
        setIsAuthenticated(false);
        setIsLoading(false);
        if (!isPublicPage) {
          router.replace('/Phone');
        }
        return;
      }

      try {
        const response = await fetch(process.env.NEXT_PUBLIC_APIURL+"/auth/getme", {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Token invalid or expired");
        }

        const data = await response.json();

        if (data?._id) {
          setIsAuthenticated(true);
          setMe(data);

          if (router.pathname === '/Phone') {
            router.replace('/Dashboard');
          }
        } else {
          setIsAuthenticated(false);
          if (!isPublicPage) {
            router.replace('/Phone');
          }
        }
      } catch (err) {
        console.error("Authentication Error:", err);
        setIsAuthenticated(false);
        if (!isPublicPage) {
          router.replace('/Phone');
        }
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, [router.pathname]);

  // اگر هنوز در حال بررسی احراز هویت است، spinner نمایش بده
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500"></div>
      </div>
    );
  }

  // صفحه عمومی: بدون بررسی auth رندر شود
  if (PUBLIC_PAGES.includes(router.pathname)) {
    return <Component token={tokenme} {...pageProps} />;
  }

  // اگر احراز هویت نشده
  if (!isAuthenticated) {
    return null; // صبر می‌کنه تا redirect انجام بشه
  }

  // اگر احراز هویت شده اما در صفحه‌ای به‌جز Dashboard هست
  if (isAuthenticated && router.pathname !== '/Dashboard') {
    router.replace('/Dashboard');
    return null;
  }

  // وضعیت نهایی: رندر کامپوننت با اطلاعات کاربر
  return <Component me={me} token={tokenme} {...pageProps} />;
}
