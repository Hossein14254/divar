import { motion } from 'framer-motion';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { FiAlertCircle, FiArrowLeft, FiMail, FiPhone } from 'react-icons/fi';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [currentTheme, setCurrentTheme] = useState('light');
  const [isMobile, setIsMobile] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const validateForm = () => {
    const newErrors = {};
    
    if (!email.trim()) {
      newErrors.email = 'ایمیل یا شماره همراه الزامی است';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !/^09\d{9}$/.test(email)) {
      newErrors.email = 'فرمت ایمیل یا شماره همراه صحیح نیست';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsSent(true);
    } catch (error) {
      setErrors({ submit: 'خطا در ارسال لینک بازیابی. لطفا مجددا تلاش کنید.' });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTheme = () => {
    setCurrentTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  return (
    <div dir="rtl" className={`min-h-screen flex items-center justify-center ${currentTheme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gradient-to-br from-blue-50 to-indigo-100 text-gray-800'}`}>
      <Head>
        <title>بازیابی رمز عبور | سامانه اختصاصی</title>
        <meta name="description" content="صفحه بازیابی رمز عبور" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <motion.div 
        className={`w-full max-w-md mx-4 p-6 sm:p-8 rounded-2xl shadow-xl ${currentTheme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <div>
            <motion.h1 
              className="text-2xl font-bold"
              variants={itemVariants}
            >
              {isSent ? 'ایمیل ارسال شد' : 'بازیابی رمز عبور'}
            </motion.h1>
            <motion.p 
              className={`text-sm ${currentTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}
              variants={itemVariants}
            >
              {isSent ? 'لینک بازیابی به ایمیل شما ارسال شد' : 'لطفا ایمیل یا شماره همراه خود را وارد کنید'}
            </motion.p>
          </div>
          <button 
            onClick={toggleTheme}
            className={`p-2 rounded-full ${currentTheme === 'dark' ? 'bg-gray-700 text-yellow-300' : 'bg-gray-200 text-gray-700'}`}
            aria-label="تغییر تم"
          >
            {currentTheme === 'dark' ? '☀️' : '🌙'}
          </button>
        </div>

        {errors.submit && (
          <motion.div 
            className="mb-6 p-3 bg-red-100 text-red-700 rounded-lg flex items-center text-right"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <FiAlertCircle className="ml-2" />
            <span>{errors.submit}</span>
          </motion.div>
        )}

        {isSent ? (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-center"
          >
            <motion.div variants={itemVariants} className="mb-6">
              <div className={`p-4 rounded-lg ${currentTheme === 'dark' ? 'bg-gray-700' : 'bg-blue-50'}`}>
                <p className={currentTheme === 'dark' ? 'text-gray-200' : 'text-blue-700'}>
                  لینک بازیابی رمز عبور به آدرس ایمیل شما ارسال شد. لطفاً صندوق ورودی خود را بررسی کنید.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="mt-6">
              <button
                onClick={() => router.push('/login')}
                className={`w-full py-3 px-4 rounded-lg font-medium transition-all hover:shadow-md ${currentTheme === 'dark' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gradient-to-r from-blue-600 to-indigo-700 text-white hover:from-blue-700 hover:to-indigo-800'}`}
              >
                بازگشت به صفحه ورود
              </button>
            </motion.div>
          </motion.div>
        ) : (
          <motion.form 
            onSubmit={handleSubmit}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={itemVariants}>
              <div className="mb-6">
                <label htmlFor="email" className={`block text-sm font-medium mb-2 text-right ${currentTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  ایمیل یا شماره همراه
                </label>
                <div className={`relative flex items-center rounded-lg overflow-hidden border ${errors.email ? 'border-red-500' : currentTheme === 'dark' ? 'border-gray-700 focus-within:border-blue-500' : 'border-gray-300 focus-within:border-blue-500'}`}>
                  <div className={`px-3 ${errors.email ? 'text-red-500' : currentTheme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    {/^09/.test(email) ? <FiPhone /> : <FiMail />}
                  </div>
                  <input
                    id="email"
                    type="text"
                    className={`w-full py-3 px-2 focus:outline-none bg-transparent ${/^09/.test(email) ? 'text-left' : 'text-right'} ${currentTheme === 'dark' ? 'placeholder-gray-500' : 'placeholder-gray-400'}`}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    dir={/^09/.test(email) ? 'ltr' : 'rtl'}
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-xs text-red-500 flex items-center justify-end">
                    <FiAlertCircle className="ml-1" /> {errors.email}
                  </p>
                )}
              </div>
            </motion.div>

            <motion.div variants={itemVariants}>
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-3 px-4 rounded-lg font-medium flex items-center justify-center transition-all ${isLoading ? 'opacity-70 cursor-not-allowed' : 'hover:shadow-md'} ${currentTheme === 'dark' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gradient-to-r from-blue-600 to-indigo-700 text-white hover:from-blue-700 hover:to-indigo-800'}`}
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span className="mr-2">در حال ارسال...</span>
                  </>
                ) : 'ارسال لینک بازیابی'}
              </button>
            </motion.div>
          </motion.form>
        )}

        <motion.div 
          className="mt-8 text-center"
          variants={itemVariants}
        >
          <p className={`text-sm ${currentTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            <a href="/login" className={`font-medium ${currentTheme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'}`}>
              بازگشت به صفحه ورود
            </a>
          </p>
        </motion.div>

        {isMobile && !isSent && (
          <motion.div 
            className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center"
            variants={itemVariants}
          >
            <button 
              onClick={() => router.back()}
              className="flex items-center justify-center text-blue-500 mx-auto"
            >
              <FiArrowLeft className="ml-1" />
              بازگشت
            </button>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}