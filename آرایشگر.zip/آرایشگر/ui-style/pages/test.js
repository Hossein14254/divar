import ProgressSteps from '@/mini-components/ProgressTracker';

export default function PersianTimePicker() {
  return (
<>
<ProgressSteps totalSteps={5} completedSteps={3} />      
  </>
  )
}