import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import express from 'express';
import jwt from 'jsonwebtoken';
import Morgan from 'morgan';
import multer from 'multer';
import connectDB from './config/db.js';




const Token ="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTEyLCJ1c2VybmFtZSI6Imhvc3NlaW4iLCJpYXQiOjE3NDgyNzQwNjIsImV4cCI6MTc0OTEzODA2Mn0.iNcOUSBu98dzKbpLBGuatFlpWUepU-vTz0zAXUJXvqU"
const accessToken=jwt.sign({id:112,username:"hossein"},'kjnefhjdsjnf',{
    expiresIn:'10 day'
})
try{
    const dataToken=jwt.verify(Token,'kjnefhjdsjnf')
    console.log(dataToken)
}catch(err){
    console.log("err:   *-*  ")
}
















dotenv.config();
const app = express();
app.use(express.json());
const uploads =multer({ dest:"uploads/",limits:{
    fileSize:1*1024*1024
}})

connectDB();
app.use(Morgan('dev'))

app.post('/post',uploads.single('profile'),async(req,res)=>{
    res.status(200).send(req.file.size/1000+"kb")
})

const salt=bcrypt.genSaltSync(10)
const hashpass=bcrypt.hashSync("0101",salt)

app.post('/pass',async(req,res)=>{
        // res.send(bcrypt.hashSync(req.body.pass,salt)==hashpass)
        res.send(bcrypt.compareSync(req.body.pass,hashpass))
})




app.get('/',async(req,res)=>{
    res.json(jsddf)
})
app.use((err, req, res, next) => {
    return res.status(err.status||500).json({
      statusCode: err.status || 500,
      msg: err.message || "Server Error !!",
    });
  });
  

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));