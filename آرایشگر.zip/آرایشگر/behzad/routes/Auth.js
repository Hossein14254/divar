import express from "express";
import AuthController from '../controllers/AuthController.js'; // import به صورت default
import aute from '../middlewares/AuteUser.js'
import AuteISadmin from "../middlewares/isAdmin.js";
import AuteisBarber from "../middlewares/isBarber.js";
import authController from "../controllers/AuthController.js";


const RouterUserAute = express.Router();

RouterUserAute.post('/register', AuthController.RegisterUser);
RouterUserAute.post('/registerCode', AuthController.LoginUserCode);

RouterUserAute.get('/getme',aute.isUser,
                            // AuteISadmin.IsAdmin,
                            // AuteisBarber.isBarber,
                            authController.GetMe);


RouterUserAute.post('/login', AuthController.LoginUser);


export default RouterUserAute;