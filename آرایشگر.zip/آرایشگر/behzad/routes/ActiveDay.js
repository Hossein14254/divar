import express from "express";
import ServicesController from "../controllers/ServicesController.js";
import ActiveDayController from "../controllers/ActiveDayController.js";
import AuteUser from "../middlewares/AuteUser.js";

const RouterActiveDay = express.Router();

RouterActiveDay.post('/new',AuteUser.isUser,ActiveDayController.NewDay)
RouterActiveDay.get('/',ActiveDayController.GetALL)
RouterActiveDay.get('/:num',ActiveDayController.GetWeekDays)


export default RouterActiveDay;