import express from "express";
import ServicesController from "../controllers/ServicesController.js";
import AuteUser from "../middlewares/AuteUser.js";

const RouterServices = express.Router();

RouterServices.post('/new',AuteUser.isUser, ServicesController.NewService)
RouterServices.delete('/delete/:serviceid',AuteUser.isUser, ServicesController.DeleteService)
RouterServices.get('/', ServicesController.GetALL)



export default RouterServices;