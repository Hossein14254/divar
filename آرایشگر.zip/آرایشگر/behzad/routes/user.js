import express from "express";
import AuteUser from "../middlewares/AuteUser.js";
import isAdmin from "../middlewares/isAdmin.js";
import UserController from "../controllers/UserController.js";

const RouterUser = express.Router();
RouterUser.post('/ban/:userid',AuteUser.isUser,isAdmin.IsAdmin,UserController.Ban);
RouterUser.post('/barber/:userid',AuteUser.isUser,isAdmin.IsAdmin,UserController.Barber);
RouterUser.put('/role/:userid',AuteUser.isUser,isAdmin.IsAdmin,UserController.PutRole);
RouterUser.post('/wallet',AuteUser.isUser,isAdmin.IsAdmin,UserController.PutWallet);
RouterUser.put('/',AuteUser.isUser, UserController.PutUser);
RouterUser.get('/',AuteUser.isUser,UserController.GetALL)
RouterUser.get('/barber',UserController.GetALLBarber)


export default RouterUser;