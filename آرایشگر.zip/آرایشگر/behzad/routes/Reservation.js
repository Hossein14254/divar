import express from "express";
import LeaveController from "../controllers/LeaveController.js";
import ReservationController from "../controllers/ReservationController.js";
import AuteUser from "../middlewares/AuteUser.js";

const RouterReservation = express.Router();

RouterReservation.post('/new',AuteUser.isUser,ReservationController.NewReservation)
RouterReservation.get('/get/:provider_id/:date_id',ReservationController.GetWorkingHour)
RouterReservation.get('/get/:date',AuteUser.isUser,ReservationController.GetAllReservationsByDate)
RouterReservation.get('/me',AuteUser.isUser,ReservationController.GetReservationMe)
RouterReservation.put('/put/:ReservationID/:status',AuteUser.isUser,ReservationController.PutStatus)
RouterReservation.get('/dashboard/:date',AuteUser.isUser,ReservationController.GetByDate)
RouterReservation.get('/me20',AuteUser.isUser,ReservationController.GetALL20me)





export default RouterReservation;