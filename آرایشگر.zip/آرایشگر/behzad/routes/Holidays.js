import express from "express";
import AuteUser from "../middlewares/AuteUser.js";
import isAdmin from "../middlewares/isAdmin.js";
import holidaysController from "../controllers/HolidaysController.js";

const RouterHolidays = express.Router();

RouterHolidays.post('/new',AuteUser.isUser, holidaysController.NewDey)
RouterHolidays.delete('/delete/:holideyid',AuteUser.isUser, holidaysController.DeleteHolidey)

RouterHolidays.get('/', holidaysController.GetALL)



export default RouterHolidays;