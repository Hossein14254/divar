import express from "express";
import AuteUser from "../middlewares/AuteUser.js";
import isAdmin from "../middlewares/isAdmin.js";
import UserController from "../controllers/UserController.js";
import NotificationController from "../controllers/NotificationController.js";

const RouterNotification = express.Router();

RouterNotification.post('/',AuteUser.isUser,isAdmin.IsAdmin, NotificationController.GetALL)
RouterNotification.post('/free',AuteUser.isUser ,NotificationController.GetALLfree)
RouterNotification.get('/free4',AuteUser.isUser ,NotificationController.GetALL4)



export default RouterNotification;