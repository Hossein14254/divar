import express from "express";
import workingHourController from "../controllers/WorkingHourController.js";
import AuteUser from "../middlewares/AuteUser.js";


const RouterWorkingHour = express.Router();

RouterWorkingHour.post('/new',AuteUser.isUser, workingHourController.NewHour)
RouterWorkingHour.delete('/delete/:hourid',AuteUser.isUser, workingHourController.DeleteHour)
RouterWorkingHour.get('/', workingHourController.GetALL)



export default RouterWorkingHour;