import express from "express";
import LeaveController from "../controllers/LeaveController.js";
import AuteUser from "../middlewares/AuteUser.js";

const RouterLeave = express.Router();

RouterLeave.post('/new',AuteUser.isUser,LeaveController.NewLeave)
RouterLeave.delete('/delete/:leaveId',AuteUser.isUser,LeaveController.DeleteLeave)
RouterLeave.get('/',LeaveController.GetAll)



export default RouterLeave;