import mongoose from 'mongoose';

const holidaySchema = new mongoose.Schema({
    date: {
        type: Date,
    },
    description: {
        type: String,
        required: true
    }
});

const HolidayModel=  mongoose.models.Holiday || mongoose.model('Holiday', holidaySchema);
export default HolidayModel
