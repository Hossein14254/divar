// models/WorkingHour.js
import mongoose from "mongoose";

const workingHourSchema = new mongoose.Schema({
    start_time: {
        type: String,
        required: true,
    },
    end_time: {
        type: String,
        required: true,
    },
    is_active:{
        type:Boolean,
        default:true
    }
});

const WorkingHour = mongoose.models.WorkingHour || mongoose.model('WorkingHour', workingHourSchema);
export default WorkingHour;

