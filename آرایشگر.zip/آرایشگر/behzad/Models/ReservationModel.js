import mongoose from 'mongoose';

const ReservationSchema = new mongoose.Schema({
    customer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: [true, 'شناسه مشتری الزامی است'],
    },
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: [true, 'شناسه آرایشگر الزامی است'],
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services',
        required: [true, 'شناسه خدمت الزامی است'],
    },
    date_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ActiveDay',
        required: [true, 'شناسه روز کاری الزامی است'],
    },
    workingHour_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WorkingHour',
        required: [true, 'شناسه ساعت کاری الزامی است'],
    },
    status: {
        type: String,
        enum: ['pending','confirmed', 'cancelled','no-show'],
        default: 'pending',
    },
},{timeseries:true});

const ReservationModel = mongoose.models.Reservation || mongoose.model('Reservation', ReservationSchema);
export default ReservationModel;