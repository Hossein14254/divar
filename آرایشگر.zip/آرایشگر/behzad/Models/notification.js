import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    text: {
        type: String,
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User' // به مدل User (مربوط به کاربر) اشاره کنید
    },
    userId2: {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        ref: 'User' // به مدل User (مربوط به کاربر) اشاره کنید
    },
    importance: {
        type: Number,
        required: true,
        min: 1,
        max: 10
    }
}, { timestamps: true }); // 'timestamps' به درستی نوشته شده باشد

const NotificationModel = mongoose.models.Notification ||mongoose.model('Notification', notificationSchema); // نام مدل باید Notification باشد

export default NotificationModel;