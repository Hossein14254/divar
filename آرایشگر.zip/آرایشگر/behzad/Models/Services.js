import mongoose from 'mongoose';

const ServicesSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'نام الزامی است'],
    },
    description: {
        type: String,
    },
    price: {
        type: Number,
        required: [true, 'مبلغ الزامی است'],
    },
    minute: {
        type: Number,
        required: [true, 'زمان لازم برای این خدمات الزامی است'],
    },
    is_active: {
        type: Boolean,
        default: true
    }
}, { timeseries: true });

const ServicesModel = mongoose.models.Services || mongoose.model('Services', ServicesSchema);
export default ServicesModel;