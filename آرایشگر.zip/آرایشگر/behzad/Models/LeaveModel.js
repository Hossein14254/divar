import mongoose from 'mongoose';

const LeaveSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'عنوان مرخصی الزامی است'],
    },
    date_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ActiveDay',
        required: [true, 'شناسه روز الزامی است'],
    },
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: [true, 'شناسه آرایشگر الزامی است'],
    },
    WorkingHour_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WorkingHour',
        required: [true, 'شناسه ساعت کاری الزامی است'],
    },
    is_active: {
        type: Boolean,
        default: true,
    },
});

const LeaveModel = mongoose.models.Leave || mongoose.model('Leave', LeaveSchema);
export default LeaveModel;