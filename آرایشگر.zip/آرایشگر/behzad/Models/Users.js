import mongoose from "mongoose";

const userSchema =new mongoose.Schema({
    name:{
        type:String,
        required: [true, 'نام الزامی است'],
    },
    phone:{
        type:Number,
        required:[true,'شماره تماس الزامی هست']
    },
    password: {
        type: String,
        required: [true, 'رمز عبور الزامی است'],
        minlength: [6, 'رمز عبور باید حداقل ۶ کاراکتر باشد'],
    },
    isbarber:{
        type:Boolean,
        default:false
    },
    ban:{
        type:Boolean,
        default:false
    },
    role: {
        type: String,
        enum: ['USER', 'ADMIN', 'ADMINPRO'],
        default: 'USER',
    },
    wallet:{
        type:Number,
        default:0
    }
},{timeStamp:true})
const UserModel = mongoose.models.user || mongoose.model('user', userSchema); // اگر مدل وجود ندارد، آن را تعریف کنید

export default  UserModel;