import mongoose from 'mongoose';

const ActiveDaySchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'نام الزامی است'],
    },
    date: {
        type: Date,
    },
    is_active: {
        type: Boolean,
        default: true
    }
}, { timeseries: true });

const ActiveDayModel = mongoose.models.ActiveDay || mongoose.model('ActiveDay', ActiveDaySchema);
export default ActiveDayModel;