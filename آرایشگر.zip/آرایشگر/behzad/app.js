import dotenv from 'dotenv';
import express from 'express';
import Morgan from 'morgan';
import connectDB from './config/db.js';
import flash from 'express-flash';
import RouterUserAute from "./routes/Auth.js";
import RouterUser from "./routes/user.js";
import RouterNotification from "./routes/Notification.js";
import RouterHolidays from "./routes/Holidays.js";
import cors from 'cors';
import RouterWorkingHour from "./routes/WorkingHour.js";
import RouterServices from "./routes/Services.js";
import ActiveDayServices from "./routes/ActiveDay.js";
import RouterActiveDay from "./routes/ActiveDay.js";
import RouterLeave from "./routes/Leave.js";
import RouterReservation from "./routes/Reservation.js";



dotenv.config();
const app = express();
app.use(cors());
connectDB();
app.use(Morgan('dev'))
app.use(express.json()); // برای پردازش JSON
app.use(express.urlencoded({ extended: true })); // برای پردازش فرم‌های url-encoded

app.use(flash());



app.use('/auth', RouterUserAute);
app.use('/user',RouterUser)
app.use('/not',RouterNotification)
app.use('/holidays', RouterHolidays);
app.use('/workinghour',RouterWorkingHour)
app.use('/services',RouterServices)
app.use('/activeday',RouterActiveDay)
app.use('/leave',RouterLeave)
app.use('/reservation',RouterReservation)



app.use((req, res, next) => {
    res.status(404).json({ message: "این لینک اشتباه هست در سیستم چنین لینکی نداریم" });
});

app.use((err, req, res, next) => {
    return res.status(err.status||500).json({
      statusCode: err.status || 500,
      msg: err.message || "Server Error !!",
    });
  });
  
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));