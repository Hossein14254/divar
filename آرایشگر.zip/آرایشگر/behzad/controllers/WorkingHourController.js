import mongoose from "mongoose";
import WorkingHourModel from "../Models/WorkingHourModel.js";
import NewNotification from "../middlewares/NewNotification.js";

// تابع کمکی برای تبدیل زمان HH:mm به دقیقه
const timeToMinutes = (time) => {
    const [hours, minutes] = time.split(":").map(Number);
    return hours * 60 + minutes;
};
const NewHour = async (req, res) => {
    try {
        const { start_time, end_time } = req.body;

        // 1. لاگ ورودی‌ها
        console.log(`دریافت درخواست: start_time=${start_time}, end_time=${end_time}`);

        // 2. اعتبارسنجی ورودی‌ها
        if (!start_time || !end_time) {
            console.log("خطا: ساعت شروع یا پایان وارد نشده است.");
            return res.status(400).json({ message: "لطفاً ساعت شروع و پایان را وارد کنید." });
        }

        // 3. اعتبارسنجی فرمت زمان (HH:mm)
        const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
        if (!timeRegex.test(start_time) || !timeRegex.test(end_time)) {
            console.log("خطا: فرمت زمان نامعتبر است.", { start_time, end_time });
            return res.status(400).json({ message: "فرمت زمان نامعتبر است. از فرمت HH:mm استفاده کنید." });
        }

        // 4. تبدیل زمان به دقیقه
        const startInMinutes = timeToMinutes(start_time);
        const endInMinutes = timeToMinutes(end_time);
        console.log(`تبدیل زمان: start_time=${start_time} -> ${startInMinutes} دقیقه, end_time=${end_time} -> ${endInMinutes} دقیقه`);

        // 5. بررسی اینکه ساعت پایان بعد از ساعت شروع باشد
        if (endInMinutes <= startInMinutes) {
            console.log("خطا: ساعت پایان قبل یا برابر با ساعت شروع است.", { startInMinutes, endInMinutes });
            return res.status(400).json({ message: "ساعت پایان باید بعد از ساعت شروع باشد." });
        }

        // 6. بررسی اینکه زمان‌ها بین 00:00 و 24:00 باشند
        if (startInMinutes < 0 || endInMinutes > 24 * 60) {
            console.log("خطا: زمان خارج از بازه 00:00 تا 24:00 است.", { startInMinutes, endInMinutes });
            return res.status(400).json({ message: "ساعت کاری باید بین 00:00 و 24:00 باشد." });
        }

        // 7. بررسی تداخل با ساعت‌های کاری فعال
        const existingHours = await WorkingHourModel.find({ is_active: true });
        let hasOverlap = false;
        for (const hour of existingHours) {
            const existingStartInMinutes = timeToMinutes(hour.start_time);
            const existingEndInMinutes = timeToMinutes(hour.end_time);
            // بررسی تداخل: اگر بازه جدید با بازه موجود حتی یک دقیقه همپوشانی داشته باشد
            if (!(endInMinutes <= existingStartInMinutes || startInMinutes >= existingEndInMinutes)) {
                hasOverlap = true;
                console.log("تداخل یافت شد:", {
                    new: { start_time, end_time, startInMinutes, endInMinutes },
                    existing: {
                        start_time: hour.start_time,
                        end_time: hour.end_time,
                        startInMinutes: existingStartInMinutes,
                        endInMinutes: existingEndInMinutes
                    }
                });
                break;
            }
        }

        if (hasOverlap) {
            console.log("خطا: تداخل با ساعت کاری فعال موجود وجود دارد.");
            return res.status(400).json({ message: "تداخل با ساعت کاری فعال موجود وجود دارد." });
        }

        // 8. ایجاد ساعت کاری جدید
        const newWorkingHour = new WorkingHourModel({
            start_time,
            end_time,
            is_active: true
        });

        // 9. ذخیره در دیتابیس
        await newWorkingHour.save();
        console.log("ساعت کاری جدید با موفقیت ثبت شد:", {
            start_time,
            end_time,
            id: newWorkingHour._id
        });

        NewNotification(
            'ساعت کاری جدید',
            `کاربر ${req.user.name} ساعت کاری جدید از ${start_time} تا ${end_time} ثبت کرد.`,
            req.user._id,
            null,
            3
        );
        return res.status(201).json({
            message: "ساعت کاری با موفقیت ثبت شد.",
            workingHour: newWorkingHour
        });

    } catch (error) {
        // 11. مدیریت خطاها و لاگ‌گیری
        console.error("خطا در ثبت ساعت کاری:", error);
        return res.status(500).json({ message: "خطای سرور در ثبت ساعت کاری." });
    }
};

const GetALL=async(req,res)=>{
    const Hour=await WorkingHourModel.find({is_active:true}).select('-__v');
    res.status(200).json({
        Hour
    })
}

const DeleteHour=async (req,res)=>{
    try {
        const {hourid}=req.params;
        const isvalidhourid=mongoose.isValidObjectId(hourid)
        if(!hourid){
            return res.status(401).json({
                message:"ای دی ارسالی شما معتبر نمی باشد."
            })
        }
        const hour = await WorkingHourModel.findByIdAndUpdate(
            hourid,
            { is_active: false },
            { new: true }
        ).lean();

        if(hour){
            NewNotification(
                'حذف ساعت کاری',
                `کاربر ${req.user.name} ساعت کاری از ${hour.start_time} تا ${hour.end_time} را حذف کرد.`,
                req.user._id,
                null,
                3
            );

            return  res.status(200).json({
                message:"ساعت کاری اعلامی شما با موفیت حذف شد.",
                hour:hour
            })
        }else {
            res.status(409).json({
                message:"چنین ساعت کاری وجود ندارد.",
            })
        }

    }catch (e) {
        res.status(500).json({
            message:"خطای سرور",
            e:e.message
        })
    }
}


export default {GetALL,DeleteHour,NewHour}

