import ReservationModel from "../Models/ReservationModel.js";
import ActiveDayModel from "../Models/ActiveDay.js";
import HolidayModel from "../Models/Holiday.js";
import ServicesModel from "../Models/Services.js";
import WorkingHourModel from "../Models/WorkingHourModel.js";
import LeaveModel from "../Models/LeaveModel.js";
import UserModel from "../Models/Users.js";
import mongoose from 'mongoose';
import NewNotification from "../middlewares/NewNotification.js";
import {populate} from "dotenv";
import jalaali from 'jalaali-js';
import NotificationModel from "../Models/notification.js";




const GetAllReservationsByDate = async (req, res) => {
    try {
        const { date } = req.params;

        // 1. اعتبارسنجی ورودی date
        if (!date) {
            console.log('خطا: تاریخ ارائه نشده است');
            return res.status(400).json({
                message: 'تاریخ الزامی است.',
            });
        }

        // 2. تبدیل تاریخ ورودی به شیء Date
        const inputDate = new Date(date);
        if (isNaN(inputDate)) {
            console.log('خطا: فرمت تاریخ نامعتبر است', { date });
            return res.status(400).json({
                message: 'فرمت تاریخ نامعتبر است. از فرمت YYYY-MM-DD استفاده کنید.',
            });
        }
        // 3. تنظیم تاریخ برای مقایسه فقط روز، ماه، سال
        const inputDateOnly = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate());

        // 4. یافتن روز کاری (ActiveDay) مرتبط با تاریخ
        const activeDay = await ActiveDayModel.findOne({
            date: {
                $gte: inputDateOnly,
                $lt: new Date(inputDateOnly.getTime() + 24 * 60 * 60 * 1000),
            },
        });

        if (!activeDay) {
            return res.status(404).json({
                message: 'روز کاری برای تاریخ مشخص‌شده یافت نشد یا غیرفعال است.',
            });
        }

        let filter = { date_id: activeDay._id };


// یافتن رزروهای مربوط به date_id
        const reservations = await ReservationModel.find(filter)
            .select('-__v')
            .populate('customer_id', 'name phone') // فقط نام مشتری
            .populate('provider_id', 'name') // فقط نام آرایشگر
            .populate('service_id', 'title price') // عنوان و قیمت خدمت
            .populate('workingHour_id', 'start_time end_time'); // ساعت کاری


        // 7. پاسخ موفق
        return res.status(200).json({
            message: `رزروهای ${date} با موفقیت دریافت شدند.`,
            filter:filter,
            reservations,
        });
    } catch (error) {
        // 8. لاگ خطا
        console.error('خطا در دریافت رزروها:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در دریافت رزروها.',
            error: error.message,
        });
    }
};
const GetByDate = async (req, res) => {
    try {
        const { date } = req.params;

        // 1. اعتبارسنجی ورودی date
        if (!date) {
            console.log('خطا: تاریخ ارائه نشده است');
            return res.status(400).json({
                message: 'تاریخ الزامی است.',
            });
        }

        // 2. تبدیل تاریخ ورودی به شیء Date
        const inputDate = new Date(date);
        inputDate.setMinutes(inputDate.getMinutes() + 210);
        console.log(inputDate)
        if (isNaN(inputDate)) {
            console.log('خطا: فرمت تاریخ نامعتبر است', { date });
            return res.status(400).json({
                message: 'فرمت تاریخ نامعتبر است. از فرمت YYYY-MM-DD استفاده کنید.',
            });
        }

        // 3. تنظیم تاریخ برای مقایسه فقط روز، ماه، سال
        const inputDateOnly = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate());

        // 4. یافتن روز کاری (ActiveDay) مرتبط با تاریخ
        const activeDay = await ActiveDayModel.findOne({
            date: {
                $gte: inputDateOnly,
                $lt: new Date(inputDateOnly.getTime() + 24 * 60 * 60 * 1000),
            },
            is_active: true,
        });
        const sumUsers = await UserModel.countDocuments();
        const sumReservations=await  ReservationModel.countDocuments();
        if (!activeDay) {
            return res.status(200).json({
                message: 'روز کاری برای تاریخ مشخص‌شده یافت نشد یا غیرفعال است.',
                reservations:[],
                sumUsers,
                sumReservations
            });
        }
        const role=req.user.role;
        const isbarber=req.user.isbarber;
        let filter={}
        if(isbarber==true){
            filter = { date_id: activeDay._id};
        }else{
            filter = { date_id: activeDay._id,
                customer_id : req.user._id
            };
        }
        console.log(isbarber)



// یافتن رزروهای مربوط به date_id
        const reservations = await ReservationModel.find(filter)
            .select('-__v')
            .populate('customer_id', 'name phone') // فقط نام مشتری
            .populate('provider_id', 'name') // فقط نام آرایشگر
            .populate('service_id', 'title price') // عنوان و قیمت خدمت
            .populate('workingHour_id', 'start_time end_time'); // ساعت کاری


        // 7. پاسخ موفق
        return res.status(200).json({
            message: `گزارش تاریخ ${date} با موفقیت دریافت شدند.`,
            filter:filter,
            reservations,
            sumUsers,
            sumReservations
        });
    } catch (error) {
        // 8. لاگ خطا
        console.error('خطا در دریافت رزروها:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در دریافت رزروها.',
            error: error.message,
        });
    }
};
const NewReservation = async (req, res) => {
    try {
        const customer_id = req.user._id;
        const wallet=req.user.wallet;
        const { provider_id, service_id, date_id, workingHour_id } = req.body;

        if (!customer_id || !provider_id || !service_id || !date_id || !workingHour_id) {
            return res.status(400).json({
                message: 'شناسه مشتری، آرایشگر، خدمت، روز کاری و ساعت کاری الزامی هستند.',
            });
        }

        if (!mongoose.isValidObjectId(customer_id) || !mongoose.isValidObjectId(provider_id) ||
            !mongoose.isValidObjectId(service_id) || !mongoose.isValidObjectId(date_id) ||
            !mongoose.isValidObjectId(workingHour_id)) {
            return res.status(400).json({
                message: 'یک یا چند شناسه نامعتبر است.',
            });
        }

        const service = await ServicesModel.findById(service_id);
        if (!service || !service.is_active) {
            return res.status(400).json({
                message: 'خدمت با این شناسه یافت نشد یا غیرفعال است.',
            });
        }
        if (service.price > wallet) {
            return res.status(400).json({
                message: 'موجودی کیف پول شما برای انجام این عملیات کافی نیست.',
            });
        }

        const activeDay = await ActiveDayModel.findById(date_id);
        if (!activeDay || !activeDay.is_active) {
            return res.status(400).json({
                message: 'روز کاری با این شناسه یافت نشد یا غیرفعال است.',
            });
        }

        const inputDateOnly = new Date(activeDay.date);
        inputDateOnly.setHours(0, 0, 0, 0);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (inputDateOnly < today) {
            return res.status(400).json({
                message: 'تاریخ رزرو باید امروز یا بعد از امروز باشد.',
            });
        }

        const workingHour = await WorkingHourModel.findById(workingHour_id);
        if (!workingHour || !workingHour.is_active) {
            return res.status(400).json({
                message: 'ساعت کاری با این شناسه یافت نشد یا غیرفعال است.',
            });
        }

        const existingLeave = await LeaveModel.findOne({
            date_id,
            provider_id,
            WorkingHour_id: workingHour_id,
            is_active: true,
        });
        if (existingLeave) {
            return res.status(400).json({
                message: 'این ساعت کاری به دلیل مرخصی آرایشگر در دسترس نیست.',
            });
        }

        const newStart = timeToMinutes(workingHour.start_time);
        const newEnd = timeToMinutes(workingHour.end_time);

        // دریافت همه رزروهای فعال آن روز برای آن آرایشگر
        const existingReservations = await ReservationModel.find({
            date_id: new mongoose.Types.ObjectId(date_id),
            provider_id: new mongoose.Types.ObjectId(provider_id),
            status: { $in: ['pending', 'confirmed'] },
        }).populate('workingHour_id');

        // بررسی تداخل زمانی
        const hasOverlap = existingReservations.some(res => {
            const existingStart = timeToMinutes(res.workingHour_id.start_time);
            const existingEnd = timeToMinutes(res.workingHour_id.end_time);
            return !(existingEnd <= newStart || existingStart >= newEnd);
        });

        if (hasOverlap) {
            return res.status(400).json({
                message: 'تداخل زمانی با رزروهای دیگر وجود دارد.',
            });
        }

        const serviceDuration = service.minute;
        const workingHourStart = timeToMinutes(workingHour.start_time);
        const workingHourEnd = timeToMinutes(workingHour.end_time);
        if (workingHourEnd - workingHourStart < serviceDuration) {
            return res.status(400).json({
                message: 'مدت زمان ساعت کاری برای این خدمت کافی نیست',
            });
        }

        const dateday = await ActiveDayModel.findById(date_id).lean();
        const Holiday = await HolidayModel.find({ date: dateday.date }).lean();
        if (Holiday && Holiday.length > 0) {
            return res.status(400).json({
                message: 'امکان رزرو به دلیل تعطیلی وجود ندارد.',
                Holiday: Holiday
            });
        }

        const newReservation = await ReservationModel.create({
            customer_id,
            provider_id,
            service_id,
            date_id,
            workingHour_id,
            status: 'pending',
        });
        const provider = await UserModel.findById(provider_id);

// تبدیل تاریخ میلادی به شمسی
        const date = new Date(activeDay.date);
        const jDate = jalaali.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
        const formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;

        const notificationText = `کاربر ${req.user.name} رزرو جدیدی برای آرایشگر ${provider.name} در تاریخ ${formattedDate} از ساعت ${workingHour.start_time} تا ${workingHour.end_time} ثبت کرد.`;

// ارسال نوتیفیکیشن
        const wallets=await UserModel.findByIdAndUpdate(req.user._id,{wallet:wallet-service.price})
        NewNotification(
            'رزرو جدید',
            notificationText,
            req.user._id,
            null,
            1
        );
        NewNotification(
            'برداشت',
            `${service.price} تومان کسر از موجودی کیف پول برای رزرو نوبت `,
            req.user._id,
            null,
            4
        );
        return res.status(201).json({
            message: 'رزرو با موفقیت ثبت شد.',
            reservation: newReservation,
        });

    } catch (error) {
        console.error('خطا در ثبت رزرو:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در ثبت رزرو.',
            error: error.message,
        });
    }
};
const PutStatus=async (req,res)=>{
    try {
        const {ReservationID,status}=req.params;
        const isvalidReservationID = mongoose.isValidObjectId(ReservationID)
        if(!isvalidReservationID){
            res.status(400).json({
                message:"شناسه رزرو معتبر نمی باشد."
            })
        }
        const Reservation=await ReservationModel.findById(ReservationID).lean()
        if(!Reservation){
            res.status(400).json({
                message:"شناسه رزرو معتبر نمی باشد."
            })
        }
        if (status !== "pending" && status !== "cancelled" && status !== "no-show"&& status !== "confirmed") {
            res.status(400).json({
                message:"وضعیت معتبر نمی باشد."
            })
        }
        const newReservation = await ReservationModel.findByIdAndUpdate(ReservationID, {
            status: status
        }, { new: true })
            .populate('customer_id', 'name phone')
            .populate('provider_id', 'name')
            .populate('service_id', 'title price')
            .populate('workingHour_id', 'start_time end_time')
            .populate('date_id', 'date'); // فقط فیلد تاریخ

        const statusLabels = {
            pending: 'در انتظار',
            confirmed: 'تایید شده',
            cancelled: 'لغو شده',
            'no-show': 'عدم حضور',
        };

        const statusFa = statusLabels[status] || status; // اگر استاتوس ناشناخته بود، خودِ مقدار رو بذار

        const dateStr = new Date(newReservation.date_id.date).toLocaleDateString('fa-IR');

        const text = `کاربر ${req.user.name} وضعیت رزرو مشتری ${newReservation.customer_id.name} برای سرویس "${newReservation.service_id.title}" در تاریخ ${dateStr} از ${newReservation.workingHour_id.start_time} تا ${newReservation.workingHour_id.end_time} را به "${statusFa}" تغییر داد.`;

        NewNotification(
            'تغییر وضعیت رزرو',
            text,
            req.user._id,
            null,
            3
        );

        res.status(200).json({
            message:"وضعیت با موفقیت تغیر پیدا کرد.",
            Reservation:newReservation
        })
    }catch (e) {
        return res.status(500).json({
            message: 'خطای سرور',
            error: e.message,
        });
    }

}
const GetReservationMe =async (req,res)=>{
    const userid=req.user._id;
    const ReservationMe = await ReservationModel.find({customer_id:userid}).sort({ _id: -1 }).limit(20).select('-__v')
        .populate('customer_id', 'name phone')
        .populate('provider_id', 'name')
        .populate('service_id', 'title price')
        .populate('date_id', 'date')
        .populate('workingHour_id', 'start_time end_time');
    return res.status(200).json({
        message:"رزرو های شما : ",
        ReservationMe:ReservationMe
    })
    }
const GetWorkingHour = async (req, res) => {
    try {
        const { date_id, provider_id } = req.params;

        if (!date_id || !provider_id) {
            return res.status(400).json({ message: 'شناسه روز کاری و آرایشگر الزامی هستند.' });
        }

        if (!mongoose.isValidObjectId(date_id) || !mongoose.isValidObjectId(provider_id)) {
            return res.status(400).json({ message: 'شناسه روز کاری یا آرایشگر نامعتبر است.' });
        }

        const activeDay = await ActiveDayModel.findById(date_id);
        if (!activeDay || !activeDay.is_active) {
            return res.status(400).json({ message: 'روز کاری یافت نشد یا غیرفعال است.' });
        }

        const inputDateOnly = new Date(activeDay.date);
        inputDateOnly.setHours(0, 0, 0, 0);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (inputDateOnly < today) {
            return res.status(400).json({ message: 'تاریخ رزرو باید امروز یا بعد از امروز باشد.' });
        }

        const holiday = await HolidayModel.findOne({
            date: {
                $gte: inputDateOnly,
                $lt: new Date(inputDateOnly.getTime() + 24 * 60 * 60 * 1000),
            },
            is_active: true,
        });
        if (holiday) {
            return res.status(400).json({ message: 'امکان رزرو به دلیل تعطیلی وجود ندارد.' });
        }

        const provider = await UserModel.findById(provider_id);
        if (!provider || provider.isbarber !== true) {
            return res.status(400).json({ message: 'آرایشگر با این شناسه یافت نشد یا نقش معتبر نیست.' });
        }

        const workingHours = await WorkingHourModel.find({ is_active: true })
            .select('start_time end_time')
            .lean();

        const leaves = await LeaveModel.find({
            date_id,
            provider_id,
            is_active: true,
        }).select('WorkingHour_id').lean();

        // ✅ تغییر مهم در اینجا:
        const reservations = await ReservationModel.find({
            provider_id,
            date_id,
            status: { $in: ['pending', 'confirmed'] },
        }).select('workingHour_id').lean();

        const leaveHours = leaves.map(leave => leave.WorkingHour_id.toString());
        const reservedHours = reservations.map(res => res.workingHour_id.toString());

        const workingHoursWithStatus = workingHours.map(hour => ({
            _id: hour._id,
            start_time: hour.start_time,
            end_time: hour.end_time,
            status: leaveHours.includes(hour._id.toString())
                ? 'onLeave'
                : reservedHours.includes(hour._id.toString())
                    ? 'reserved'
                    : 'available',
        })).filter(hour => hour.status === 'available');

        return res.status(200).json({
            message: `ساعت‌های کاری برای آرایشگر در تاریخ ${activeDay.date.toISOString().split('T')[0]} دریافت شدند.`,
            workingHours: workingHoursWithStatus,
        });

    } catch (error) {
        console.error('خطا در دریافت ساعت‌های کاری:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در دریافت ساعت‌های کاری.',
            error: error.message,
        });
    }
};
const GetALL20me=async(req,res)=>{
    const userid=req.user._id;
    let nots=[]
        nots = await ReservationModel.find({
            $or: [
                { customer_id: userid },
            ]
        }).sort({ _id: -1 }).limit(20).select('-__v');

    console.log(nots[0])
    res.status(200).json({
        nots
    })
}




// تابع کمکی برای تبدیل زمان به دقیقه
const timeToMinutes = (time) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};
export default {GetAllReservationsByDate,NewReservation,GetWorkingHour,PutStatus,GetReservationMe,GetByDate,GetALL20me}

