import mongoose from "mongoose";
import NotificationModel from "../Models/notification.js";
import User from "../routes/user.js";
import UserModel from "../Models/Users.js";
const GetALL = async (req, res) => {
    try {
        const { title, phone, importance, limit } = req.body;
        const role = req.user.role;
        const userid = req.user._id;

        let query = {};

        // فیلتر بر اساس نقش کاربر
        if (role !== "ADMINPRO") {
            query.$or = [
                { userId: userid },
                { userId2: userid }
            ];
        }

        // اعمال فیلترهای اختیاری
        if (title) {
            query.title = { $regex: title, $options: 'i' };
        }

        if (phone) {
            // اگر شماره تلفن وارد شده، کاربر مربوطه را پیدا کن
            const user = await UserModel.findOne({ phone: phone });
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'کاربر با این شماره تلفن یافت نشد'
                });
            }

            // اگر کاربر ADMINPRO است، جستجو بر اساس userId کاربر پیدا شده
            if (role === "ADMINPRO") {
                query.$or = [
                    { userId: user._id },
                    { userId2: user._id }
                ];
            } else {
                // برای کاربران عادی، فقط اگر جستجو برای خودشان باشد
                if (!user._id.equals(userid)) {
                    return res.status(403).json({
                        success: false,
                        message: 'شما فقط می‌توانید اعلان‌های خود را مشاهده کنید'
                    });
                }
                // نیازی به تغییر کوئری نیست چون از قبل فیلتر userid اعمال شده
            }
        }

        if (importance) {
            query.importance = parseInt(importance);
        }

        // تنظیم محدودیت تعداد نتایج
        const resultLimit = limit ? parseInt(limit) : 20;

        const nots = await NotificationModel.find(query)
            .sort({ createdAt: -1 })
            .limit(resultLimit)
            .select('-__v');

        res.status(200).json({
            success: true,
            nots
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'خطا در دریافت اعلان‌ها'
        });
    }
};

const GetALLfree=async(req,res)=>{
    const role=req.user.role;
    const userid=req.user._id;
    const  userRole=req.user.role;
    let nots=[]
    if(role=="ADMINPRO"){
        nots=await NotificationModel.find().select('-__v');
    }else{
        nots = await NotificationModel.find({
            $or: [
                { userId: userid },
                { userId2: userid }
            ]
        }).sort({ _id: -1 }).limit(20).select('-__v');
    }
    console.log(nots[0])
    res.status(200).json({
        nots
    })
}

const GetALL4=async(req,res)=>{
    const role=req.user.role;
    const userid=req.user._id;
    const  userRole=req.user.role;
    let nots=[]
        nots = await NotificationModel.find({
            $or: [
                { userId: userid },
                { userId2: userid }
            ],
            $and: [
                {importance:4}
            ]
        }).sort({ _id: -1 }).limit(50).select('-__v');

    console.log(nots[0])
    res.status(200).json({
        nots
    })
}

export default {GetALL,GetALL4,GetALLfree}

