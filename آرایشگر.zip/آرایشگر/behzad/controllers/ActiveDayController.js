import mongoose from "mongoose";
import ActiveDayModel from "../Models/ActiveDay.js";
import HolidayModel from "../Models/Holiday.js";
import NewNotification from "../middlewares/NewNotification.js";
import jalaali from 'jalaali-js';

const GetALL=async(req,res)=>{
    const days=await ActiveDayModel.find().select('-__v');
    res.status(200).json({
        days
    })
}
const NewDay = async (req, res) => {
    try {
        const { title, date } = req.body;

        // 1. اعتبارسنجی ورودی‌ها
        if (!title || !date) {
            console.log('خطا: فیلدهای الزامی پر نشده‌اند', { title, date });
            return res.status(400).json({
                message: 'عنوان و تاریخ الزامی هستند.',
            });
        }

        // 2. تبدیل تاریخ ورودی به شیء Date
        const inputDate = new Date(date);
        inputDate.setMinutes(inputDate.getMinutes() + 210);

        if (isNaN(inputDate)) {
            console.log('خطا: فرمت تاریخ نامعتبر است', { date });
            return res.status(400).json({
                message: 'فرمت تاریخ نامعتبر است. از فرمت YYYY-MM-DD استفاده کنید.',
            });
        }

        // 3. تنظیم ساعت برای مقایسه فقط تاریخ
        const inputDateOnly = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate());
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // 4. بررسی اینکه تاریخ ورودی قبل از امروز نباشد
        if (inputDateOnly < today) {
            console.log('خطا: تاریخ قبل از امروز', { inputDate, today });
            return res.status(400).json({
                message: 'تاریخ وارد شده باید امروز یا بعد از امروز باشد.',
            });
        }

        // 5. بررسی تکرار تاریخ با is_active: true
        const existingActiveDay = await ActiveDayModel.findOne({
            date: {
                $gte: inputDateOnly,
                $lt: new Date(inputDateOnly.getTime() + 24 * 60 * 60 * 1000), // روز بعدی
            },
            is_active: true,
        });

        if (existingActiveDay) {
            console.log('خطا: تاریخ قبلاً با وضعیت فعال ثبت شده است', {
                date: inputDateOnly,
                existing: existingActiveDay,
            });
            return res.status(400).json({
                message: 'این تاریخ قبلاً به عنوان روز کاری فعال ثبت شده است.',
            });
        }

        // 6. ایجاد روز کاری جدید
        const newDay = await ActiveDayModel.create({
            title,
            date: inputDateOnly,
            is_active: true,
        });

        // 7. لاگ موفقیت
        console.log('روز کاری جدید ثبت شد:', { id: newDay._id, title, date: inputDateOnly });const gDate = inputDateOnly; // Date object

        const jDate = jalaali.toJalaali(gDate);

        const formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;

        NewNotification(
            'روز کاری جدید',
            `روز کاری جدید به تاریخ ${formattedDate} توسط ${req.user.name} ثبت شد.`,
            req.user._id,
            null,
            3
        );

        return res.status(201).json({
            message: 'روز کاری با موفقیت ثبت شد.',
            day: newDay,
        });
    } catch (error) {
        // 9. لاگ خطا
        console.error('خطا در ثبت روز کاری:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در ثبت روز کاری.',
            error: error.message,
        });
    }
};
const GetWeekDays = async (req, res) => {
    try {
        const { num } = req.params;

        if (!num) {
            return res.status(400).json({ message: 'شماره هفته الزامی است.' });
        }

        const weekNum = parseInt(num);
        if (isNaN(weekNum)) {
            return res.status(400).json({ message: 'شماره هفته باید یک عدد صحیح باشد.' });
        }

        // تابع تبدیل تاریخ به ایران (فرمت YYYY-MM-DD)
        const formatDateToIran = (date) => {
            const iranOffset = 3.5 * 60; // دقیقه
            const local = new Date(date.getTime() + iranOffset * 60 * 1000);
            return local.toISOString().split('T')[0];
        };

        // تعیین تاریخ امروز ایران
        const now = new Date();
        const todayStr = formatDateToIran(now); // امروز ایران (مثلاً 2025-07-14)

        // محاسبه بازه هفته
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const startDate = new Date(today.getTime() + (weekNum - 1) * 7 * 24 * 60 * 60 * 1000);
        const endDate = new Date(startDate.getTime() + 7 * 24 * 60 * 60 * 1000);

        const activeDays = await ActiveDayModel.find({
            date: { $gte: startDate, $lt: endDate },
        }).select('date');

        const holidays = await HolidayModel.find({
            date: { $gte: startDate, $lt: endDate },
        }).select('date');

        const holidayDates = holidays.map(h => formatDateToIran(h.date));

        const weekDaysMap = {};

        // اضافه‌کردن روزهای کاری
        activeDays.forEach(day => {
            const dateStr = formatDateToIran(day.date);
            weekDaysMap[dateStr] = {
                _id: day._id,
                date: dateStr,
                isHoliday: false,
                isToday: dateStr === todayStr,
            };
        });

        // اضافه‌کردن تعطیلی‌ها
        holidays.forEach(holiday => {
            const dateStr = formatDateToIran(holiday.date);
            if (!weekDaysMap[dateStr]) {
                weekDaysMap[dateStr] = {
                    date: dateStr,
                    isHoliday: true,
                    isToday: dateStr === todayStr,
                };
            } else {
                // اگر در هر دو بود، تعطیل بودن را ثبت کن
                weekDaysMap[dateStr].isHoliday = true;
                weekDaysMap[dateStr].isToday = dateStr === todayStr;
            }
        });

        // تبدیل map به آرایه مرتب‌شده
        const allDays = Object.values(weekDaysMap).sort((a, b) => new Date(a.date) - new Date(b.date));

        return res.status(200).json({
            message: `روزهای هفته ${weekNum} با موفقیت دریافت شدند.`,
            days: allDays,
        });

    } catch (error) {
        console.error('خطا در دریافت روزهای کاری:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در دریافت روزهای کاری.',
            error: error.message,
        });
    }
};


export default {GetALL,NewDay,GetWeekDays}

