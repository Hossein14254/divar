import HolidayModel from "../Models/Holiday.js";
import mongoose from "mongoose";
import NewNotification from "../middlewares/NewNotification.js";
import jalaali from 'jalaali-js';

const GetALL=async(req,res)=>{
    const days=await HolidayModel.find().select('-__v');
    res.status(200).json({
        days
    })
}

const NewDey = async (req, res) => {
    try {
        const { date, description } = req.body;

        // بررسی فرمت تاریخ
        const inputDate = new Date(date);
        const today = new Date();

        // حذف ساعت از تاریخ
        inputDate.setHours(0, 0, 0, 0);
        today.setHours(0, 0, 0, 0);

        // بررسی اینکه آیا تاریخ ورودی معتبر است
        if (isNaN(inputDate.getTime())) {
            return res.status(400).json({ message: "تاریخ ورودی معتبر نیست." });
        }

        // بررسی اینکه آیا تاریخ ورودی از امروز عقب‌تر است
        if (inputDate < today) {
            return res.status(400).json({ message: "تاریخ ورودی نمی‌تواند از تاریخ امروز عقب‌تر باشد." });
        }
        const Dey = await HolidayModel.create({
            date:inputDate,
            description
        })
        const gDate = new Date(inputDate);

        const jDate = jalaali.toJalaali(gDate);

        const formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;

        NewNotification(
            'ثبت تعطیلی',
            `کاربر ${req.user.name} تعطیلی به تاریخ ${formattedDate} ثبت کرد.`,
            req.user._id,
            null,
            3
        );

        res.status(200).json({
            message:"تاریخ اعلام شده شما تعطیل ثبت شد.",
            date:Dey
        })
    }catch (e) {
        res.status(500).json({
            message:"خطای سرور",
            e:e.message
        })
    }
};
const DeleteHolidey=async (req,res)=>{
    try {
        const {holideyid}=req.params;
        const isvalidholideyid=mongoose.isValidObjectId(holideyid)
        if(!holideyid){
            return res.status(401).json({
                message:"ای دی ارسالی شما معتبر نمی باشد."
            })
        }
        const dey=await HolidayModel.findByIdAndDelete(holideyid).lean()
        if(dey){
            const gDate = new Date(dey.date);
            const jDate = jalaali.toJalaali(gDate);
            const formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;

            NewNotification(
                'حذف تعطیلی',
                `کاربر ${req.user.name} تعطیلی به تاریخ ${formattedDate} حذف کرد.`,
                req.user._id,
                null,
                3
            );

            return  res.status(200).json({
                message:"تاریخ اعلامی شما با موفیت حذف شد.",
                dey:dey
            })
        }else {
            res.status(409).json({
                message:"چنین روز تعطیلی وجود ندارد.",
            })
        }

    }catch (e) {
        res.status(500).json({
            message:"خطای سرور",
            e:e.message
        })
    }
}

export default {GetALL,NewDey,DeleteHolidey}

