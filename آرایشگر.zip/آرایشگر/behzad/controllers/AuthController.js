// controllers/AuthController.js
import bcrypt from 'bcrypt';
import UserModel from '../Models/Users.js'
import JWT from 'jsonwebtoken';
import NewNotification from "../middlewares/NewNotification.js";
const RegisterUser = async (req, res) => {
    console.log(req.body)

    const { name, phone, password } = req.body;

    // بررسی وجود کاربر با شماره تلفن قبلاً ثبت شده
    const isUser = await UserModel.findOne({
        $or: [{ phone }]
    });

    if (isUser) {
        return res.status(409).json({
            message: "کاربر با این مشخصات قبلاً ثبت شده است.",
            data: isUser.name
        });
    }

    // تعداد کاربران موجود
    const lenUsers = await UserModel.estimatedDocumentCount();

    // هش کردن رمز عبور
    const hash = await bcrypt.hash(password, 10);

    // ایجاد کاربر جدید
    const user = await UserModel.create({
        name,
        phone,
        password: hash,
        role: lenUsers > 0 ? "USER" : "ADMINPRO" // اولین کاربر مدیر کل
    });

    // حذف رمز عبور از شی کاربر
    const userObject = user.toObject();
    Reflect.deleteProperty(userObject, 'password');

    // ایجاد توکن JWT
    const token = JWT.sign({ _id: user._id }, process.env.JWT_SECRET);

    NewNotification(
        'ثبت نام',
        `کاربر ${name} با موفقیت ثبت نام شد.`,
        user._id,
        3
    );

    res.status(200).json({
        user: userObject,
        token
    });
};
const LoginUser = async (req, res) => {
    const {identifier, password}=req.body
    const user = await UserModel.findOne({
        $or : [{phone:identifier}]
    })
    if(!user){
        return res.status(401).json({
            message:"شماره همراه اشتباه هست."
        })
    }
    const isvalidpassword=await bcrypt.compare(password,user.password)
    if(!isvalidpassword){
        return res.status(401).json({
            message:"رمزعبور شما اشتباه هست."
        })
    }
    const accessToken =JWT.sign({id:user._id},process.env.JWT_SECRET,{
        expiresIn:'30 day'
    })
    res.status(200).json({
        phone:user.phone,
        accessToken:accessToken
    })
};
// ذخیره کدهای تأیید در حافظه (موقت)
const codeStore = new Map();

const LoginUserCode = async (req, res) => {
    const { identifier, usercode } = req.body;

    // مرحله ۱: دریافت شماره تلفن و تولید کد تأیید
    if (!usercode) {
        if (!identifier) {
            return res.status(400).json({
                message: "شماره همراه الزامی است."
            });
        }

        // بررسی وجود کاربر
        const user = await UserModel.findOne({
            $or: [{ phone: identifier }]
        });

        if (!user) {
            return res.status(401).json({
                message: "شماره همراه اشتباه است."
            });
        }

        // تولید کد تأیید تصادفی
        const generatedCode = Math.floor(Math.random() * (99999 - 10000 + 1)) + 10000;

        // ذخیره کد در حافظه با زمان انقضا (مثلاً ۵ دقیقه)
        codeStore.set(identifier, {
            code: generatedCode,
            expiresAt: Date.now() + 5 * 60 * 1000 // انقضا پس از ۵ دقیقه
        });

        // لاگ کردن کد تأیید در کنسول
        console.log(`کد تأیید برای ${identifier}: ${generatedCode}`);

        return res.status(200).json({
            message: "کد تأیید در کنسول لاگ شد."
        });
    }

    // مرحله ۲: بررسی کد تأیید
    const storedData = codeStore.get(identifier);

    if (!storedData || storedData.expiresAt < Date.now()) {
        codeStore.delete(identifier); // حذف کد منقضی‌شده
        return res.status(401).json({
            message: "کد تأیید منقضی شده یا وجود ندارد. دوباره شماره را ارسال کنید."
        });
    }

    if (Number(usercode) !== storedData.code) {
        return res.status(401).json({
            message: "کد تأیید اشتباه است. دوباره کد را وارد کنید.",
            usercode: Number(usercode),
            storedCode: storedData.code
        });
    }

    // یافتن کاربر
    const user = await UserModel.findOne({
        $or: [{ phone: identifier }]
    });

    if (!user) {
        codeStore.delete(identifier); // حذف کد در صورت عدم وجود کاربر
        return res.status(401).json({
            message: "کاربر یافت نشد."
        });
    }

    // تولید توکن دسترسی
    const accessToken = JWT.sign({ id: user._id }, process.env.JWT_SECRET, {
        expiresIn: '30d'
    });

    // پاک کردن کد تأیید از حافظه
    codeStore.delete(identifier);
    NewNotification(
        'ورود',
        `کاربر ${user.name} با شماره تلفن وارد سیستم شد.`,
        user._id,
        null,
        3
    );

    return res.status(200).json({
        phone: user.phone,
        accessToken: accessToken
    });
};

const GetMe = async (req, res) => {
    const user=req.user;
    res.json(user);
};

export default { RegisterUser ,GetMe ,LoginUser,LoginUserCode};