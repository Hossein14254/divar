import HolidayModel from "../Models/Holiday.js";
import mongoose from "mongoose";
import ServicesModel from "../Models/Services.js";
import WorkingHourModel from "../Models/WorkingHourModel.js";
import NewNotification from "../middlewares/NewNotification.js";

const GetALL=async(req,res)=>{
    const Services=await ServicesModel.find({is_active:true}).select('-__v');
    res.status(200).json({
        Services
    })
}

const NewService = async (req, res) => {
    try {
        const { title, description, price, minute } = req.body;

        // 1. اعتبارسنجی ورودی‌ها
        if (!title || !price || !minute) {
            console.log('خطا: فیلدهای الزامی پر نشده‌اند', { title, price, minute });
            return res.status(400).json({
                message: 'فیلدهای نام، هزینه و زمان الزامی هستند.',
            });
        }

        // 2. بررسی مقادیر منفی
        if (price < 0 || minute < 0) {
            console.log('خطا: مقادیر منفی', { price, minute });
            return res.status(400).json({
                message: 'هزینه و زمان خدمت نمی‌توانند منفی باشند.',
            });
        }

        // 3. بررسی نوع داده‌ها
        if (typeof title !== 'string' || typeof price !== 'number' || typeof minute !== 'number') {
            console.log('خطا: نوع داده‌ها نامعتبر', { title, price, minute });
            return res.status(400).json({
                message: 'نوع داده‌های ورودی نامعتبر است.',
            });
        }

        // 4. ایجاد خدمت جدید
        const newService = await ServicesModel.create({
            title,
            description,
            price,
            minute,
        });

        // 5. لاگ موفقیت
        console.log('خدمت جدید ثبت شد:', { id: newService._id, title });

        NewNotification(
            'سرویس جدید',
            `کاربر ${req.user.name} سرویس "${title}" را ثبت کرد.`,
            req.user._id,
            null,
            3
        );
        return res.status(201).json({
            message: 'خدمت با موفقیت ثبت شد.',
            service: newService,
        });
    } catch (error) {
        // 7. لاگ خطا
        console.error('خطا در ثبت خدمت:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در ثبت خدمت.',
            error: error.message,
        });
    }
};
const DeleteService=async (req,res)=>{
    try {
        const {serviceid}=req.params;
        const isvalidserviceid=mongoose.isValidObjectId(serviceid)
        if(!serviceid){
            return res.status(401).json({
                message:"ای دی ارسالی شما معتبر نمی باشد."
            })
        }
        const service= await ServicesModel.findByIdAndUpdate(
            serviceid,
            { is_active: false },
            { new: true }
        ).lean();
        if(service){
            NewNotification(
                'حذف سرویس',
                `کاربر ${req.user.name} سرویس "${service.title}" را حذف کرد.`,
                req.user._id,
                null,
                3
            );

            return  res.status(200).json({
                message:"خدمات اعلامی شما با موفیت حذف شد.",
                service:service
            })
        }else {
            res.status(409).json({
                message:"چنین خدماتی وجود ندارد.",
            })
        }

    }catch (e) {
        res.status(500).json({
            message:"خطای سرور",
            e:e.message
        })
    }
}

export default {GetALL,NewService,DeleteService}

