import mongoose from "mongoose";
import UserModel from "../models/Users.js";
import bcrypt from "bcrypt";
import NewNotification from "../middlewares/NewNotification.js";

const Ban =async (req,res)=>{
    const {userid}=req.params;
    const user =await UserModel.findOne({_id:userid}).lean();
    if(!user){
        return res.status(404).json({
            message:"چنین کاربری وجود ندارد.",
        })
    }
    const updatedUser = await UserModel.findByIdAndUpdate(
            userid,
            { ban: !user.ban },
            { new: true } // این باعث میشه نسخه آپدیت‌شده برگرده
        ).select('-password');
    if(updatedUser.ban== true){
        NewNotification(
            'مسدود شد',
            `حساب کاربر ${updatedUser.name} به دلیل نقض قوانین مسدود شد.`,
            req.user._id,
            userid,
            3
        );
        return res.status(200).json({
            message:"کاربر با موفقیت بن شد.",
        })
    }else {
        return res.status(200).json({
            message:"کاربر با موفقیت آزاد شد.",
        })
    }
    return res.status(500).json({
        message:"خطا در بن شدن کاربر"
    })}
const Barber =async (req,res)=>{
    const {userid}=req.params;
    const user =await UserModel.findOne({_id:userid}).lean();
    if(!user){
        return res.status(404).json({
            message:"چنین کاربری وجود ندارد.",
        })
    }
    if(!user.role=="ADMIN" || !user.role=="ADMINPRO"){
        return res.status(404).json({
            message:"این کاربر در سیستم ارایشگر ثبت نشده هست شما نمی توانید کاربری که ارایشگر نیست را به ارایشگر فعال تبدیل کنید.",
        })
    }
    const updatedUser = await UserModel.findByIdAndUpdate(
        userid,
        { isbarber: !user.isbarber },
        { new: true } // این باعث میشه نسخه آپدیت‌شده برگرده
    ).select('-password');
    if(updatedUser.isbarber=== true){
        NewNotification(
            'تغییر نقش',
            `نقش کاربر ${updatedUser.name} به آرایشگر تغییر یافت.`,
            req.user._id,
            userid,
            3
        );

        return res.status(200).json({
            message:"کاربر با موفقیت آرایشگر فعال تبدیل شد.",
        })
    }else {
        return res.status(200).json({
            message:"کاربر با موفقیت آرایشگر غیرفعال تبدیل شد.",
        })
    }
    return res.status(500).json({
        message:"خطا در بن شدن کاربر"
    })}
const GetALL=async(req,res)=>{
    const users=await UserModel.find();
    res.status(200).json({
        users
    })
}
const DeleteUser=async (req,res)=>{
    try {
        const {userid}=req.params;
        const isvaliduserid=mongoose.isValidObjectId(userid)
        if(!userid){
            return res.status(401).json({
                message:"ای دی ارسالی شما معتبر نمی باشد."
            })
        }
        const user=await UserModel.findByIdAndDelete(userid).lean()
        if(user){
            NewNotification(
                'حذف حساب کاربر',
                `حساب کاربر ${user.name} از سیستم حذف شد.`,
                req.user._id,
                userid,
                3
            );

            return  res.status(200).json({
                message:"کاربر با موفیت حذف شد.",
                user:user
            })
        }else {
            res.status(409).json({
                message:"چنین کاربری وجود ندارد.",
            })
        }

    }catch (e) {
        res.status(500).json({
            message:"خطای سرور",
            e:e.message
        })
    }
}
const PutRole = async (req, res) => {
    try {
        const { userid } = req.params;
        const user = await UserModel.findById(userid).lean();

        if (!user) {
            return res.status(404).json({
                message: "چنین کاربری وجود ندارد.",
            });
        }

        // منطق تغییر نقش ها
        let newRole;
        if (user.role === "USER") {
            newRole = "ADMIN"; // اگر کاربر USER باشد، به ADMIN تغییر کند
        } else if (user.role === "ADMIN") {
            newRole = "USER"; // اگر کاربر ADMIN باشد، به ADMINPRO تغییر کند
        } else {
            newRole = "USER"; // اگر کاربر ADMINPRO باشد، به USER تغییر کند
        }

        const updatedUser = await UserModel.findByIdAndUpdate(
            userid,
            { role: newRole, isbarber: false },
            { new: true } // این باعث میشه نسخه آپدیت‌شده برگرده
        );
        NewNotification(
            'تغییر نقش',
            `نقش کاربر ${updatedUser.name} به ${newRole} تغییر یافت.`,
            req.user._id,
            userid,
            3
        );

        res.status(200).json({
            message: "نقش کاربر تغییر پیدا کرد.",
            role: updatedUser.role,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "خطا در تغییر نقش کاربر.",
        });
    }
};
const PutUser = async (req,res)=>{
    try {
        const {name}=req.body;

        const user=await UserModel.findByIdAndUpdate({
            _id:req.user._id
        },{
            name,
        },{new:true}).select('-password -__v').lean()

        NewNotification(
            'بروزرسانی پروفایل',
            `${req.user.name}
             پروفایل خودشو ویرایش کرد .`,
            req.user._id,
            null,
            3);

        return res.status(200).json({
            message:"کاربر بروزرسانی شد.",
            data:user
        })
    }catch (e) {
        res.status(500).json({
            message:"خطا سرور",
            err:e.message
        })
    }
}
const GetALLBarber=async  (req,res)=>{
    const users=await UserModel.find({isbarber:true});
    res.status(200).json({
        users
    })
}
const PutWallet = async (req, res) => {
    try {
        const { newwallet,phone } = req.body;
        if(!newwallet){
            return res.status(400).json({
                message: "مقدار میزان شارژ حساب معتبر نمی باشد.",
            });
        }
        if(newwallet==null){
            return res.status(400).json({
                message: "مقدار میزان شارژ حساب معتبر نمی باشد.",
            });
        }
        const user = await UserModel.findOne({phone:phone}).lean();

        if (!user) {
            return res.status(404).json({
                message: "چنین کاربری وجود ندارد.",
            });
        }

        if(!req.user.role=="ADMINPRO"){
            if(user._id!=req.user._id){
                return res.status(400).json({
                    message: "شما فقط می توانید موجود خودتون را شارژ کنید",
                })
            }
        }
        const updatedUser = await UserModel.findByIdAndUpdate(
            user._id,
            { wallet:user.wallet+newwallet },
            { new: true }
        );
        NewNotification(
            'واریز',
            `حساب کاربر ${updatedUser.name} با مبلغ ${newwallet} شارژ شد.`,
            req.user._id,
            user._id,
            4
        );

        res.status(200).json({
            message: "کیف پول بروز شد",
            role: updatedUser.wallet,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "خطا در تغییر موجودی کیف پول .",
            error:error
        });
    }
};

export default {Ban,GetALL,DeleteUser,Barber,PutRole,PutUser,GetALLBarber,PutWallet}