import LeaveModel from '../Models/LeaveModel.js';
import WorkingHourModel from '../Models/WorkingHourModel.js';
import ActiveDayModel from "../Models/ActiveDay.js";
import mongoose from "mongoose";
import UserModel from "../Models/Users.js";
import NewNotification from "../middlewares/NewNotification.js";
import jalaali from 'jalaali-js';

const NewLeave = async (req, res) => {
    try {
        const { title, date_id, provider_id, workingHour_ids } = req.body;

        // 1. اعتبارسنجی ورودی‌ها
        if (!title || !date_id || !provider_id || !workingHour_ids || !Array.isArray(workingHour_ids) || workingHour_ids.length === 0) {
            console.log('خطا: فیلدهای الزامی پر نشده‌اند یا workingHour_ids نامعتبر است', { title, date_id, provider_id, workingHour_ids });
            return res.status(400).json({
                message: 'عنوان، شناسه روز، شناسه آرایشگر و آرایه ساعت‌های کاری الزامی هستند.',
            });
        }

        // 2. بررسی وجود ActiveDay
        const activeDay = await ActiveDayModel.findById(date_id);
        if (!activeDay || !activeDay.is_active) {
            console.log('خطا: روز کاری یافت نشد یا غیرفعال است', { date_id });
            return res.status(400).json({
                message: 'روز کاری با این شناسه یافت نشد یا غیرفعال است.',
            });
        }

        // 3. تنظیم تاریخ برای مقایسه
        const inputDateOnly = new Date(activeDay.date);
        inputDateOnly.setHours(0, 0, 0, 0);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // 4. بررسی اینکه تاریخ ورودی قبل از امروز نباشد
        if (inputDateOnly < today) {
            console.log('خطا: تاریخ قبل از امروز', { inputDate: inputDateOnly, today });
            return res.status(400).json({
                message: 'تاریخ مرخصی باید امروز یا بعد از امروز باشد.',
            });
        }

        const provider = await UserModel.findById(provider_id).lean();
        if (!provider) {
            return res.status(400).json({
                message: "کاربر نامعتبر می باشد."
            });
        }
        if (provider.role === "USER") {
            return res.status(400).json({
                message: "برای ثبت مرخصی باید شخصی را انتخاب کنید که آرایشگر باشد."
            });
        }
        if (provider.isbarber === false) {
            return res.status(400).json({
                message: "برای ثبت مرخصی باید شخصی را انتخاب کنید که آرایشگر باشد."
            });
        }

        // 5. بررسی وجود WorkingHour_idها
        const workingHours = await WorkingHourModel.find({ _id: { $in: workingHour_ids } });
        if (workingHours.length !== workingHour_ids.length) {
            return res.status(400).json({
                message: 'یک یا چند شناسه ساعت کاری نامعتبر است.',
            });
        }

        // 6. بررسی تکرار مرخصی برای همان تاریخ و آرایشگر
        const existingLeaves = await LeaveModel.find({
            date_id,
            provider_id,
            WorkingHour_id: { $in: workingHour_ids },
            is_active: true,
        });

        if (existingLeaves.length > 0) {
            console.log('خطا: مرخصی برای برخی ساعت‌ها قبلاً ثبت شده است', {
                date_id,
                provider_id,
                existing: existingLeaves.map(l => l.WorkingHour_id.toString()),
            });
            return res.status(400).json({
                message: 'مرخصی برای یک یا چند ساعت کاری در این روز قبلاً ثبت شده است.',
            });
        }

        // 7. ایجاد رکوردهای مرخصی برای هر ساعت کاری
        const createdLeaves = [];
        for (const workingHour_id of workingHour_ids) {
            const newLeave = await LeaveModel.create({
                title,
                date_id,
                provider_id,
                WorkingHour_id: workingHour_id,
                is_active: true,
            });
            createdLeaves.push(newLeave);
        }

        // 8. لاگ موفقیت
        console.log('مرخصی‌های جدید ثبت شدند:', {
            date_id,
            provider_id,
            workingHour_ids,
            created: createdLeaves.map(l => l._id.toString()),
        });

        // 9. ایجاد نوتفیکیشن با نمایش دقیق بازه‌های زمانی
        const gDate = new Date(activeDay.date);
        const jDate = jalaali.toJalaali(gDate);
        const formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;

        const timeRanges = workingHours.map(h => h.time).join('، ');
        const notificationText = `کاربر ${req.user.name} مرخصی روز ${formattedDate} در بازه‌های زمانی ${timeRanges} را ثبت کرد.`;

        NewNotification(
            'ثبت مرخصی',
            notificationText,
            req.user._id,
            provider_id,
            3
        );
        return res.status(201).json({
            message: 'مرخصی‌ها با موفقیت ثبت شدند.',
            leaves: createdLeaves,
        });
    } catch (error) {
        // 10. لاگ خطا
        console.error('خطا در ثبت مرخصی:', error.message);
        return res.status(500).json({
            message: 'خطای سرور در ثبت مرخصی.',
            error: error.message,
        });
    }
};
const GetAll =async (req,res)=>{
    const Leave=await LeaveModel.find().select('-__v')
        .populate('date_id','date')
        .populate('provider_id', 'name')
        .populate('WorkingHour_id' ,'start_time end_time');
    res.status(200).json({
        Leave
    })
}
const DeleteLeave = async (req, res) => {
    try {
        const { leaveId } = req.params;

        if (!leaveId || !mongoose.isValidObjectId(leaveId)) {
            return res.status(400).json({ message: 'شناسه مرخصی نامعتبر است.' });
        }

        // پیدا کردن مرخصی همراه با تاریخ روز و ساعت کاری
        const leave = await LeaveModel.findById(leaveId)
            .populate('date_id')       // فرض: ActiveDay مدل با فیلد date
            .populate('WorkingHour_id') // فرض: WorkingHour مدل با فیلد startTime یا time

        if (!leave) {
            return res.status(404).json({ message: 'مرخصی یافت نشد.' });
        }

        // حذف مرخصی
        await leave.deleteOne();

        // ساخت متن اعلان با تاریخ و ساعت
        const gDate = leave.date_id?.date ? new Date(leave.date_id.date) : null;

        let formattedDate = 'نامشخص';
        if (gDate) {
            const jDate = jalaali.toJalaali(gDate);
            formattedDate = `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;
        }

        const timeStr = leave.WorkingHour_id?.startTime || leave.WorkingHour_id?.time || 'نامشخص';

        NewNotification(
            'حذف مرخصی',
            `کاربر ${req.user.name} مرخصی به تاریخ ${formattedDate} و ساعت ${timeStr} حذف کرد.`,
            req.user._id,
            leave.provider_id,
            3
        );

        return res.status(200).json({
            message: 'مرخصی با موفقیت حذف شد.',
            leave,
        });

    } catch (error) {
        console.error('خطا در حذف مرخصی:', error.message);
        return res.status(500).json({ message: 'خطای سرور در حذف مرخصی.', error: error.message });
    }
};
export default {NewLeave,GetAll,DeleteLeave};