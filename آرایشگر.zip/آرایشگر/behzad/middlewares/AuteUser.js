import jwt from 'jsonwebtoken'
import UserModel from "../Models/Users.js";

const isUser = async (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // فرمت: "Bearer <token>"

        if (!token) {
            return res.status(401).json({ message: 'عدم دسترسی: توکن ارائه نشده است' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET); // کلید مخفی JWT باید در .env تعریف شود
        console.log(decoded)
        const user = await UserModel.findById(decoded.id).select('-password -__v')
        req.user=user
        next(); // ادامه به middleware یا route بعدی
    } catch (error) {
        console.error(error);
        return res.status(401).json({ message: 'عدم دسترسی: توکن نامعتبر است' });
    }
};
export default { isUser };
