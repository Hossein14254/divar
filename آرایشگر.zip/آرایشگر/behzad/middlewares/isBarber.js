const isBarber = async (req, res, next) => {
    console.log(req.user)
    const user = req.user;
    const isBarber = user.role == "ADMIN";
    req.isBarber = isBarber;

    if (isBarber) {
        // next();
        console.log(isBarber)
    } else {
        return res.status(403).json({
            message: "شما مجوز دسترسی به این بخش را ندارید."
        });
    }
}

export default { isBarber }