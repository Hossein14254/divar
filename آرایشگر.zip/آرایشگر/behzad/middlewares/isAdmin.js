const IsAdmin = async (req, res, next) => {
    console.log(req.user)
    const user = req.user;
    const isadmin = user.role == "ADMINPRO";
    req.isadmin = isadmin;

    if (isadmin) {
        next();
        console.log(isadmin)
    } else {
        return res.status(403).json({
            message: "شما مجوز دسترسی به این بخش را ندارید."
        });
    }
}

export default { IsAdmin }