
import NotificationModel from '../models/Notification.js';
const Notification = async (title, text, userId, userId2, importance) => {
    try {
        const newNotification = new NotificationModel({
            title,
            text,
            userId,
            userId2: userId2 || null, // اگر userId2 برابر 0 باشد، آن را null تنظیم کنید
            importance
        });

        await newNotification.save(); // ذخیره اعلان
        console.log('Notification saved:', newNotification);
    } catch (error) {
        console.error('Error saving notification:', error);
    }
};
export default Notification;